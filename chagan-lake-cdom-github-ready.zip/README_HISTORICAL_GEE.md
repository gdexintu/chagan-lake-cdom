# 查干湖 1986-2026 历史 CDOM 制图流程

## 重要科学边界

Sentinel-2 从 2015 年以后才可用，不能覆盖 1986-2014。
因此 1986-2026 的长时间序列必须使用 Landsat 5/7/8/9。

原来的 Sentinel-2 随机森林模型使用了 `B1、B2、B3、B4、B5、B8、B12` 等特征，其中 `B5=705 nm` 是 Sentinel-2 红边波段，Landsat 没有对应波段。
所以不能把原 Sentinel-2 模型直接套到 1986 年 Landsat 影像上。

本流程采用更严谨的替代方案：

1. 使用 Sentinel-2 样本训练一个 Landsat/Sentinel 共通波段模型；
2. 共通波段包括 Blue、Green、Red、NIR、SWIR1、SWIR2；
3. 用该模型对 GEE 导出的 Landsat 历史影像进行 CDOM 代理反演；
4. 论文中应表述为“基于共通波段的历史 CDOM 产品重建/代理制图”。

## GEE 导出步骤

1. 打开 Google Earth Engine Code Editor：
   `https://code.earthengine.google.com/`
2. 复制脚本：
   `D:\codex\gee_scripts\gee_chaganlake_historical_landsat_exports.js`
3. 粘贴到 GEE Code Editor。
4. 点击 `Run`。
5. 右侧 `Tasks` 会出现多个导出任务。
6. 逐个点击 `Run`，导出到 Google Drive 文件夹：
   `ChaganLake_CDOM_GEE_Exports`
7. 从 Google Drive 下载所有 GeoTIFF 到：
   `D:\codex\gee_exports`

默认年份：

```text
1986, 1991, 1996, 2001, 2006, 2011, 2016, 2021
```

注意：当前日期是 2026-05-16，2026 年 6-9 月还没有发生，不能生成完整的 2026 年夏季平均影像。
等 2026-09-30 以后，可以在 GEE 脚本中加入 `2026`。

## GEE 预处理内容

GEE 脚本使用：

- Landsat Collection 2 Level-2 Surface Reflectance；
- Tier 1 数据，降低几何配准误差；
- QA_PIXEL 去除云、云影、雪、填充值、膨胀云；
- QA_RADSAT 去除饱和像元；
- Landsat 8/9 使用 SR_QA_AEROSOL 去除高气溶胶像元；
- MNDWI / NDVI 水体掩膜；
- 6-9 月季节中值合成，降低单景噪声和大气残差影响。

这些步骤只能降低误差，不能完全消除大气校正误差、气溶胶误差或几何误差。论文中不要写成“完全消除了误差”。

## 本地 Python 反演和制图

导出的 GeoTIFF 放入 `D:\codex\gee_exports` 后运行：

```powershell
D:\codex\pytorch\Scripts\python.exe D:\codex\cdom_historical_mapping_from_gee.py
```

输出目录：

```text
D:\codex\outputs\cdom_2020\historical_cdom
```

主要输出：

- `rasters\ChaganLake_CDOM_RF_年份_JunSep.tif`
- `figures\01_historical_cdom_spatial_panel.png`
- `figures\02_historical_cdom_time_series.png`
- `tables\06_historical_cdom_stats.csv`

## 当前本地模型验证结果

本地脚本已成功训练共通波段 RF 模型。
当前没有 GEE GeoTIFF 输入文件，所以暂时不能生成历史空间图。

模型测试集结果：

```text
R²   = 0.644
RMSE = 0.500
MAE  = 0.385
OOB R² = 0.638
```

这个结果低于 Sentinel-2 红边模型是正常的，因为 Landsat 缺少 Sentinel-2 的关键红边波段。
