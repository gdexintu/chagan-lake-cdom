# Chagan Lake CDOM Remote-Sensing Reconstruction

This repository contains the Python and Google Earth Engine workflows used to reconstruct and map colored dissolved organic matter (CDOM) proxy values in Chagan Lake, Jilin Province, China.

The target variable used in the current workflow is not in-situ CDOM. It is the extracted mean value from a public CDOM remote-sensing product. Therefore, the models should be interpreted as reconstruction or approximation of an existing CDOM product, not as field-validated CDOM concentration inversion.

## Main Workflows

### 1. Sentinel-2 feature engineering and model comparison

`cdom_complete_ml_pipeline.py`

- Cleans sample records and removes outliers.
- Keeps water pixels using Sentinel-2 SCL water class.
- Applies optical stratification using `B11/B3`.
- Builds candidate features from original bands, band ratios, normalized indices, red-edge indices, and nonlinear combinations.
- Screens features with Pearson and Spearman correlation.
- Reduces multicollinearity using VIF.
- Ranks predictors using ReliefF.
- Compares RF, SVR, and XGBoost.
- Generates figures for spectra, correlation, VIF, ReliefF, model metrics, SHAP, and prediction diagnostics.

### 2. Stratified Random Forest workflow

`cdom_stratified_rf.py`

- Implements the optically stratified Sentinel-2 RF workflow.
- Produces a 2020 RF fitted CDOM map and validation figures.

### 3. Cross-sensor long-term mapping

`cdom_cross_sensor_longterm_pipeline.py`

- Builds a Landsat/Sentinel common-band feature set.
- Trains long-term-compatible models.
- Applies the selected model to five-year Landsat/Sentinel composites.
- Generates long-term CDOM proxy maps and temporal statistics.

### 4. Google Earth Engine exports

The `gee_scripts/` directory contains JavaScript scripts for exporting harmonized Landsat/Sentinel composites from GEE.

### 5. Figure production

- `make_integrated_study_area_cdom_map.py`: creates the study-area framework figure with the 2020 RF fitted CDOM map.
- `make_longterm_cdom_lake_only_figure.py`: creates the lake-only long-term CDOM spatial panel.
- `add_2026_longterm_map.py`: adds the 2026 partial-year CDOM map to the long-term outputs.

## Repository Structure

```text
.
├── gee_scripts/                         # Google Earth Engine JavaScript workflows
├── cdom_complete_ml_pipeline.py          # Complete Sentinel-2 ML pipeline
├── cdom_stratified_rf.py                 # Stratified RF workflow
├── cdom_cross_sensor_longterm_pipeline.py# Cross-sensor long-term workflow
├── cdom_historical_mapping_from_gee.py   # Historical mapping helper
├── cdom_rf_inversion.py                  # Baseline RF inversion workflow
├── cdom_correlation_search.py            # Correlation and optical-strata search
├── cdom_rf_70_30_error_search.py         # 70/30 split sensitivity checks
├── cdom_shap_continuous_plots.py         # SHAP continuous-effect plotting
├── make_integrated_study_area_cdom_map.py
├── make_longterm_cdom_lake_only_figure.py
├── add_2026_longterm_map.py
├── requirements.txt
├── DATA.md
└── README.md
```

Large raster files, raw CSV data, virtual environments, generated outputs, and manuscript drafts are intentionally excluded by `.gitignore`.

## Installation

Create and activate a Python environment, then install dependencies:

```bash
pip install -r requirements.txt
```

The project was developed with Python 3.10+ and uses `rasterio`, `scikit-learn`, `xgboost`, `shap`, `numpy`, `pandas`, `scipy`, `matplotlib`, and `joblib`.

## Required Local Data

The code expects local data files that are not committed to GitHub:

- `CDOM_Extracted_2020.csv`
- `S2_2020_AllBands_Median.tif`
- GEE exported rasters under `gee_exports/`

See `DATA.md` for the expected file layout and data interpretation notes.

## Example Commands

Run the complete Sentinel-2 pipeline:

```bash
python cdom_complete_ml_pipeline.py
```

Run the cross-sensor long-term pipeline:

```bash
python cdom_cross_sensor_longterm_pipeline.py
```

Generate the integrated study-area/CDOM map:

```bash
python make_integrated_study_area_cdom_map.py
```

## Scientific Interpretation

Because the target is product-derived CDOM rather than field-measured CDOM, reported model performance measures the ability to reconstruct the public CDOM product from Sentinel-2/Landsat features. Independent field measurements are required before interpreting the output as absolute CDOM concentration.

