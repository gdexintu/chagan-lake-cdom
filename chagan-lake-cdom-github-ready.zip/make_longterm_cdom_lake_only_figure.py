from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
import rasterio
from scipy import ndimage


BASE_DIR = Path(__file__).resolve().parent
GEE_DIR = BASE_DIR / "gee_exports"
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "cross_sensor_longterm"
FIG_DIR = OUT_DIR / "figures"
RASTER_DIR = OUT_DIR / "rasters"
TABLE_PATH = OUT_DIR / "tables" / "11_longterm_cdom_raster_stats.csv"

MNDWI_THRESHOLD = 0.25
NDVI_THRESHOLD = 0.0
REFERENCE_MASK_YEAR = 2001


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 150
    plt.rcParams["savefig.dpi"] = 300
    plt.rcParams["font.sans-serif"] = [
        "Microsoft YaHei",
        "SimHei",
        "Arial Unicode MS",
        "DejaVu Sans",
    ]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 12
    plt.rcParams["axes.labelsize"] = 10
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 9


def source_tif_for_year(year: int) -> Path:
    if year == 2026:
        return GEE_DIR / "ChaganLake_harmonized_SR_2026_to_20260516.tif"
    return GEE_DIR / f"ChaganLake_harmonized_SR_{year}_JunSep.tif"


def largest_lake_mask(source_path: Path) -> np.ndarray:
    with rasterio.open(source_path) as src:
        names = list(src.descriptions)
        mndwi = src.read(names.index("MNDWI") + 1).astype("float32")
        ndvi = src.read(names.index("NDVI") + 1).astype("float32")

    water = np.isfinite(mndwi) & np.isfinite(ndvi)
    water &= mndwi > MNDWI_THRESHOLD
    water &= ndvi < NDVI_THRESHOLD

    labels, n_labels = ndimage.label(water, structure=np.ones((3, 3), dtype=int))
    if n_labels == 0:
        return water

    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    largest = int(np.argmax(sizes))
    lake = labels == largest

    # Smooth tiny edge gaps without expanding into surrounding land.
    lake = ndimage.binary_closing(lake, structure=np.ones((3, 3), dtype=bool), iterations=1)
    lake = ndimage.binary_fill_holes(lake)
    return lake


def reference_lake_mask() -> np.ndarray:
    return largest_lake_mask(source_tif_for_year(REFERENCE_MASK_YEAR))


def crop_extent_from_mask(mask: np.ndarray, bounds, margin_fraction: float = 0.035):
    rows, cols = np.where(mask)
    row_min, row_max = int(rows.min()), int(rows.max())
    col_min, col_max = int(cols.min()), int(cols.max())
    height, width = mask.shape

    xres = (bounds.right - bounds.left) / width
    yres = (bounds.top - bounds.bottom) / height

    x0 = bounds.left + col_min * xres
    x1 = bounds.left + (col_max + 1) * xres
    y1 = bounds.top - row_min * yres
    y0 = bounds.top - (row_max + 1) * yres

    x_margin = (x1 - x0) * margin_fraction
    y_margin = (y1 - y0) * margin_fraction
    return (
        max(bounds.left, x0 - x_margin),
        min(bounds.right, x1 + x_margin),
        max(bounds.bottom, y0 - y_margin),
        min(bounds.top, y1 + y_margin),
    )


def load_masked_rasters(stats: pd.DataFrame, mask: np.ndarray):
    rasters = []
    for _, row in stats.sort_values("year").iterrows():
        year = int(row["year"])
        cdom_path = RASTER_DIR / str(row["output_file"])
        with rasterio.open(cdom_path) as src:
            arr = src.read(1).astype("float32")
            bounds = src.bounds
        masked = np.where(mask & np.isfinite(arr), arr, np.nan)
        rasters.append((year, masked, bounds))
    return rasters


def draw_lake_only_panel() -> Path:
    setup_plot_style()
    stats = pd.read_csv(TABLE_PATH).sort_values("year")
    ref_mask = reference_lake_mask()
    rasters = load_masked_rasters(stats, ref_mask)
    finite = np.concatenate([arr[np.isfinite(arr)] for _, arr, _ in rasters])
    vmin = float(np.nanpercentile(finite, 2))
    vmax = float(np.nanpercentile(finite, 98))
    crop_extent = crop_extent_from_mask(ref_mask, rasters[0][2])

    cmap = plt.get_cmap("YlOrBr").copy()
    cmap.set_bad("white")

    fig, axes = plt.subplots(3, 3, figsize=(10.6, 5.35), constrained_layout=False)
    fig.subplots_adjust(left=0.006, right=0.902, bottom=0.012, top=0.992, wspace=0.006, hspace=0.006)
    fig.patch.set_facecolor("white")
    axes = axes.ravel()
    letters = "abcdefghi"
    im = None

    for i, (year, arr, bounds) in enumerate(rasters):
        ax = axes[i]
        ax.set_facecolor("white")
        im = ax.imshow(
            arr,
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
            extent=[bounds.left, bounds.right, bounds.bottom, bounds.top],
            origin="upper",
            interpolation="nearest",
        )
        ax.text(
            0.035,
            0.04,
            f"({letters[i]}) {year}",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=12,
            color="black",
            path_effects=[pe.withStroke(linewidth=3.2, foreground="white")],
        )
        ax.set_xlim(crop_extent[0], crop_extent[1])
        ax.set_ylim(crop_extent[2], crop_extent[3])
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    cax = fig.add_axes([0.925, 0.07, 0.024, 0.86])
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Estimated CDOM", rotation=90, labelpad=20)

    out_path = FIG_DIR / "04_longterm_cdom_spatial_panel_with_2026_lake_only.png"
    fig.savefig(out_path, facecolor="white", bbox_inches="tight", pad_inches=0.015)
    fig.savefig(
        FIG_DIR / "04_longterm_cdom_spatial_panel_with_2026.png",
        facecolor="white",
        bbox_inches="tight",
        pad_inches=0.015,
    )
    plt.close(fig)
    return out_path


def main() -> None:
    out_path = draw_lake_only_panel()
    print(out_path)


if __name__ == "__main__":
    main()
