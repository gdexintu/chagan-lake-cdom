from __future__ import annotations

import json
import math
import re
from itertools import combinations, permutations
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from scipy import stats
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, VotingRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, KFold, cross_val_predict, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from xgboost import XGBRegressor


BASE_DIR = Path(__file__).resolve().parent
SAMPLES_PATH = BASE_DIR / "outputs" / "cdom_2020" / "complete_ml_pipeline" / "01_clean_stratified_samples.csv"
INPUT_DIRS = [BASE_DIR / "gee_exports_cross_sensor", BASE_DIR / "gee_exports"]
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "cross_sensor_longterm"
FIG_DIR = OUT_DIR / "figures"
RASTER_DIR = OUT_DIR / "rasters"
MODEL_DIR = OUT_DIR / "models"
TABLE_DIR = OUT_DIR / "tables"

for path in [*INPUT_DIRS, OUT_DIR, FIG_DIR, RASTER_DIR, MODEL_DIR, TABLE_DIR]:
    path.mkdir(parents=True, exist_ok=True)

TARGET_COL = "mean"
RANDOM_STATE = 42
TEST_SIZE = 0.30
EPS = 1e-6
CV_FOLDS = 5
PEARSON_PRESELECT_N = 50
VIF_THRESHOLD = 30.0
MIN_FEATURES_AFTER_VIF = 6
FINAL_FEATURE_RANGE = range(5, 13)
RELIEFF_NEIGHBORS = 10

COMMON_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"]
S2_TO_COMMON = {
    "Blue": "B2",
    "Green": "B3",
    "Red": "B4",
    "NIR": "B8",
    "SWIR1": "B11",
    "SWIR2": "B12",
}


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 240
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 13
    plt.rcParams["axes.labelsize"] = 11
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 9


def add_feature(features: Dict[str, np.ndarray], name: str, values: np.ndarray) -> None:
    if name in features:
        return
    values = np.asarray(values, dtype=float)
    finite = np.isfinite(values)
    if finite.sum() < 10:
        return
    if np.nanstd(values[finite]) == 0:
        return
    features[name] = values


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    band = {b: df[b].to_numpy(dtype=float) for b in COMMON_BANDS}
    features: Dict[str, np.ndarray] = {}

    for b in COMMON_BANDS:
        x = band[b]
        add_feature(features, b, x)
        add_feature(features, f"log_{b}", np.log(x + EPS))
        add_feature(features, f"sqrt_{b}", np.sqrt(np.clip(x, 0, None)))
        add_feature(features, f"inv_{b}", 1.0 / (x + EPS))

    add_feature(features, "NDWI_Green_NIR", (band["Green"] - band["NIR"]) / (band["Green"] + band["NIR"] + EPS))
    add_feature(features, "MNDWI_Green_SWIR1", (band["Green"] - band["SWIR1"]) / (band["Green"] + band["SWIR1"] + EPS))
    add_feature(features, "AWEI_nsh", 4 * (band["Green"] - band["SWIR1"]) - (0.25 * band["NIR"] + 2.75 * band["SWIR2"]))
    add_feature(features, "NDVI_NIR_Red", (band["NIR"] - band["Red"]) / (band["NIR"] + band["Red"] + EPS))
    add_feature(features, "NDTI_Red_Green", (band["Red"] - band["Green"]) / (band["Red"] + band["Green"] + EPS))
    add_feature(features, "Blue_Green_Ratio", band["Blue"] / (band["Green"] + EPS))
    add_feature(features, "Blue_Red_Ratio", band["Blue"] / (band["Red"] + EPS))
    add_feature(features, "Green_Red_Ratio", band["Green"] / (band["Red"] + EPS))
    add_feature(features, "(Blue+Green)/Red", (band["Blue"] + band["Green"]) / (band["Red"] + EPS))
    add_feature(features, "(Blue+Green)/NIR", (band["Blue"] + band["Green"]) / (band["NIR"] + EPS))
    add_feature(features, "(Blue+Green)/SWIR1", (band["Blue"] + band["Green"]) / (band["SWIR1"] + EPS))
    add_feature(features, "(Green-Red)/Blue", (band["Green"] - band["Red"]) / (band["Blue"] + EPS))
    add_feature(features, "Visible_mean", (band["Blue"] + band["Green"] + band["Red"]) / 3)
    add_feature(features, "Visible_to_NIR", (band["Blue"] + band["Green"] + band["Red"]) / (band["NIR"] + EPS))
    add_feature(features, "Visible_to_SWIR1", (band["Blue"] + band["Green"] + band["Red"]) / (band["SWIR1"] + EPS))

    for b1, b2 in permutations(COMMON_BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        ratio = (x1 + EPS) / (x2 + EPS)
        add_feature(features, f"{b1}/{b2}", ratio)
        add_feature(features, f"log({b1}/{b2})", np.log(ratio))
        add_feature(features, f"({b1}-{b2})/{b2}", (x1 - x2) / (x2 + EPS))
        add_feature(features, f"({b1}/{b2})^0.5", np.sqrt(np.clip(ratio, 0, None)))
        add_feature(features, f"({b1}/{b2})^1.5", np.power(np.clip(ratio, 0, None), 1.5))

    for b1, b2 in combinations(COMMON_BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        add_feature(features, f"NDI_{b1}_{b2}", (x1 - x2) / (x1 + x2 + EPS))
        add_feature(features, f"Diff_{b1}_{b2}", x1 - x2)
        add_feature(features, f"Sum_{b1}_{b2}", x1 + x2)
        add_feature(features, f"Product_{b1}_{b2}", x1 * x2)

    for b1, b2, b3 in permutations(COMMON_BANDS, 3):
        x1 = band[b1]
        x2 = band[b2]
        x3 = band[b3]
        add_feature(features, f"({b1}-{b2})/{b3}", (x1 - x2) / (x3 + EPS))
        add_feature(features, f"{b1}/({b2}+{b3})", x1 / (x2 + x3 + EPS))
        add_feature(features, f"({b1}+{b2})/{b3}", (x1 + x2) / (x3 + EPS))
        add_feature(features, f"log(({b1}+{b2})/{b3})", np.log((x1 + x2 + EPS) / (x3 + EPS)))

    out = pd.DataFrame(features).replace([np.inf, -np.inf], np.nan)
    out = out.loc[:, out.notna().sum(axis=0) >= int(0.95 * len(out))]
    out = out.fillna(out.median(numeric_only=True))
    return out


def safe_corr(x: np.ndarray, y: np.ndarray, method: str = "pearson") -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 5 or np.nanstd(x[mask]) == 0:
        return 0.0
    if method == "spearman":
        return float(stats.spearmanr(x[mask], y[mask]).statistic)
    return float(stats.pearsonr(x[mask], y[mask]).statistic)


def correlation_table(X: pd.DataFrame, y: np.ndarray) -> pd.DataFrame:
    rows = []
    for col in X.columns:
        pr = safe_corr(X[col].to_numpy(dtype=float), y, "pearson")
        sr = safe_corr(X[col].to_numpy(dtype=float), y, "spearman")
        rows.append({"feature": col, "pearson_r": pr, "pearson_abs": abs(pr), "spearman_r": sr, "spearman_abs": abs(sr)})
    return pd.DataFrame(rows).sort_values(["pearson_abs", "spearman_abs"], ascending=False)


def calculate_vif(X: pd.DataFrame, features: Sequence[str]) -> pd.DataFrame:
    rows = []
    for feature in features:
        others = [f for f in features if f != feature]
        if not others:
            rows.append({"feature": feature, "vif": 1.0})
            continue
        model = LinearRegression()
        model.fit(X[others], X[feature])
        r2 = model.score(X[others], X[feature])
        vif = math.inf if r2 >= 0.999999 else 1.0 / max(1.0 - r2, EPS)
        rows.append({"feature": feature, "vif": float(vif)})
    return pd.DataFrame(rows).sort_values("vif", ascending=False)


def vif_filter(X: pd.DataFrame, candidates: List[str]) -> Tuple[List[str], pd.DataFrame, pd.DataFrame]:
    current = list(dict.fromkeys(candidates))
    before = calculate_vif(X, current)
    while len(current) > MIN_FEATURES_AFTER_VIF:
        vif = calculate_vif(X, current)
        if float(vif.iloc[0]["vif"]) <= VIF_THRESHOLD:
            break
        current.remove(str(vif.iloc[0]["feature"]))
    after = calculate_vif(X, current)
    return current, before, after


def relieff_scores(X: pd.DataFrame, y: np.ndarray, n_neighbors: int = RELIEFF_NEIGHBORS) -> pd.DataFrame:
    values = X.to_numpy(dtype=float)
    scaled = (values - np.nanmin(values, axis=0)) / (np.nanmax(values, axis=0) - np.nanmin(values, axis=0) + EPS)
    y_scaled = (y - np.nanmin(y)) / (np.nanmax(y) - np.nanmin(y) + EPS)
    from sklearn.neighbors import NearestNeighbors

    nn = NearestNeighbors(n_neighbors=min(n_neighbors + 1, len(X))).fit(scaled)
    _, inds = nn.kneighbors(scaled)
    scores = np.zeros(scaled.shape[1], dtype=float)
    for i in range(len(X)):
        neigh = inds[i, 1:]
        dy = np.abs(y_scaled[i] - y_scaled[neigh])
        dx = np.abs(scaled[i] - scaled[neigh])
        scores += np.mean(dx * dy[:, None], axis=0) - np.mean(dx * (1 - dy)[:, None], axis=0)
    scores /= len(X)
    return pd.DataFrame({"feature": X.columns, "relieff_score": scores}).sort_values("relieff_score", ascending=False)


def regression_metrics(y_true: np.ndarray, pred: np.ndarray) -> Dict[str, float]:
    return {
        "r2": float(r2_score(y_true, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, pred))),
        "mae": float(mean_absolute_error(y_true, pred)),
        "mape_percent": float(np.mean(np.abs((y_true - pred) / np.maximum(np.abs(y_true), EPS))) * 100),
    }


def load_training_data() -> Tuple[pd.DataFrame, np.ndarray]:
    if not SAMPLES_PATH.exists():
        raise FileNotFoundError("Run cdom_complete_ml_pipeline.py first to create cleaned Sentinel-2 samples.")
    samples = pd.read_csv(SAMPLES_PATH)
    common = pd.DataFrame({name: samples[src].astype(float) for name, src in S2_TO_COMMON.items()})
    valid = common.notna().all(axis=1) & samples[TARGET_COL].notna()
    return common.loc[valid].reset_index(drop=True), samples.loc[valid, TARGET_COL].to_numpy(dtype=float)


def model_grid() -> Dict[str, Tuple[object, Dict[str, list]]]:
    return {
        "RF": (
            RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True),
            {
                "n_estimators": [500, 900],
                "max_depth": [4, 6, None],
                "min_samples_leaf": [2, 3, 5],
                "max_features": ["sqrt", 0.7],
            },
        ),
        "ExtraTrees": (
            ExtraTreesRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True),
            {
                "n_estimators": [500, 900],
                "max_depth": [4, 6, None],
                "min_samples_leaf": [2, 3, 5],
                "max_features": ["sqrt", 0.7],
            },
        ),
        "XGBoost": (
            XGBRegressor(random_state=RANDOM_STATE, objective="reg:squarederror", n_jobs=-1),
            {
                "n_estimators": [120, 240],
                "max_depth": [2, 3],
                "learning_rate": [0.03, 0.05],
                "subsample": [0.8, 1.0],
                "colsample_bytree": [0.7, 1.0],
                "reg_lambda": [1.0, 5.0],
            },
        ),
        "SVR": (
            Pipeline([("scaler", StandardScaler()), ("svr", SVR())]),
            {
                "svr__C": [1, 3, 10, 30],
                "svr__gamma": ["scale", 0.1, 0.3],
                "svr__epsilon": [0.05, 0.1, 0.2],
            },
        ),
    }


def tune_models(X_train: pd.DataFrame, y_train: np.ndarray, cv: KFold) -> Dict[str, object]:
    fitted: Dict[str, object] = {}
    tuning_rows = []
    for name, (model, grid) in model_grid().items():
        search = GridSearchCV(model, grid, cv=cv, scoring="r2", n_jobs=-1, refit=True)
        search.fit(X_train, y_train)
        fitted[name] = search.best_estimator_
        tuning_rows.append({"model": name, "best_cv_r2": search.best_score_, "best_params": json.dumps(search.best_params_, ensure_ascii=False)})
    pd.DataFrame(tuning_rows).to_csv(TABLE_DIR / "05_model_tuning_summary.csv", index=False, encoding="utf-8-sig")
    return fitted


def choose_features_and_train() -> Tuple[Dict[str, object], List[str], Dict[str, float]]:
    common, y = load_training_data()
    features = build_features(common)
    features.to_csv(TABLE_DIR / "01_common_band_feature_matrix.csv", index=False, encoding="utf-8-sig")

    train_idx, test_idx = train_test_split(np.arange(len(y)), test_size=TEST_SIZE, random_state=RANDOM_STATE)
    X_train_all = features.iloc[train_idx].reset_index(drop=True)
    X_test_all = features.iloc[test_idx].reset_index(drop=True)
    y_train = y[train_idx]
    y_test = y[test_idx]

    train_corr = correlation_table(X_train_all, y_train)
    all_corr = correlation_table(features, y)
    train_corr.to_csv(TABLE_DIR / "02_train_common_feature_correlations.csv", index=False, encoding="utf-8-sig")
    all_corr.to_csv(TABLE_DIR / "02_all_common_feature_correlations.csv", index=False, encoding="utf-8-sig")

    candidates = train_corr.head(PEARSON_PRESELECT_N)["feature"].tolist()
    vif_features, vif_before, vif_after = vif_filter(X_train_all, candidates)
    vif_before.to_csv(TABLE_DIR / "03_vif_before.csv", index=False, encoding="utf-8-sig")
    vif_after.to_csv(TABLE_DIR / "04_vif_after.csv", index=False, encoding="utf-8-sig")

    relief = relieff_scores(X_train_all[vif_features], y_train)
    relief.to_csv(TABLE_DIR / "04b_relieff_ranking.csv", index=False, encoding="utf-8-sig")

    cv = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    feature_trials = []
    best_score = -np.inf
    best_features: List[str] = []
    best_models: Dict[str, object] = {}
    best_metrics: pd.DataFrame | None = None
    best_pred_tables: Dict[str, pd.DataFrame] = {}

    for n_features in FINAL_FEATURE_RANGE:
        selected = relief.head(min(n_features, len(relief)))["feature"].tolist()
        X_train = X_train_all[selected]
        X_test = X_test_all[selected]
        models = tune_models(X_train, y_train, cv)

        estimators = [(name, model) for name, model in models.items() if name in ["RF", "ExtraTrees", "XGBoost"]]
        if len(estimators) >= 2:
            ensemble = VotingRegressor(estimators=estimators, n_jobs=-1)
            ensemble.fit(X_train, y_train)
            models["TreeEnsemble"] = ensemble

        rows = []
        pred_tables: Dict[str, pd.DataFrame] = {}
        for name, model in models.items():
            pred_train = model.predict(X_train)
            pred_test = model.predict(X_test)
            row = {"model": name, "n_features": len(selected)}
            row.update({f"train_{k}": v for k, v in regression_metrics(y_train, pred_train).items()})
            row.update({f"test_{k}": v for k, v in regression_metrics(y_test, pred_test).items()})
            row["oob_r2"] = float(getattr(model, "oob_score_", np.nan))
            rows.append(row)
            pred_tables[name] = pd.DataFrame({"y_true": y_test, "y_pred": pred_test})
        metrics_df = pd.DataFrame(rows).sort_values(["test_r2", "test_rmse"], ascending=[False, True])

        cv_rows = []
        for name, model in models.items():
            pred = cross_val_predict(clone(model), features[selected], y, cv=cv, n_jobs=-1)
            row = {"model": name, "n_features": len(selected)}
            row.update({f"cv_{k}": v for k, v in regression_metrics(y, pred).items()})
            cv_rows.append(row)
        cv_df = pd.DataFrame(cv_rows).sort_values(["cv_r2", "cv_rmse"], ascending=[False, True])
        cv_score = float(cv_df.iloc[0]["cv_r2"])
        feature_trials.append(
            {
                "n_features": len(selected),
                "best_test_model": metrics_df.iloc[0]["model"],
                "best_test_r2": metrics_df.iloc[0]["test_r2"],
                "best_cv_model": cv_df.iloc[0]["model"],
                "best_cv_r2": cv_score,
                "features": "; ".join(selected),
            }
        )
        if cv_score > best_score:
            best_score = cv_score
            best_features = selected
            best_models = models
            best_metrics = metrics_df
            best_pred_tables = pred_tables
            cv_df.to_csv(TABLE_DIR / "08_5fold_cv_metrics.csv", index=False, encoding="utf-8-sig")

    pd.DataFrame(feature_trials).to_csv(TABLE_DIR / "06_feature_count_trials.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame({"feature": best_features}).to_csv(TABLE_DIR / "07_final_cross_sensor_features.csv", index=False, encoding="utf-8-sig")
    assert best_metrics is not None
    best_metrics.to_csv(TABLE_DIR / "09_holdout_model_metrics.csv", index=False, encoding="utf-8-sig")

    X_all = features[best_features]
    final_models = {name: clone(model).fit(X_all, y) for name, model in best_models.items()}
    for name, model in final_models.items():
        joblib.dump(model, MODEL_DIR / f"{name}_cross_sensor_model.joblib")

    best_name = str(best_metrics.iloc[0]["model"])
    best_model = best_models[best_name]
    perm = permutation_importance(best_model, X_test_all[best_features], y_test, n_repeats=40, random_state=RANDOM_STATE, scoring="r2", n_jobs=-1)
    perm_df = pd.DataFrame({"feature": best_features, "importance_mean": perm.importances_mean, "importance_std": perm.importances_std}).sort_values("importance_mean", ascending=False)
    perm_df.to_csv(TABLE_DIR / f"10_{best_name}_permutation_importance.csv", index=False, encoding="utf-8-sig")

    plot_training_outputs(best_metrics, best_pred_tables, perm_df)

    summary = {
        "model_note": "Cross-sensor long-term model uses Landsat/Sentinel common bands only. It is recommended for temporal consistency, not for maximum single-year Sentinel-2 accuracy.",
        "common_bands": COMMON_BANDS,
        "s2_to_common": S2_TO_COMMON,
        "final_features": best_features,
        "holdout_metrics": best_metrics.to_dict(orient="records"),
        "training_samples": int(len(y)),
    }
    with open(OUT_DIR / "cross_sensor_model_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    return final_models, best_features, summary


def plot_training_outputs(metrics_df: pd.DataFrame, pred_tables: Dict[str, pd.DataFrame], perm_df: pd.DataFrame) -> None:
    setup_plot_style()
    data = metrics_df.sort_values("test_r2", ascending=False)
    fig, ax = plt.subplots(figsize=(8, 4.6))
    bars = ax.bar(data["model"], data["test_r2"], color="#4c78a8")
    ax.set_ylabel("Holdout R²")
    ax.set_title("Cross-sensor Model Comparison")
    ax.grid(axis="y", alpha=0.25)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01, f"{bar.get_height():.3f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01_cross_sensor_model_r2.png")
    plt.close(fig)

    models = data["model"].tolist()
    ncols = min(3, len(models))
    nrows = math.ceil(len(models) / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(5.0 * ncols, 4.5 * nrows), squeeze=False)
    y_min = min(pred_tables[m]["y_true"].min() for m in models)
    y_max = max(pred_tables[m]["y_true"].max() for m in models)
    for ax, model_name in zip(axes.ravel(), models):
        pred = pred_tables[model_name]
        ax.scatter(pred["y_true"], pred["y_pred"], s=36, alpha=0.82, color="#4c78a8", edgecolor="white", linewidth=0.4)
        ax.plot([y_min, y_max], [y_min, y_max], ls="--", color="#d62728", lw=1.8)
        row = data[data["model"] == model_name].iloc[0]
        ax.set_title(f"{model_name}: R²={row['test_r2']:.3f}, RMSE={row['test_rmse']:.3f}")
        ax.set_xlabel("Reference CDOM product")
        ax.set_ylabel("Predicted CDOM")
        ax.grid(alpha=0.25)
    for ax in axes.ravel()[len(models):]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "02_cross_sensor_prediction_scatter.png")
    plt.close(fig)

    plot_df = perm_df.iloc[::-1]
    fig, ax = plt.subplots(figsize=(8.5, max(4.5, 0.38 * len(plot_df) + 1.2)))
    ax.barh(plot_df["feature"], plot_df["importance_mean"], xerr=plot_df["importance_std"], color="#59a14f", alpha=0.9)
    ax.set_xlabel("Mean decrease in R²")
    ax.set_title("Permutation Importance of Cross-sensor Model")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "03_cross_sensor_permutation_importance.png")
    plt.close(fig)


def year_from_path(path: Path) -> int | None:
    match = re.search(r"(19|20)\d{2}", path.name)
    return int(match.group(0)) if match else None


def read_common_band_raster(path: Path) -> Tuple[Dict[str, np.ndarray], np.ndarray, dict]:
    with rasterio.open(path) as src:
        names = [desc if desc else "" for desc in src.descriptions]
        if all(b in names for b in COMMON_BANDS):
            band_arrays = {b: src.read(names.index(b) + 1).astype("float32") for b in COMMON_BANDS}
        else:
            band_arrays = {b: src.read(i + 1).astype("float32") for i, b in enumerate(COMMON_BANDS)}
        profile = src.profile.copy()

    stack = np.stack([band_arrays[b] for b in COMMON_BANDS])
    valid = np.isfinite(stack).all(axis=0)
    valid &= np.nanmin(stack, axis=0) > 0
    valid &= np.nanmax(stack, axis=0) < 1
    return band_arrays, valid, profile


def predict_rasters(models: Dict[str, object], selected_features: Sequence[str]) -> None:
    best_name = pick_best_model_name()
    model = models[best_name]
    samples = pd.read_csv(SAMPLES_PATH)
    y_clip = (float(samples[TARGET_COL].quantile(0.005)), float(samples[TARGET_COL].quantile(0.995)))

    tif_files: List[Path] = []
    for directory in INPUT_DIRS:
        tif_files.extend(sorted(directory.glob("*.tif")))
        tif_files.extend(sorted(directory.glob("*.tiff")))
    tif_files = sorted(set(tif_files))
    if not tif_files:
        print("\nNo GEE GeoTIFF files found yet.")
        print("Put GEE exports into D:\\codex\\gee_exports_cross_sensor or D:\\codex\\gee_exports, then rerun this script.")
        return

    stats_rows = []
    for path in tif_files:
        year = year_from_path(path)
        if year is None:
            continue
        band_arrays, valid, profile = read_common_band_raster(path)
        pred = np.full(valid.shape, np.nan, dtype="float32")
        if valid.sum() > 0:
            flat = {b: band_arrays[b][valid].astype(float) for b in COMMON_BANDS}
            feature_frame = build_features(pd.DataFrame(flat))
            missing = [f for f in selected_features if f not in feature_frame.columns]
            if missing:
                raise ValueError(f"Missing raster features in {path.name}: {missing}")
            values = model.predict(feature_frame[list(selected_features)])
            values = np.clip(values, y_clip[0], y_clip[1])
            pred[valid] = values.astype("float32")

        out_path = RASTER_DIR / f"ChaganLake_CDOM_{best_name}_{year}_JunSep.tif"
        profile.update(count=1, dtype="float32", nodata=np.nan, compress="deflate")
        with rasterio.open(out_path, "w", **profile) as dst:
            dst.write(pred, 1)
            dst.update_tags(year=str(year), source_file=path.name, model=best_name)

        finite = pred[np.isfinite(pred)]
        stats_rows.append(
            {
                "year": year,
                "source_file": path.name,
                "output_file": out_path.name,
                "model": best_name,
                "valid_pixels": int(len(finite)),
                "mean_cdom": float(np.nanmean(finite)) if len(finite) else np.nan,
                "median_cdom": float(np.nanmedian(finite)) if len(finite) else np.nan,
                "std_cdom": float(np.nanstd(finite)) if len(finite) else np.nan,
                "min_cdom": float(np.nanmin(finite)) if len(finite) else np.nan,
                "max_cdom": float(np.nanmax(finite)) if len(finite) else np.nan,
            }
        )

    if stats_rows:
        stats_df = pd.DataFrame(stats_rows).sort_values("year")
        stats_df.to_csv(TABLE_DIR / "11_longterm_cdom_raster_stats.csv", index=False, encoding="utf-8-sig")
        make_longterm_figures(stats_df)


def pick_best_model_name() -> str:
    metrics = pd.read_csv(TABLE_DIR / "09_holdout_model_metrics.csv")
    return str(metrics.sort_values(["test_r2", "test_rmse"], ascending=[False, True]).iloc[0]["model"])


def make_longterm_figures(stats_df: pd.DataFrame) -> None:
    setup_plot_style()
    rasters = []
    for _, row in stats_df.sort_values("year").iterrows():
        path = RASTER_DIR / row["output_file"]
        with rasterio.open(path) as src:
            arr = src.read(1).astype(float)
            bounds = src.bounds
        rasters.append((int(row["year"]), arr, bounds))
    finite = np.concatenate([arr[np.isfinite(arr)] for _, arr, _ in rasters if np.isfinite(arr).any()])
    vmin = float(np.nanpercentile(finite, 2))
    vmax = float(np.nanpercentile(finite, 98))

    ncols = 3
    nrows = math.ceil(len(rasters) / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(11.0, 3.6 * nrows), constrained_layout=True)
    axes = np.atleast_1d(axes).ravel()
    letters = "abcdefghijklmnopqrstuvwxyz"
    im = None
    for i, (year, arr, bounds) in enumerate(rasters):
        ax = axes[i]
        im = ax.imshow(arr, cmap="YlOrBr", vmin=vmin, vmax=vmax, extent=[bounds.left, bounds.right, bounds.bottom, bounds.top], origin="upper")
        ax.set_title(f"({letters[i]}) {year}", loc="left", fontsize=12)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)
    for ax in axes[len(rasters):]:
        ax.axis("off")
    if im is not None:
        cbar = fig.colorbar(im, ax=axes[: len(rasters)], shrink=0.82, location="bottom", pad=0.04)
        cbar.set_label("Predicted CDOM")
    fig.savefig(FIG_DIR / "04_longterm_cdom_spatial_panel.png")
    plt.close(fig)

    data = stats_df.sort_values("year")
    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    ax.plot(data["year"], data["mean_cdom"], marker="o", lw=2.2, color="#a6611a", label="Mean")
    ax.fill_between(
        data["year"].to_numpy(dtype=float),
        (data["mean_cdom"] - data["std_cdom"]).to_numpy(dtype=float),
        (data["mean_cdom"] + data["std_cdom"]).to_numpy(dtype=float),
        color="#dfc27d",
        alpha=0.28,
        linewidth=0,
        label="Mean ± SD",
    )
    ax.set_xlabel("Year")
    ax.set_ylabel("Predicted CDOM")
    ax.set_title("Chagan Lake Jun-Sep CDOM Long-term Change")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "05_longterm_cdom_time_series.png")
    plt.close(fig)


def main() -> None:
    models, selected_features, summary = choose_features_and_train()
    predict_rasters(models, selected_features)
    metrics = pd.read_csv(TABLE_DIR / "09_holdout_model_metrics.csv")
    cv = pd.read_csv(TABLE_DIR / "08_5fold_cv_metrics.csv")
    print("Cross-sensor long-term model finished.")
    print("\nFinal features:")
    print(pd.Series(selected_features).to_string(index=False))
    print("\nHoldout metrics:")
    print(metrics[["model", "n_features", "test_r2", "test_rmse", "test_mae", "test_mape_percent"]].to_string(index=False))
    print("\n5-fold CV metrics:")
    print(cv[["model", "n_features", "cv_r2", "cv_rmse", "cv_mae", "cv_mape_percent"]].to_string(index=False))
    print(f"\nOutputs saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
