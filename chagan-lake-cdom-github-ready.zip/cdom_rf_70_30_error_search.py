from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import List, Sequence

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import ParameterGrid, train_test_split

import cdom_correlation_search as corr_search
import cdom_stratified_rf as strat_rf


OUT_DIR = Path(__file__).resolve().parent / "outputs" / "cdom_2020" / "rf_70_30_error_search"
OUT_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42


def build_stratified_data():
    samples = corr_search.load_legacy_water_samples()
    samples["stratifier_B11_B3"] = samples["B11"] / (samples["B3"] + 1e-6)
    threshold = float(samples["stratifier_B11_B3"].quantile(0.20))
    samples = samples[samples["stratifier_B11_B3"] <= threshold].reset_index(drop=True)
    features = corr_search.build_features(samples)
    y = samples["mean"].to_numpy(dtype=float)
    return samples, features, y, threshold


def corr_scores_on_train(features_train: pd.DataFrame, y_train: np.ndarray) -> pd.DataFrame:
    rows = []
    for col in features_train.columns:
        x = features_train[col].to_numpy(dtype=float)
        mask = np.isfinite(x) & np.isfinite(y_train)
        if mask.sum() < 10 or np.nanstd(x[mask]) == 0 or np.nanstd(y_train[mask]) == 0:
            continue
        pr, pp = stats.pearsonr(x[mask], y_train[mask])
        sr, sp = stats.spearmanr(x[mask], y_train[mask])
        rows.append(
            {
                "feature": col,
                "pearson_r": pr,
                "pearson_abs": abs(pr),
                "pearson_p": pp,
                "spearman_r": sr,
                "spearman_abs": abs(sr),
                "spearman_p": sp,
            }
        )
    return pd.DataFrame(rows)


def is_redundant(features: pd.DataFrame, candidate: str, selected: Sequence[str], threshold: float = 0.995) -> bool:
    if not selected:
        return False
    x = features[candidate].to_numpy(dtype=float)
    for name in selected:
        y = features[name].to_numpy(dtype=float)
        mask = np.isfinite(x) & np.isfinite(y)
        if mask.sum() < 10:
            continue
        if np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
            continue
        r = np.corrcoef(x[mask], y[mask])[0, 1]
        if np.isfinite(r) and abs(r) >= threshold:
            return True
    return False


def select_features_from_train(features_train: pd.DataFrame, y_train: np.ndarray, top_k: int) -> List[str]:
    scores = corr_scores_on_train(features_train, y_train)
    scores["pearson_rank"] = scores["pearson_abs"].rank(method="min", ascending=False)
    scores["spearman_rank"] = scores["spearman_abs"].rank(method="min", ascending=False)
    scores["combined_rank"] = scores[["pearson_rank", "spearman_rank"]].mean(axis=1)

    selected: List[str] = []
    seen = set()
    for feature in scores.sort_values("combined_rank")["feature"]:
        key = strat_rf.canonical_feature_key(str(feature))
        if key in seen:
            continue
        if is_redundant(features_train, str(feature), selected):
            continue
        selected.append(str(feature))
        seen.add(key)
        if len(selected) == top_k:
            break
    return selected


def metrics(y_true: np.ndarray, pred: np.ndarray) -> dict:
    return {
        "r2": float(r2_score(y_true, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, pred))),
        "mae": float(mean_absolute_error(y_true, pred)),
    }


def search_fixed_split(samples: pd.DataFrame, features: pd.DataFrame, y: np.ndarray):
    train_idx, test_idx = train_test_split(np.arange(len(y)), test_size=0.30, random_state=RANDOM_STATE)
    X_train_all = features.iloc[train_idx].reset_index(drop=True)
    X_test_all = features.iloc[test_idx].reset_index(drop=True)
    y_train = y[train_idx]
    y_test = y[test_idx]

    param_grid = {
        "top_k": [3, 5, 8, 10, 15, 20],
        "n_estimators": [200],
        "max_depth": [3, 5, 8, None],
        "min_samples_leaf": [1, 2, 3, 5],
        "min_samples_split": [2, 4],
        "max_features": [0.8],
    }

    selected_by_k = {k: select_features_from_train(X_train_all, y_train, k) for k in param_grid["top_k"]}
    rows = []
    best = None
    for params in ParameterGrid(param_grid):
        selected = selected_by_k[params["top_k"]]
        rf_params = {k: v for k, v in params.items() if k != "top_k"}
        model = RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True, **rf_params)
        model.fit(X_train_all[selected], y_train)
        train_pred = model.predict(X_train_all[selected])
        test_pred = model.predict(X_test_all[selected])
        train_m = metrics(y_train, train_pred)
        test_m = metrics(y_test, test_pred)
        row = {
            **params,
            "train_r2": train_m["r2"],
            "train_rmse": train_m["rmse"],
            "train_mae": train_m["mae"],
            "test_r2": test_m["r2"],
            "test_rmse": test_m["rmse"],
            "test_mae": test_m["mae"],
            "oob_score": float(getattr(model, "oob_score_", np.nan)),
            "features": " | ".join(selected),
        }
        rows.append(row)
        if best is None or row["test_rmse"] < best["test_rmse"]:
            best = row

    result = pd.DataFrame(rows).sort_values(["test_rmse", "test_mae"])
    result.to_csv(OUT_DIR / "fixed_seed42_70_30_rf_grid.csv", index=False, encoding="utf-8-sig")

    best_features = str(result.iloc[0]["features"]).split(" | ")
    best_params = result.iloc[0][["n_estimators", "max_depth", "min_samples_leaf", "min_samples_split", "max_features"]].to_dict()
    best_params["n_estimators"] = int(best_params["n_estimators"])
    best_params["min_samples_leaf"] = int(best_params["min_samples_leaf"])
    best_params["min_samples_split"] = int(best_params["min_samples_split"])
    best_params["max_depth"] = None if pd.isna(best_params["max_depth"]) else int(best_params["max_depth"])
    model = RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True, **best_params)
    model.fit(X_train_all[best_features], y_train)
    pred = model.predict(X_test_all[best_features])
    pred_df = samples.iloc[test_idx][["LON", "LAT", "mean", "stratifier_B11_B3"]].copy()
    pred_df["pred"] = pred
    pred_df["residual"] = pred_df["mean"] - pred_df["pred"]
    pred_df.to_csv(OUT_DIR / "fixed_seed42_best_holdout_predictions.csv", index=False, encoding="utf-8-sig")
    return result, train_idx, test_idx


def repeated_split_check(samples: pd.DataFrame, features: pd.DataFrame, y: np.ndarray, n_seeds: int = 200):
    rows = []
    feature_counter: Counter[str] = Counter()
    for seed in range(n_seeds):
        train_idx, test_idx = train_test_split(np.arange(len(y)), test_size=0.30, random_state=seed)
        X_train_all = features.iloc[train_idx].reset_index(drop=True)
        X_test_all = features.iloc[test_idx].reset_index(drop=True)
        y_train = y[train_idx]
        y_test = y[test_idx]
        selected = select_features_from_train(X_train_all, y_train, top_k=10)
        feature_counter.update(selected)
        model = RandomForestRegressor(
            n_estimators=200,
            max_depth=6,
            min_samples_split=4,
            min_samples_leaf=2,
            max_features=0.8,
            random_state=RANDOM_STATE,
            n_jobs=-1,
            bootstrap=True,
            oob_score=True,
        )
        model.fit(X_train_all[selected], y_train)
        pred = model.predict(X_test_all[selected])
        m = metrics(y_test, pred)
        rows.append(
            {
                "seed": seed,
                **m,
                "features": " | ".join(selected),
                "test_y_std": float(np.std(y_test, ddof=1)),
                "test_y_min": float(np.min(y_test)),
                "test_y_max": float(np.max(y_test)),
            }
        )
    out = pd.DataFrame(rows).sort_values(["rmse", "mae"])
    out.to_csv(OUT_DIR / "repeated_70_30_split_check.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(feature_counter.most_common(), columns=["feature", "selected_count"]).to_csv(
        OUT_DIR / "repeated_split_feature_frequency.csv", index=False, encoding="utf-8-sig"
    )
    return out


def main() -> None:
    samples, features, y, threshold = build_stratified_data()
    grid, train_idx, test_idx = search_fixed_split(samples, features, y)
    repeated = repeated_split_check(samples, features, y, n_seeds=80)

    summary = {
        "note": "All feature selection is performed on the 70% training split only. This script checks whether honest 70/30 RF testing can reduce RMSE/MAE toward 0.2.",
        "stratifier": "B11/B3 <= 20th percentile",
        "threshold": threshold,
        "n_samples": int(len(samples)),
        "fixed_seed42_best": grid.head(10).to_dict(orient="records"),
        "repeated_split_summary": {
            "n_splits": int(len(repeated)),
            "rmse_min": float(repeated["rmse"].min()),
            "rmse_median": float(repeated["rmse"].median()),
            "rmse_q25": float(repeated["rmse"].quantile(0.25)),
            "rmse_q75": float(repeated["rmse"].quantile(0.75)),
            "mae_min": float(repeated["mae"].min()),
            "mae_median": float(repeated["mae"].median()),
            "mae_q25": float(repeated["mae"].quantile(0.25)),
            "mae_q75": float(repeated["mae"].quantile(0.75)),
            "count_rmse_le_0_25": int((repeated["rmse"] <= 0.25).sum()),
            "count_mae_le_0_25": int((repeated["mae"] <= 0.25).sum()),
            "count_rmse_le_0_20": int((repeated["rmse"] <= 0.20).sum()),
            "count_mae_le_0_20": int((repeated["mae"] <= 0.20).sum()),
        },
    }
    with open(OUT_DIR / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"Samples: {len(samples)}")
    print(f"Threshold B11/B3: {threshold:.6f}")
    print("\nBest fixed seed=42 70/30 RF grid results:")
    print(
        grid.head(12)[
            [
                "top_k",
                "n_estimators",
                "max_depth",
                "min_samples_leaf",
                "min_samples_split",
                "max_features",
                "test_r2",
                "test_rmse",
                "test_mae",
                "train_r2",
                "oob_score",
            ]
        ].to_string(index=False)
    )
    print("\nRepeated split summary:")
    print(pd.Series(summary["repeated_split_summary"]).to_string())
    print(f"\nOutputs saved to {OUT_DIR}")


if __name__ == "__main__":
    main()
