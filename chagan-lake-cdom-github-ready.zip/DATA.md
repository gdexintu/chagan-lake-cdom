# Data Notes

This repository does not include raw raster datasets, local virtual environments, generated model outputs, or manuscript files. These files are excluded to keep the GitHub repository lightweight and to avoid publishing local/private artifacts.

## Expected Local File Layout

Place the required input data in the project root or the expected subdirectories:

```text
D:\codex
├── CDOM_Extracted_2020.csv
├── S2_2020_AllBands_Median.tif
├── gee_exports/
│   ├── ChaganLake_harmonized_SR_1986_JunSep.tif
│   ├── ChaganLake_harmonized_SR_1991_JunSep.tif
│   ├── ChaganLake_harmonized_SR_1996_JunSep.tif
│   ├── ChaganLake_harmonized_SR_2001_JunSep.tif
│   ├── ChaganLake_harmonized_SR_2006_JunSep.tif
│   ├── ChaganLake_harmonized_SR_2011_JunSep.tif
│   ├── ChaganLake_harmonized_SR_2016_JunSep.tif
│   ├── ChaganLake_harmonized_SR_2021_JunSep.tif
│   └── ChaganLake_harmonized_SR_2026_to_20260516.tif
└── outputs/
```

## Input Files

### `CDOM_Extracted_2020.csv`

The `mean` column is used as the target variable. It is not an in-situ CDOM measurement. It is an extracted mean value from a public CDOM remote-sensing product.

Recommended interpretation:

- correct: public CDOM product reconstruction
- correct: CDOM proxy mapping
- incorrect: field-measured CDOM inversion

### `S2_2020_AllBands_Median.tif`

Sentinel-2 image stack containing bands B1-B12 and quality layers used by the 2020 workflow. Reflectance values are scaled in the scripts before feature construction.

### `gee_exports/`

Google Earth Engine exported Landsat/Sentinel common-band composites used for long-term mapping. The complete historical sequence uses June-September composites from 1986 to 2021. The 2026 raster is a partial-year composite available up to 2026-05-16 and should not be interpreted as a complete summer mean.

## Generated Outputs

Generated figures, tables, model outputs, rasters, and manuscript drafts are written under:

```text
outputs/
```

This directory is ignored by Git because it can contain many large files and intermediate products.

## Google Earth Engine Scripts

Use the scripts in `gee_scripts/` to regenerate exported rasters from GEE. The exports should be downloaded into `gee_exports/` before running the long-term Python workflow.

