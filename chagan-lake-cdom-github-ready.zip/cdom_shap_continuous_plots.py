from __future__ import annotations

from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap


BASE_DIR = Path(__file__).resolve().parent
PIPELINE_DIR = BASE_DIR / "outputs" / "cdom_2020" / "complete_ml_pipeline"
FIG_DIR = PIPELINE_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 240
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 14
    plt.rcParams["axes.labelsize"] = 11
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 10


def kernel_smooth(x: np.ndarray, y: np.ndarray, grid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    span = np.nanmax(x) - np.nanmin(x)
    bandwidth = span * 0.18 if span > 0 else 1.0
    smooth = []
    spread = []
    for gx in grid:
        w = np.exp(-0.5 * ((x - gx) / bandwidth) ** 2)
        w_sum = w.sum()
        if w_sum <= 0:
            smooth.append(np.nan)
            spread.append(np.nan)
            continue
        mu = np.sum(w * y) / w_sum
        var = np.sum(w * (y - mu) ** 2) / w_sum
        smooth.append(mu)
        spread.append(np.sqrt(var))
    return np.asarray(smooth), np.asarray(spread)


def make_continuous_shap_plots() -> None:
    setup_plot_style()

    model = joblib.load(PIPELINE_DIR / "models" / "RF_model.joblib")
    data = pd.read_csv(PIPELINE_DIR / "08_final_feature_dataset.csv")
    features = pd.read_csv(PIPELINE_DIR / "07_final_model_features.csv")["feature"].tolist()
    X = data[features].copy()

    explainer = shap.Explainer(model, X)
    shap_values = explainer(X)
    values = np.asarray(shap_values.values, dtype=float)
    base_value = float(np.ravel(shap_values.base_values)[0]) if np.ndim(shap_values.base_values) else float(shap_values.base_values)
    pred = model.predict(X)

    importance = pd.DataFrame(
        {
            "feature": features,
            "mean_abs_shap": np.abs(values).mean(axis=0),
        }
    ).sort_values("mean_abs_shap", ascending=False)
    ordered = importance["feature"].tolist()
    order_idx = [features.index(f) for f in ordered]
    ordered_values = values[:, order_idx]

    # 1. Violin summary: smooth density instead of isolated beeswarm points.
    fig, ax = plt.subplots(figsize=(9, 5.5))
    parts = ax.violinplot(
        [ordered_values[:, i] for i in range(ordered_values.shape[1])],
        vert=False,
        showmeans=False,
        showmedians=True,
        widths=0.82,
    )
    for body in parts["bodies"]:
        body.set_facecolor("#7b68ee")
        body.set_edgecolor("#4c3fb3")
        body.set_alpha(0.68)
    for key in ["cmedians", "cbars", "cmins", "cmaxes"]:
        if key in parts:
            parts[key].set_color("#333333")
            parts[key].set_linewidth(1.0)
    ax.axvline(0, color="#888888", lw=1.4, ls="--")
    ax.set_yticks(np.arange(1, len(ordered) + 1))
    ax.set_yticklabels(ordered)
    ax.set_xlabel("SHAP value (impact on model output)")
    ax.set_title("SHAP Value Distribution (RF, all samples)")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "15b_shap_violin_summary_all_samples.png")
    plt.close(fig)

    # 2. Heatmap sorted by model prediction.
    sort_idx = np.argsort(pred)
    heat = ordered_values[sort_idx, :].T
    vmax = np.nanpercentile(np.abs(heat), 98)
    fig, ax = plt.subplots(figsize=(10, 4.8))
    im = ax.imshow(heat, aspect="auto", cmap="coolwarm", vmin=-vmax, vmax=vmax)
    ax.set_yticks(np.arange(len(ordered)))
    ax.set_yticklabels(ordered)
    ax.set_xlabel("Samples sorted by RF predicted CDOM")
    ax.set_title("Continuous SHAP Heatmap (RF, all samples)")
    cbar = fig.colorbar(im, ax=ax, pad=0.015)
    cbar.set_label("SHAP value")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "15c_shap_heatmap_all_samples.png")
    plt.close(fig)

    # 3. Smooth feature-effect curves.
    n = len(ordered)
    ncols = 2
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(12, 4.2 * nrows))
    axes = np.ravel(axes)
    for ax, feature in zip(axes, ordered):
        idx = features.index(feature)
        x = X[feature].to_numpy(dtype=float)
        y = values[:, idx]
        grid = np.linspace(np.nanmin(x), np.nanmax(x), 180)
        smooth, spread = kernel_smooth(x, y, grid)
        ax.scatter(x, y, s=24, alpha=0.32, color="#4c78a8", edgecolor="white", linewidth=0.25)
        ax.plot(grid, smooth, color="#d62728", lw=2.2, label="kernel-smoothed SHAP")
        ax.fill_between(grid, smooth - 0.35 * spread, smooth + 0.35 * spread, color="#d62728", alpha=0.13, linewidth=0)
        ax.axhline(0, color="#888888", lw=1, ls="--")
        ax.set_xlabel(feature)
        ax.set_ylabel("SHAP value")
        ax.set_title(f"SHAP Effect Curve: {feature}")
        ax.grid(alpha=0.22)
    for ax in axes[n:]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "16b_shap_smooth_effect_curves.png")
    plt.close(fig)

    # 4. Prediction decomposition as continuous stacked lines after sorting by prediction.
    cumulative = np.cumsum(heat, axis=0)
    fig, ax = plt.subplots(figsize=(10, 5.3))
    x_axis = np.arange(len(sort_idx))
    bottom = np.zeros(len(sort_idx)) + base_value
    colors = ["#4c78a8", "#f58518", "#54a24b", "#e45756", "#72b7b2", "#b279a2"]
    for i, feature in enumerate(ordered):
        contrib = heat[i]
        ax.plot(x_axis, bottom + contrib, lw=1.2, color=colors[i % len(colors)], alpha=0.85, label=feature)
        bottom = bottom + contrib
    ax.plot(x_axis, pred[sort_idx], color="#111111", lw=2.2, label="RF prediction")
    ax.set_xlabel("Samples sorted by RF predicted CDOM")
    ax.set_ylabel("CDOM / cumulative contribution")
    ax.set_title("SHAP Contributions Along Sorted Predictions")
    ax.grid(alpha=0.22)
    ax.legend(frameon=False, ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "16c_shap_continuous_contribution_lines.png")
    plt.close(fig)

    print("Generated continuous SHAP-style figures:")
    print(FIG_DIR / "15b_shap_violin_summary_all_samples.png")
    print(FIG_DIR / "15c_shap_heatmap_all_samples.png")
    print(FIG_DIR / "16b_shap_smooth_effect_curves.png")
    print(FIG_DIR / "16c_shap_continuous_contribution_lines.png")


if __name__ == "__main__":
    make_continuous_shap_plots()
