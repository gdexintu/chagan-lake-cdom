from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, cross_val_predict, cross_val_score, train_test_split

import cdom_correlation_search as corr_search


BASE_DIR = Path(__file__).resolve().parent
TIF_PATH = BASE_DIR / "S2_2020_AllBands_Median.tif"
if not TIF_PATH.exists():
    TIF_PATH = BASE_DIR / "lunwen" / "PythonProject1" / "S2_2020_AllBands_Median.tif"

OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "stratified_rf"
FIG_DIR = OUT_DIR / "figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

BANDS = corr_search.BANDS
ALL_BAND_NAMES = corr_search.ALL_BAND_NAMES
EPS = 1e-6
RANDOM_STATE = 42
BLOCK_SIZE = 512


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 200
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False


def safe_corr(x: np.ndarray, y: np.ndarray, method: str) -> Tuple[float, float, int]:
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < 10 or np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
        return np.nan, np.nan, n
    if method == "pearson":
        r, p = stats.pearsonr(x[mask], y[mask])
    else:
        r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), n


def correlation_table(features: pd.DataFrame, y: np.ndarray) -> pd.DataFrame:
    rows = []
    for name in features.columns:
        x = features[name].to_numpy(dtype=float)
        pr, pp, n = safe_corr(x, y, "pearson")
        sr, sp, _ = safe_corr(x, y, "spearman")
        rows.append(
            {
                "feature": name,
                "pearson_r": pr,
                "pearson_abs": abs(pr) if np.isfinite(pr) else np.nan,
                "pearson_p": pp,
                "spearman_r": sr,
                "spearman_abs": abs(sr) if np.isfinite(sr) else np.nan,
                "spearman_p": sp,
                "n": n,
            }
        )
    return pd.DataFrame(rows)


def canonical_feature_key(name: str) -> str:
    """Collapse exact commutative duplicates such as (B2+B3)/B5 and (B3+B2)/B5."""
    m = re.fullmatch(r"\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, b, c = m.groups()
        left = "+".join(sorted([a, b]))
        return f"({left})/{c}"
    m = re.fullmatch(r"log\(\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)\)", name)
    if m:
        a, b, c = m.groups()
        left = "+".join(sorted([a, b]))
        return f"log(({left})/{c})"
    m = re.fullmatch(r"(B\d+A?|B\d+)/\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)", name)
    if m:
        a, b, c = m.groups()
        denom = "+".join(sorted([b, c]))
        return f"{a}/({denom})"
    m = re.fullmatch(r"\((B\d+A?|B\d+)-(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, b, c = m.groups()
        diff = "-".join(sorted([a, b]))
        return f"absdiff({diff})/{c}"
    return name


def top_unique(df: pd.DataFrame, metric_col: str, n: int = 10) -> pd.DataFrame:
    seen = set()
    rows = []
    for _, row in df.sort_values(metric_col, ascending=False).iterrows():
        key = canonical_feature_key(str(row["feature"]))
        if key in seen:
            continue
        seen.add(key)
        rows.append(row)
        if len(rows) == n:
            break
    return pd.DataFrame(rows)


def is_redundant_feature(features: pd.DataFrame, candidate: str, selected: Sequence[str], threshold: float = 0.995) -> bool:
    if not selected:
        return False
    x = features[candidate].to_numpy(dtype=float)
    for chosen in selected:
        y = features[chosen].to_numpy(dtype=float)
        mask = np.isfinite(x) & np.isfinite(y)
        if mask.sum() < 10:
            continue
        if np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
            continue
        r = np.corrcoef(x[mask], y[mask])[0, 1]
        if np.isfinite(r) and abs(r) >= threshold:
            return True
    return False


def select_combined_top10(corr_df: pd.DataFrame, features: pd.DataFrame, top_pearson: pd.DataFrame, top_spearman: pd.DataFrame) -> List[str]:
    ranked = corr_df.copy()
    ranked["pearson_rank"] = ranked["pearson_abs"].rank(method="min", ascending=False)
    ranked["spearman_rank"] = ranked["spearman_abs"].rank(method="min", ascending=False)
    ranked["combined_rank"] = ranked[["pearson_rank", "spearman_rank"]].mean(axis=1)

    candidates = pd.concat([top_pearson, top_spearman, ranked.sort_values("combined_rank").head(200)], ignore_index=True)
    feature_to_score = ranked.set_index("feature")["combined_rank"].to_dict()
    candidates["combined_rank"] = candidates["feature"].map(feature_to_score)
    candidates = candidates.sort_values("combined_rank")

    selected: List[str] = []
    seen = set()
    for feature in candidates["feature"]:
        key = canonical_feature_key(str(feature))
        if key in seen:
            continue
        if is_redundant_feature(features, str(feature), selected):
            continue
        selected.append(str(feature))
        seen.add(key)
        if len(selected) == 10:
            break
    return selected


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    r, p, _ = safe_corr(np.asarray(y_pred), np.asarray(y_true), "pearson")
    return {
        "r2": float(r2_score(y_true, y_pred)),
        "rmse": float(math.sqrt(mean_squared_error(y_true, y_pred))),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "pearson_r": float(r),
        "pearson_p": float(p),
    }


def plot_top_bars(top_df: pd.DataFrame, metric_col: str, title: str, output: Path) -> None:
    setup_plot_style()
    data = top_df.iloc[::-1].copy()
    fig, ax = plt.subplots(figsize=(9, 5.8))
    colors = np.where(data[metric_col.replace("_abs", "_r")] >= 0, "#4c78a8", "#e45756")
    ax.barh(data["feature"], data[metric_col], color=colors)
    ax.set_xlabel(f"|{metric_col.replace('_abs', '')}|")
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.25)
    for i, value in enumerate(data[metric_col]):
        ax.text(value + 0.006, i, f"{value:.3f}", va="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(output)
    plt.close(fig)


def plot_scatter_for_top(features: pd.DataFrame, y: np.ndarray, feature: str, output: Path, title_prefix: str) -> None:
    setup_plot_style()
    x = features[feature].to_numpy(dtype=float)
    r, p, n = safe_corr(x, y, "pearson")
    sr, sp, _ = safe_corr(x, y, "spearman")
    fig, ax = plt.subplots(figsize=(6.5, 5.2))
    ax.scatter(x, y, s=28, alpha=0.78, color="#1f77b4", edgecolor="white", linewidth=0.35)
    coef = np.polyfit(x, y, 1)
    xx = np.linspace(np.nanmin(x), np.nanmax(x), 100)
    ax.plot(xx, coef[0] * xx + coef[1], color="#d62728", lw=2)
    ax.set_xlabel(feature)
    ax.set_ylabel("Reference CDOM product")
    ax.set_title(f"{title_prefix}: r={r:.3f}, rho={sr:.3f}, n={n}")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output)
    plt.close(fig)


def train_rf(samples: pd.DataFrame, features: pd.DataFrame, selected: Sequence[str]):
    X = features[list(selected)].copy()
    y = samples["mean"].to_numpy(dtype=float)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=RANDOM_STATE)
    model = RandomForestRegressor(
        n_estimators=500,
        max_depth=8,
        min_samples_split=4,
        min_samples_leaf=3,
        max_features=0.8,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        bootstrap=True,
        oob_score=True,
    )
    model.fit(X_train, y_train)
    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)

    cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    cv_pred = cross_val_predict(model, X, y, cv=cv, n_jobs=-1)
    cv_scores = cross_val_score(model, X, y, cv=cv, scoring="r2", n_jobs=-1)

    final_model = RandomForestRegressor(**model.get_params())
    final_model.fit(X, y)

    metrics = {
        "n_samples": int(len(samples)),
        "n_features": int(len(selected)),
        "train": regression_metrics(y_train, train_pred),
        "test": regression_metrics(y_test, test_pred),
        "random_5fold": regression_metrics(y, cv_pred),
        "random_5fold_r2_scores": [float(v) for v in cv_scores],
        "oob_score": float(getattr(model, "oob_score_", np.nan)),
    }

    pred_df = pd.DataFrame(
        {
            "obs": y_test,
            "pred": test_pred,
            "residual": y_test - test_pred,
        }
    )
    cv_pred_df = samples[["LON", "LAT", "mean", "stratifier_B11_B3"]].copy()
    cv_pred_df["cv_pred"] = cv_pred
    cv_pred_df["cv_residual"] = cv_pred_df["mean"] - cv_pred_df["cv_pred"]

    importance = pd.DataFrame(
        {"feature": list(selected), "importance": final_model.feature_importances_}
    ).sort_values("importance", ascending=False)
    return final_model, metrics, pred_df, cv_pred_df, importance


def plot_rf_outputs(pred_df: pd.DataFrame, importance: pd.DataFrame) -> None:
    setup_plot_style()

    fig, ax = plt.subplots(figsize=(5.7, 5.5))
    ax.scatter(pred_df["obs"], pred_df["pred"], s=30, alpha=0.8, color="#4c78a8", edgecolor="white", linewidth=0.35)
    low = min(pred_df["obs"].min(), pred_df["pred"].min())
    high = max(pred_df["obs"].max(), pred_df["pred"].max())
    ax.plot([low, high], [low, high], "--", color="#d62728", lw=1.6)
    ax.set_xlabel("Reference CDOM product")
    ax.set_ylabel("RF predicted CDOM")
    ax.set_title("Stratified RF holdout validation")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "04_rf_holdout_observed_vs_predicted.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    data = importance.iloc[::-1]
    ax.barh(data["feature"], data["importance"], color="#59a14f")
    ax.set_xlabel("Feature importance")
    ax.set_title("RF feature importance: selected top-10 indices")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "05_rf_feature_importance.png")
    plt.close(fig)


def read_reflectance_block(src: rasterio.io.DatasetReader, band_indexes: Dict[str, int], band: str, window: Window) -> np.ndarray:
    return src.read(band_indexes[band], window=window, out_dtype="float32") / 10000.0


def compute_feature_array(name: str, b: Dict[str, np.ndarray]) -> np.ndarray:
    if name in BANDS:
        return b[name]
    if name.startswith("log_"):
        return np.log(b[name.replace("log_", "")] + EPS)
    if name.startswith("sqrt_"):
        return np.sqrt(np.clip(b[name.replace("sqrt_", "")], 0, None))
    if name.startswith("inv_"):
        return 1.0 / (b[name.replace("inv_", "")] + EPS)

    m = re.fullmatch(r"(B\d+A?|B\d+)/(B\d+A?|B\d+)", name)
    if m:
        a, c = m.groups()
        return (b[a] + EPS) / (b[c] + EPS)

    m = re.fullmatch(r"log\((B\d+A?|B\d+)/(B\d+A?|B\d+)\)", name)
    if m:
        a, c = m.groups()
        return np.log((b[a] + EPS) / (b[c] + EPS))

    m = re.fullmatch(r"\((B\d+A?|B\d+)/(B\d+A?|B\d+)\)\^([0-9.]+)", name)
    if m:
        a, c, p = m.groups()
        return np.power(np.clip((b[a] + EPS) / (b[c] + EPS), 0, None), float(p))

    m = re.fullmatch(r"\((B\d+A?|B\d+)-(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, c, d = m.groups()
        return (b[a] - b[c]) / (b[d] + EPS)

    m = re.fullmatch(r"\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, c, d = m.groups()
        return (b[a] + b[c]) / (b[d] + EPS)

    m = re.fullmatch(r"log\(\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)\)", name)
    if m:
        a, c, d = m.groups()
        return np.log((b[a] + b[c] + EPS) / (b[d] + EPS))

    m = re.fullmatch(r"(B\d+A?|B\d+)/\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)", name)
    if m:
        a, c, d = m.groups()
        return b[a] / (b[c] + b[d] + EPS)

    m = re.fullmatch(r"(B\d+A?|B\d+)-([0-9.]+)\*(B\d+A?|B\d+)", name)
    if m:
        a, k, c = m.groups()
        return b[a] - float(k) * b[c]

    m = re.fullmatch(r"([0-9.]+)\*(B\d+A?|B\d+)-(B\d+A?|B\d+)", name)
    if m:
        k, a, c = m.groups()
        return float(k) * b[a] - b[c]

    if name.startswith("NDI_"):
        _, a, c = name.split("_")
        return (b[a] - b[c]) / (b[a] + b[c] + EPS)
    if name.startswith("Diff_"):
        _, a, c = name.split("_")
        return b[a] - b[c]
    if name.startswith("Sum_"):
        _, a, c = name.split("_")
        return b[a] + b[c]
    if name.startswith("Product_"):
        _, a, c = name.split("_")
        return b[a] * b[c]
    if name.startswith("ConstRatio_"):
        _, a, c, const = name.split("_")
        const_f = float(const)
        return (b[a] + const_f) / (b[c] + const_f)
    if name.startswith("ConstNDI_"):
        _, a, c, const = name.split("_")
        const_f = float(const)
        return (b[a] - b[c]) / (b[a] + b[c] + const_f)
    if name.startswith("TriNDI_"):
        _, a, c, d = name.split("_")
        return (b[a] - b[c]) / (b[a] + b[c] - 2 * b[d] + EPS)
    if name.startswith("3B_"):
        _, a, c, d = name.split("_")
        return (1.0 / (b[a] + EPS) - 1.0 / (b[c] + EPS)) * b[d]

    raise ValueError(f"Unsupported feature expression for raster prediction: {name}")


def needed_bands(selected: Sequence[str]) -> List[str]:
    needed = set()
    for feature in selected:
        for band in BANDS:
            if re.search(rf"(?<![A-Z0-9]){re.escape(band)}(?![A-Z0-9])", feature):
                needed.add(band)
    needed.update(["B11", "B3"])
    return sorted(needed, key=BANDS.index)


def predict_stratified_raster(model: RandomForestRegressor, selected: Sequence[str], threshold: float) -> Path:
    output = OUT_DIR / "ChaganLake_CDOM_RF_2020_low_B11_B3_stratum.tif"
    nodata = -9999.0
    required_bands = needed_bands(selected)

    with rasterio.open(TIF_PATH) as src:
        names = [d if d else ALL_BAND_NAMES[i] for i, d in enumerate(src.descriptions)]
        band_indexes = {name: i + 1 for i, name in enumerate(names)}
        profile = src.profile.copy()
        profile.update(
            count=1,
            dtype="float32",
            nodata=nodata,
            compress="deflate",
            predictor=2,
            tiled=True,
            blockxsize=256,
            blockysize=256,
        )

        with rasterio.open(output, "w", **profile) as dst:
            for row in range(0, src.height, BLOCK_SIZE):
                height = min(BLOCK_SIZE, src.height - row)
                for col in range(0, src.width, BLOCK_SIZE):
                    width = min(BLOCK_SIZE, src.width - col)
                    window = Window(col, row, width, height)
                    arrays = {band: read_reflectance_block(src, band_indexes, band, window) for band in required_bands}
                    valid = np.ones((height, width), dtype=bool)
                    for arr in arrays.values():
                        valid &= np.isfinite(arr) & (arr >= 0.0) & (arr <= 1.2)

                    if "SCL" in band_indexes:
                        scl = src.read(band_indexes["SCL"], window=window, out_dtype="float32")
                        valid &= np.rint(scl).astype(np.int16) == 6
                    valid &= arrays["B11"] / (arrays["B3"] + EPS) <= threshold

                    feature_arrays = []
                    for feature in selected:
                        vals = compute_feature_array(feature, arrays).astype("float32")
                        feature_arrays.append(vals)
                        valid &= np.isfinite(vals)

                    out = np.full((height, width), nodata, dtype="float32")
                    if valid.any():
                        X_block = pd.DataFrame(np.stack(feature_arrays, axis=-1)[valid], columns=list(selected))
                        out[valid] = model.predict(X_block).astype("float32")
                    dst.write(out, 1, window=window)
    return output


def plot_map_preview(raster_path: Path) -> None:
    setup_plot_style()
    with rasterio.open(raster_path) as src:
        scale = max(1, math.ceil(max(src.width, src.height) / 1200))
        arr = src.read(1, out_shape=(1, src.height // scale, src.width // scale), masked=True)
        bounds = src.bounds
        nodata = src.nodata
    data = np.ma.masked_where(np.asarray(arr) == nodata, arr)
    finite = data.compressed()
    vmin, vmax = (np.percentile(finite, 2), np.percentile(finite, 98)) if finite.size else (0, 1)
    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(data, extent=[bounds.left, bounds.right, bounds.bottom, bounds.top], origin="upper", cmap="viridis", vmin=vmin, vmax=vmax)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Stratified RF CDOM prediction: low B11/B3 water")
    fig.colorbar(im, ax=ax, label="Reference-CDOM-fitted value")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "06_stratified_rf_map_preview.png")
    plt.close(fig)


def main() -> None:
    samples = corr_search.load_legacy_water_samples()
    samples["stratifier_B11_B3"] = samples["B11"] / (samples["B3"] + EPS)
    threshold = float(samples["stratifier_B11_B3"].quantile(0.20))
    stratified = samples[samples["stratifier_B11_B3"] <= threshold].copy().reset_index(drop=True)
    stratified.to_csv(OUT_DIR / "stratified_low_B11_B3_samples.csv", index=False, encoding="utf-8-sig")

    features = corr_search.build_features(stratified)
    y = stratified["mean"].to_numpy(dtype=float)
    corr_df = correlation_table(features, y)
    corr_df.sort_values(["pearson_abs", "spearman_abs"], ascending=False).to_csv(
        OUT_DIR / "stratified_all_index_correlations.csv", index=False, encoding="utf-8-sig"
    )

    top_pearson = top_unique(corr_df, "pearson_abs", 10)
    top_spearman = top_unique(corr_df, "spearman_abs", 10)
    top_pearson.to_csv(OUT_DIR / "top10_pearson_indices.csv", index=False, encoding="utf-8-sig")
    top_spearman.to_csv(OUT_DIR / "top10_spearman_indices.csv", index=False, encoding="utf-8-sig")

    selected = select_combined_top10(corr_df, features, top_pearson, top_spearman)
    selected_df = corr_df[corr_df["feature"].isin(selected)].copy()
    selected_df["selected_order"] = selected_df["feature"].map({name: i + 1 for i, name in enumerate(selected)})
    selected_df.sort_values("selected_order").to_csv(OUT_DIR / "rf_selected_top10_features.csv", index=False, encoding="utf-8-sig")

    top_feature_cols = ["LON", "LAT", "mean", "stratifier_B11_B3"] + list(selected)
    top10_dataset = pd.concat([stratified[["LON", "LAT", "mean", "stratifier_B11_B3"]], features[selected]], axis=1)
    top10_dataset.to_csv(OUT_DIR / "stratified_low_B11_B3_top10_feature_dataset.csv", index=False, encoding="utf-8-sig")

    plot_top_bars(top_pearson, "pearson_abs", "Top 10 Pearson spectral indices in low B11/B3 stratum", FIG_DIR / "01_top10_pearson_indices.png")
    plot_top_bars(top_spearman, "spearman_abs", "Top 10 Spearman spectral indices in low B11/B3 stratum", FIG_DIR / "02_top10_spearman_indices.png")
    plot_scatter_for_top(features, y, top_pearson.iloc[0]["feature"], FIG_DIR / "03_best_index_scatter.png", "Best Pearson index")

    model, metrics, pred_df, cv_pred_df, importance = train_rf(stratified, features, selected)
    pred_df.to_csv(OUT_DIR / "rf_holdout_predictions.csv", index=False, encoding="utf-8-sig")
    cv_pred_df.to_csv(OUT_DIR / "rf_5fold_predictions.csv", index=False, encoding="utf-8-sig")
    importance.to_csv(OUT_DIR / "rf_feature_importance.csv", index=False, encoding="utf-8-sig")
    plot_rf_outputs(pred_df, importance)

    joblib.dump(model, OUT_DIR / "stratified_rf_model.joblib")
    raster_path = predict_stratified_raster(model, selected, threshold)
    plot_map_preview(raster_path)

    summary = {
        "method_note": "The model is trained and applied only to the low B11/B3 optical stratum. It fits a public reference CDOM remote-sensing product, not field measurements.",
        "stratifier": "B11/B3",
        "threshold_quantile": 0.20,
        "threshold": threshold,
        "n_stratified_samples": int(len(stratified)),
        "top10_pearson": top_pearson.to_dict(orient="records"),
        "top10_spearman": top_spearman.to_dict(orient="records"),
        "rf_selected_features": selected,
        "rf_metrics": metrics,
        "raster_output": str(raster_path),
    }
    with open(OUT_DIR / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    with rasterio.open(raster_path) as src:
        arr = src.read(1, masked=True)
        valid_pixels = int(arr.count())
        raster_stats = {
            "valid_pixels": valid_pixels,
            "min": float(arr.min()) if valid_pixels else None,
            "mean": float(arr.mean()) if valid_pixels else None,
            "max": float(arr.max()) if valid_pixels else None,
        }

    print(f"Stratified samples: {len(stratified)}")
    print(f"B11/B3 threshold: {threshold:.6f}")
    print("\nTop 10 Pearson:")
    print(top_pearson[["feature", "pearson_r", "pearson_abs", "spearman_r", "n"]].to_string(index=False))
    print("\nTop 10 Spearman:")
    print(top_spearman[["feature", "spearman_r", "spearman_abs", "pearson_r", "n"]].to_string(index=False))
    print("\nRF selected features:")
    print(pd.DataFrame({"feature": selected}).to_string(index=False))
    print("\nRF metrics:")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print("\nRaster stats:")
    print(json.dumps(raster_stats, ensure_ascii=False, indent=2))
    print(f"\nOutputs saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
