from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import rasterio
from matplotlib.collections import PatchCollection
from matplotlib.patches import Polygon, Rectangle


BASE_DIR = Path(r"D:\codex")
GEOJSON_PATH = BASE_DIR / "china_provinces_datav.json"
RASTER_PATH = BASE_DIR / "outputs" / "cdom_2020" / "ChaganLake_CDOM_RF_2020.tif"
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "figures"
OUT_PATH = OUT_DIR / "00_integrated_study_area_cdom_2020.png"

CHAGAN_LON = 124.25
CHAGAN_LAT = 45.28


def setup_style() -> None:
    plt.rcParams["figure.dpi"] = 150
    plt.rcParams["savefig.dpi"] = 300
    plt.rcParams["font.sans-serif"] = [
        "Microsoft YaHei",
        "SimHei",
        "Arial Unicode MS",
        "DejaVu Sans",
    ]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.linewidth"] = 0.8


def load_features() -> list[dict]:
    with GEOJSON_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)["features"]


def geometry_to_patches(geometry: dict) -> list[Polygon]:
    patches: list[Polygon] = []
    gtype = geometry["type"]
    coords = geometry["coordinates"]
    if gtype == "Polygon":
        polygons = [coords]
    elif gtype == "MultiPolygon":
        polygons = coords
    else:
        return patches
    for poly in polygons:
        if not poly:
            continue
        exterior = np.asarray(poly[0], dtype=float)
        if exterior.ndim == 2 and exterior.shape[0] >= 3:
            patches.append(Polygon(exterior, closed=True))
    return patches


def draw_provinces(ax, features, *, highlight_jilin: bool = False, extent=None) -> None:
    base_patches: list[Polygon] = []
    jilin_patches: list[Polygon] = []
    ne_names = {"黑龙江省", "吉林省", "辽宁省", "内蒙古自治区"}

    for feature in features:
        name = feature["properties"]["name"]
        patches = geometry_to_patches(feature["geometry"])
        if extent is not None and name not in ne_names:
            continue
        if highlight_jilin and name == "吉林省":
            jilin_patches.extend(patches)
        else:
            base_patches.extend(patches)

    ax.add_collection(
        PatchCollection(
            base_patches,
            facecolor="#fbfbf4" if extent is not None else "#ffffff",
            edgecolor="#222222",
            linewidth=0.45 if extent is None else 0.55,
            zorder=1,
        )
    )
    if jilin_patches:
        ax.add_collection(
            PatchCollection(
                jilin_patches,
                facecolor="#fff8cc",
                edgecolor="#ff3030",
                linewidth=1.15,
                zorder=3,
            )
        )

    if extent is not None:
        ax.set_xlim(*extent[:2])
        ax.set_ylim(*extent[2:])
    else:
        ax.set_xlim(73, 136)
        ax.set_ylim(17, 54)
    ax.set_aspect("equal", adjustable="box")


def draw_north_arrow(ax, x=0.94, y=0.91, size=0.065) -> None:
    ax.text(x, y + size * 0.72, "N", transform=ax.transAxes, ha="center", va="center", fontsize=9)
    ax.annotate(
        "",
        xy=(x, y + size * 0.55),
        xytext=(x, y - size * 0.52),
        xycoords=ax.transAxes,
        arrowprops=dict(arrowstyle="-|>", color="black", lw=0.9, mutation_scale=15),
    )
    ax.annotate(
        "",
        xy=(x + size * 0.26, y - size * 0.46),
        xytext=(x, y + size * 0.40),
        xycoords=ax.transAxes,
        arrowprops=dict(arrowstyle="-|>", color="#1f78b4", lw=0.75, mutation_scale=10),
    )


def draw_scale_bar(ax, lon0, lat0, km_values, fontsize=6.5) -> None:
    km_per_deg_lon = 111.32 * np.cos(np.deg2rad(lat0))
    x0 = lon0
    y0 = lat0
    height = 0.0055
    for i in range(len(km_values) - 1):
        x_start = x0 + km_values[i] / km_per_deg_lon
        x_end = x0 + km_values[i + 1] / km_per_deg_lon
        ax.plot([x_start, x_end], [y0, y0], color="black", lw=0.8, zorder=10)
        ax.plot([x_start, x_start], [y0 - height, y0 + height], color="black", lw=0.65, zorder=10)
    x_end = x0 + km_values[-1] / km_per_deg_lon
    ax.plot([x_end, x_end], [y0 - height, y0 + height], color="black", lw=0.65, zorder=10)
    for km in km_values:
        ax.text(x0 + km / km_per_deg_lon, y0 + 0.010, f"{km:g}", ha="center", va="bottom", fontsize=fontsize)
    ax.text(x_end + 0.015, y0 + 0.010, "km", ha="left", va="bottom", fontsize=fontsize)


def add_degree_ticks(ax, *, top=False, right=False, step_x=10, step_y=10, fontsize=8) -> None:
    ax.tick_params(
        labelsize=fontsize,
        direction="out",
        length=3,
        top=top,
        right=right,
        labeltop=top,
        labelright=right,
        labelbottom=not top,
        labelleft=not right,
    )
    ax.xaxis.set_major_formatter(lambda x, pos: f"{x:.0f}°E")
    ax.yaxis.set_major_formatter(lambda y, pos: f"{y:.0f}°N")


def draw_china_inset(ax, features) -> None:
    draw_provinces(ax, features, highlight_jilin=True)
    ax.scatter(CHAGAN_LON, CHAGAN_LAT, s=18, color="#d7191c", edgecolor="white", linewidth=0.5, zorder=6)
    ax.text(CHAGAN_LON - 8.0, CHAGAN_LAT + 1.0, "Chagan Lake", fontsize=5.8, color="#d7191c", zorder=7)
    draw_north_arrow(ax, x=0.94, y=0.83, size=0.065)
    add_degree_ticks(ax, top=True, right=False, fontsize=6.0)
    ax.set_xticks([80, 100, 120, 140])
    ax.set_yticks([20, 30, 40])
    ax.text(0.02, 0.965, "(a) China", transform=ax.transAxes, ha="left", va="top", fontsize=8.5, fontweight="bold")


def draw_ne_inset(ax, features) -> None:
    draw_provinces(ax, features, highlight_jilin=True, extent=(116.5, 135.5, 38.0, 54.2))
    ax.scatter(CHAGAN_LON, CHAGAN_LAT, s=24, color="#1f78b4", edgecolor="white", linewidth=0.6, zorder=6)
    ax.text(CHAGAN_LON + 0.35, CHAGAN_LAT - 0.55, "Chagan Lake", fontsize=6.5, color="#1f78b4")
    ax.text(126.6, 48.2, "Heilongjiang", fontsize=6.4, color="#555555", ha="center")
    ax.text(126.0, 43.7, "Jilin", fontsize=6.4, color="#555555", ha="center")
    ax.text(123.0, 41.0, "Liaoning", fontsize=6.4, color="#555555", ha="center")
    draw_north_arrow(ax, x=0.93, y=0.82, size=0.065)
    add_degree_ticks(ax, top=False, right=False, fontsize=6.0)
    ax.set_xticks([120, 125, 130, 135])
    ax.set_yticks([40, 45, 50])
    ax.text(0.02, 0.965, "(b) Northeast China", transform=ax.transAxes, ha="left", va="top", fontsize=8.5, fontweight="bold")


def draw_main_cdom(ax) -> None:
    with rasterio.open(RASTER_PATH) as src:
        arr = src.read(1).astype("float32")
        bounds = src.bounds
        nodata = src.nodata

    mask = ~np.isfinite(arr)
    if nodata is not None:
        mask |= arr == nodata
    arr = np.ma.masked_where(mask, arr)
    cmap = plt.get_cmap("viridis").copy()
    cmap.set_bad("white")
    im = ax.imshow(
        arr,
        extent=[bounds.left, bounds.right, bounds.bottom, bounds.top],
        origin="upper",
        cmap=cmap,
        vmin=3.5,
        vmax=5.5,
        interpolation="nearest",
    )

    ax.set_xlim(bounds.left, bounds.right)
    ax.set_ylim(bounds.bottom, bounds.top)
    ax.set_aspect("auto")
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.text(
        0.02,
        0.97,
        "(c) RF fitted CDOM from Sentinel-2, 2020",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9.2,
        fontweight="bold",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=1.5),
    )
    ax.tick_params(labelsize=6.2, direction="out", top=True, right=True, labeltop=True, labelright=True, length=2.5)
    ax.xaxis.set_major_formatter(lambda x, pos: f"{x:.2f}°E")
    ax.yaxis.set_major_formatter(lambda y, pos: f"{y:.2f}°N")
    draw_north_arrow(ax, x=0.963, y=0.885, size=0.052)
    draw_scale_bar(ax, lon0=bounds.left + 0.020, lat0=bounds.bottom + 0.018, km_values=[0, 2.5, 5, 10], fontsize=6.5)
    return im


def make_figure() -> Path:
    setup_style()
    features = load_features()
    fig = plt.figure(figsize=(8.0, 5.55), facecolor="white")
    gs = fig.add_gridspec(
        2,
        2,
        width_ratios=[0.88, 1.12],
        height_ratios=[1, 1],
        left=0.055,
        right=0.975,
        bottom=0.075,
        top=0.955,
        wspace=0.025,
        hspace=0.025,
    )
    ax_china = fig.add_subplot(gs[0, 0])
    ax_ne = fig.add_subplot(gs[1, 0])
    ax_main = fig.add_subplot(gs[:, 1])

    draw_china_inset(ax_china, features)
    draw_ne_inset(ax_ne, features)
    im = draw_main_cdom(ax_main)

    cax = ax_main.inset_axes([0.585, 0.095, 0.32, 0.030])
    cax.set_facecolor("white")
    cbar = fig.colorbar(im, cax=cax, orientation="horizontal")
    cbar.set_label("CDOM value", fontsize=6.8, labelpad=1)
    cbar.ax.xaxis.set_label_position("top")
    cbar.ax.tick_params(labelsize=6, length=1.8)

    for ax in [ax_china, ax_ne, ax_main]:
        for spine in ax.spines.values():
            spine.set_linewidth(0.9)
            spine.set_color("black")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT_PATH, bbox_inches="tight", pad_inches=0.02, facecolor="white")
    plt.close(fig)
    return OUT_PATH


if __name__ == "__main__":
    print(make_figure())
