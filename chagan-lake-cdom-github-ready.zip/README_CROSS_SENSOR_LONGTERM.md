# 查干湖 CDOM 跨传感器长时序反演模型

## 为什么要新建跨传感器模型

原 Sentinel-2 模型精度较高，但使用了 Sentinel-2 独有红边信息，例如 `B5=705 nm`。
Landsat 5/7/8/9 没有等价红边波段，所以不能把原模型直接用于 1986-2014。

长时序分析建议使用一个跨传感器共通波段模型：

```text
Blue, Green, Red, NIR, SWIR1, SWIR2
```

这样牺牲部分单年精度，但保证 1986-2026 的时间可比性。

## GEE 脚本

推荐使用：

```text
D:\codex\gee_scripts\gee_chaganlake_cross_sensor_integrated_exports.js
```

它会导出每 5 年一次的 6-9 月季节中值影像：

```text
1986, 1991, 1996, 2001, 2006, 2011, 2016, 2021
```

当前日期是 2026-05-16，2026 年 6-9 月还未发生，不能生成完整 2026 年夏季合成影像。
2026-09-30 以后再加入 2026。

## GEE 预处理

Landsat：

- Landsat Collection 2 Level-2 Surface Reflectance；
- Tier 1 数据，降低几何配准误差；
- QA_PIXEL 去除云、云影、雪、填充值、膨胀云；
- QA_RADSAT 去除饱和像元；
- Landsat 8/9 使用 SR_QA_AEROSOL 去除高气溶胶像元。

Sentinel-2：

- COPERNICUS/S2_SR_HARMONIZED；
- SCL 去除云、云影、雪、卷云、无效像元；
- 共通波段重命名为 Blue、Green、Red、NIR、SWIR1、SWIR2；
- 统一以 30 m 导出。

共同处理：

- MNDWI / NDVI 水体掩膜；
- 6-9 月季节中值合成；
- 输出 `valid_count` 记录有效观测数量。

这些步骤是误差抑制，不是误差完全消除。

## 本地模型脚本

```text
D:\codex\cdom_cross_sensor_longterm_pipeline.py
```

运行：

```powershell
D:\codex\pytorch\Scripts\python.exe D:\codex\cdom_cross_sensor_longterm_pipeline.py
```

导出的 GEE GeoTIFF 放到任一目录：

```text
D:\codex\gee_exports_cross_sensor
D:\codex\gee_exports
```

脚本会自动：

1. 从已有 Sentinel-2 样本中提取共通波段训练数据；
2. 构建跨传感器候选特征；
3. Pearson + VIF + ReliefF 筛选；
4. 比较 RF / ExtraTrees / XGBoost / SVR / TreeEnsemble；
5. 保存最佳模型；
6. 对 GEE 导出的多年影像进行 CDOM 反演；
7. 绘制多年空间分布图和时间序列图。

## 当前模型结果

优化后的跨传感器模型当前最佳为 ExtraTrees：

```text
Holdout R²  = 0.668
Holdout RMSE = 0.483
Holdout MAE  = 0.379
5-fold CV R² = 0.651
5-fold CV RMSE = 0.530
```

最终特征：

```text
(Blue/NIR)^1.5
NIR/(Red+SWIR2)
NDI_Red_NIR
Blue/(NIR+Red)
log((SWIR1+Blue)/NIR)
Blue/(NIR+Green)
```

这个精度低于 Sentinel-2 红边模型，但更适合做 1986-2026 长时序趋势。

## 论文建议表述

建议写：

“为保证长时序跨传感器一致性，本文构建了基于 Landsat 与 Sentinel-2 共通波段的 CDOM 代理反演模型。模型牺牲了 Sentinel-2 红边波段带来的局部精度优势，但增强了 1986 年以来多源影像反演结果的可比性。”

不要写：

“1986-2026 全部使用 Sentinel-2 反演”。
