from __future__ import annotations

import json
from itertools import combinations, permutations
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
import rasterio
from scipy import stats


BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "CDOM_cleaned.csv"
if not CSV_PATH.exists():
    CSV_PATH = BASE_DIR / "lunwen" / "PythonProject1" / "CDOM_cleaned.csv"

TIF_PATH = BASE_DIR / "S2_2020_AllBands_Median.tif"
if not TIF_PATH.exists():
    TIF_PATH = BASE_DIR / "lunwen" / "PythonProject1" / "S2_2020_AllBands_Median.tif"

OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "correlation_search"
OUT_DIR.mkdir(parents=True, exist_ok=True)

BANDS = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
ALL_BAND_NAMES = BANDS + [
    "AOT",
    "WVP",
    "SCL",
    "TCI_R",
    "TCI_G",
    "TCI_B",
    "MSK_CLDPRB",
    "MSK_SNWPRB",
    "QA10",
    "QA20",
    "QA60",
    "MSK_CLASSI_OPAQUE",
    "MSK_CLASSI_CIRRUS",
    "MSK_CLASSI_SNOW_ICE",
]
EPS = 1e-6


def legacy_centroid(geo_str: str) -> Tuple[float, float]:
    """Reproduce the centroid method used in lunwen/PythonProject1/pearson.py."""
    try:
        geo = json.loads(geo_str)
        coords = geo["coordinates"][0]
        lons = [p[0] for p in coords]
        lats = [p[1] for p in coords]
        return sum(lons) / len(lons), sum(lats) / len(lats)
    except Exception:
        return np.nan, np.nan


def load_legacy_water_samples() -> pd.DataFrame:
    df = pd.read_csv(CSV_PATH, low_memory=False)
    centroids = df[".geo"].apply(legacy_centroid)
    df["LON"] = [c[0] for c in centroids]
    df["LAT"] = [c[1] for c in centroids]
    df = df.dropna(subset=["LON", "LAT", "mean"]).copy()

    with rasterio.open(TIF_PATH) as src:
        samples = np.array(list(src.sample(list(zip(df["LON"], df["LAT"])))), dtype=float)

    for i, band in enumerate(ALL_BAND_NAMES):
        df[band] = samples[:, i]

    for band in BANDS:
        df[band] = df[band] / 10000.0

    df = df[df["SCL"] == 6].copy()
    mean = df["mean"].mean()
    std = df["mean"].std()
    df = df[(df["mean"] >= mean - 3 * std) & (df["mean"] <= mean + 3 * std)].copy()
    return df.reset_index(drop=True)


def target_variants(y: pd.Series) -> Dict[str, np.ndarray]:
    arr = y.to_numpy(dtype=float)
    variants = {
        "raw": arr,
        "zscore": (arr - arr.mean()) / arr.std(ddof=1),
        "log": np.log(arr),
        "sqrt": np.sqrt(arr),
        "inverse": 1.0 / arr,
    }

    y_boxcox, lam = stats.boxcox(arr)
    variants[f"boxcox_lambda_{lam:.3f}"] = y_boxcox
    return variants


def add_feature(features: Dict[str, np.ndarray], name: str, values: np.ndarray) -> None:
    if name in features:
        return
    values = np.asarray(values, dtype=float)
    if np.isfinite(values).sum() < 10:
        return
    if np.nanstd(values) == 0:
        return
    features[name] = values


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    band = {b: df[b].to_numpy(dtype=float) for b in BANDS}
    features: Dict[str, np.ndarray] = {}

    for b in BANDS:
        x = band[b]
        add_feature(features, b, x)
        add_feature(features, f"log_{b}", np.log(x + EPS))
        add_feature(features, f"sqrt_{b}", np.sqrt(np.clip(x, 0, None)))
        add_feature(features, f"inv_{b}", 1.0 / (x + EPS))

    for b1, b2 in permutations(BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        ratio = (x1 + EPS) / (x2 + EPS)
        add_feature(features, f"{b1}/{b2}", ratio)
        add_feature(features, f"log({b1}/{b2})", np.log(ratio))
        for p in [0.5, 1.5, 2.0, 3.0]:
            add_feature(features, f"({b1}/{b2})^{p}", np.power(np.clip(ratio, 0, None), p))
        add_feature(features, f"({b1}-{b2})/{b2}", (x1 - x2) / (x2 + EPS))

    for b1, b2 in combinations(BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        add_feature(features, f"NDI_{b1}_{b2}", (x1 - x2) / (x1 + x2 + EPS))
        add_feature(features, f"Diff_{b1}_{b2}", x1 - x2)
        add_feature(features, f"Sum_{b1}_{b2}", x1 + x2)
        add_feature(features, f"Product_{b1}_{b2}", x1 * x2)
        for c in [0.001, 0.005, 0.01, 0.05, 0.1]:
            add_feature(features, f"ConstNDI_{b1}_{b2}_{c}", (x1 - x2) / (x1 + x2 + c))
            add_feature(features, f"ConstRatio_{b1}_{b2}_{c}", (x1 + c) / (x2 + c))
        for k in [0.25, 0.5, 0.75, 1.25, 1.5, 2.0, 3.0]:
            add_feature(features, f"{b1}-{k}*{b2}", x1 - k * x2)
            add_feature(features, f"{k}*{b1}-{b2}", k * x1 - x2)

    for b1, b2, b3 in permutations(BANDS, 3):
        x1 = band[b1]
        x2 = band[b2]
        x3 = band[b3]
        add_feature(features, f"({b1}-{b2})/{b3}", (x1 - x2) / (x3 + EPS))
        add_feature(features, f"{b1}/({b2}+{b3})", x1 / (x2 + x3 + EPS))
        add_feature(features, f"({b1}+{b2})/{b3}", (x1 + x2) / (x3 + EPS))
        add_feature(features, f"log(({b1}+{b2})/{b3})", np.log((x1 + x2 + EPS) / (x3 + EPS)))
        add_feature(features, f"TriNDI_{b1}_{b2}_{b3}", (x1 - x2) / (x1 + x2 - 2 * x3 + EPS))
        add_feature(features, f"3B_{b1}_{b2}_{b3}", (1.0 / (x1 + EPS) - 1.0 / (x2 + EPS)) * x3)

    out = pd.DataFrame(features).replace([np.inf, -np.inf], np.nan)
    out = out.loc[:, out.notna().sum(axis=0) >= int(0.95 * len(out))]
    return out


def corr_one(x: np.ndarray, y: np.ndarray, method: str) -> Tuple[float, float, int]:
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < 10 or np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
        return np.nan, np.nan, n
    if method == "pearson":
        r, p = stats.pearsonr(x[mask], y[mask])
    else:
        r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), n


def search_correlations(features: pd.DataFrame, targets: Dict[str, np.ndarray]) -> pd.DataFrame:
    rows: List[dict] = []
    for target_name, y in targets.items():
        for feature in features.columns:
            x = features[feature].to_numpy(dtype=float)
            pr, pp, n = corr_one(x, y, "pearson")
            sr, sp, _ = corr_one(x, y, "spearman")
            rows.append(
                {
                    "target": target_name,
                    "feature": feature,
                    "pearson_r": pr,
                    "pearson_abs": abs(pr) if np.isfinite(pr) else np.nan,
                    "pearson_p": pp,
                    "spearman_r": sr,
                    "spearman_abs": abs(sr) if np.isfinite(sr) else np.nan,
                    "spearman_p": sp,
                    "n": n,
                }
            )
    return pd.DataFrame(rows)


def optical_strata_report(df: pd.DataFrame, features: pd.DataFrame, best_feature: str) -> pd.DataFrame:
    """Only use spectral variables for stratification; do not use CDOM/residuals."""
    y = df["mean"].to_numpy(dtype=float)
    x = features[best_feature].to_numpy(dtype=float)
    rows = []

    stratifiers = {
        "B8/B4": df["B8"].to_numpy(dtype=float) / (df["B4"].to_numpy(dtype=float) + EPS),
        "B5/B2": df["B5"].to_numpy(dtype=float) / (df["B2"].to_numpy(dtype=float) + EPS),
        "B3": df["B3"].to_numpy(dtype=float),
    }

    for name, z in stratifiers.items():
        for q in [0.33, 0.50, 0.67]:
            th = np.nanquantile(z, q)
            for side, mask in [("low", z <= th), ("high", z > th)]:
                if mask.sum() < 40:
                    continue
                pr, pp, n = corr_one(x[mask], y[mask], "pearson")
                sr, sp, _ = corr_one(x[mask], y[mask], "spearman")
                rows.append(
                    {
                        "stratifier": name,
                        "quantile": q,
                        "side": side,
                        "threshold": th,
                        "n": n,
                        "pearson_r": pr,
                        "pearson_abs": abs(pr),
                        "pearson_p": pp,
                        "spearman_r": sr,
                        "spearman_abs": abs(sr),
                        "spearman_p": sp,
                    }
                )
    return pd.DataFrame(rows).sort_values("pearson_abs", ascending=False)


def main() -> None:
    df = load_legacy_water_samples()
    features = build_features(df)
    targets = target_variants(df["mean"])
    results = search_correlations(features, targets)
    results.sort_values(["pearson_abs", "spearman_abs"], ascending=False).to_csv(
        OUT_DIR / "expanded_correlation_search.csv", index=False, encoding="utf-8-sig"
    )

    best_raw = results[results["target"] == "raw"].sort_values("pearson_abs", ascending=False).head(30)
    best_raw.to_csv(OUT_DIR / "top_raw_target_pearson.csv", index=False, encoding="utf-8-sig")

    best_spearman = results[results["target"] == "raw"].sort_values("spearman_abs", ascending=False).head(30)
    best_spearman.to_csv(OUT_DIR / "top_raw_target_spearman.csv", index=False, encoding="utf-8-sig")

    best_any = results.sort_values("pearson_abs", ascending=False).head(30)
    best_any.to_csv(OUT_DIR / "top_any_target_transform_pearson.csv", index=False, encoding="utf-8-sig")

    strata = optical_strata_report(df, features, best_raw.iloc[0]["feature"])
    strata.to_csv(OUT_DIR / "spectral_strata_report.csv", index=False, encoding="utf-8-sig")

    print(f"samples={len(df)} features={features.shape[1]}")
    print("\nTop Pearson against raw reference CDOM:")
    print(best_raw.head(12).to_string(index=False))
    print("\nTop Spearman against raw reference CDOM:")
    print(best_spearman.head(12).to_string(index=False))
    print("\nTop Pearson after target transformations:")
    print(best_any.head(12).to_string(index=False))
    print("\nBest spectral-only strata using the best raw-Pearson feature:")
    print(strata.head(12).to_string(index=False))
    print(f"\nSaved outputs to {OUT_DIR}")


if __name__ == "__main__":
    main()
