from __future__ import annotations

import json
import math
import re
from itertools import combinations, permutations
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
import shap
from scipy import stats
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, KFold, train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.svm import SVR
from xgboost import XGBRegressor


# =========================
# Configuration
# =========================
BASE_DIR = Path(__file__).resolve().parent
RAW_CSV = BASE_DIR / "CDOM_Extracted_2020.csv"
CLEAN_CSV = BASE_DIR / "CDOM_cleaned.csv"
if not CLEAN_CSV.exists():
    alt = BASE_DIR / "lunwen" / "PythonProject1" / "CDOM_cleaned.csv"
    CLEAN_CSV = alt if alt.exists() else CLEAN_CSV

TIF_PATH = BASE_DIR / "S2_2020_AllBands_Median.tif"
if not TIF_PATH.exists():
    TIF_PATH = BASE_DIR / "lunwen" / "PythonProject1" / "S2_2020_AllBands_Median.tif"

OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "complete_ml_pipeline"
FIG_DIR = OUT_DIR / "figures"
MODEL_DIR = OUT_DIR / "models"
OUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

TARGET_COL = "mean"
GEO_COL = ".geo"
RANDOM_STATE = 42
TEST_SIZE = 0.30
EPS = 1e-6

USE_OPTICAL_STRATUM = True
STRATIFIER_NAME = "B11/B3"
STRATIFIER_QUANTILE = 0.20

PEARSON_PRESELECT_N = 40
VIF_THRESHOLD = 30.0
MIN_FEATURES_AFTER_VIF = 5
RELIEFF_NEIGHBORS = 10
FINAL_FEATURE_COUNT = 5
CV_FOLDS = 5
SPECTRAL_CURVE_SAMPLE_COUNT = 18
SPECTRAL_CURVE_BAND_FRACTION = 0.06
SPECTRAL_TOP_CORR_COUNT = 10
SPECTRAL_FORCE_KEEP_BANDS = ["B2", "B3", "B4", "B5"]
SPECTRAL_CONTEXT_BANDS = ["B8A", "B11"]
SPECTRAL_HIDE_BANDS = {"B6", "B7", "B9"}

BANDS = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
BAND_WAVELENGTHS_NM = {
    "B1": 443,
    "B2": 490,
    "B3": 560,
    "B4": 665,
    "B5": 705,
    "B6": 740,
    "B7": 783,
    "B8": 842,
    "B8A": 865,
    "B9": 945,
    "B11": 1610,
    "B12": 2190,
}
ALL_BANDS = BANDS + [
    "AOT",
    "WVP",
    "SCL",
    "TCI_R",
    "TCI_G",
    "TCI_B",
    "MSK_CLDPRB",
    "MSK_SNWPRB",
    "QA10",
    "QA20",
    "QA60",
    "MSK_CLASSI_OPAQUE",
    "MSK_CLASSI_CIRRUS",
    "MSK_CLASSI_SNOW_ICE",
]


# =========================
# Plot helpers
# =========================
def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 220
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 14
    plt.rcParams["axes.labelsize"] = 11
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 9


def save_barh(
    df: pd.DataFrame,
    label_col: str,
    value_col: str,
    title: str,
    xlabel: str,
    output: Path,
    sign_col: str | None = None,
    top_n: int | None = None,
) -> None:
    setup_plot_style()
    data = df.head(top_n).copy() if top_n else df.copy()
    data = data.iloc[::-1]
    colors = "#4c78a8"
    if sign_col:
        colors = np.where(data[sign_col] >= 0, "#4c78a8", "#e45756")
    fig_h = max(4.8, 0.35 * len(data) + 1.4)
    fig, ax = plt.subplots(figsize=(10, fig_h))
    raw_values = data[value_col].astype(float).to_numpy()
    finite_values = raw_values[np.isfinite(raw_values)]
    finite_max = float(finite_values.max()) if len(finite_values) else 1.0
    plot_values = np.where(np.isfinite(raw_values), raw_values, finite_max * 1.08)
    ax.barh(data[label_col], plot_values, color=colors, alpha=0.92)
    ax.set_title(title, pad=12)
    ax.set_xlabel(xlabel)
    ax.grid(axis="x", alpha=0.25, linestyle="-")
    if sign_col:
        from matplotlib.patches import Patch

        ax.legend(
            handles=[
                Patch(facecolor="#4c78a8", label="positive correlation"),
                Patch(facecolor="#e45756", label="negative correlation"),
            ],
            frameon=False,
            loc="lower right",
        )
    x_max = float(np.max(plot_values)) if len(plot_values) else 1.0
    for i, (plot_v, raw_v) in enumerate(zip(plot_values, raw_values)):
        label = "Inf" if not np.isfinite(raw_v) else f"{raw_v:.3f}"
        ax.text(plot_v + x_max * 0.01, i, label, va="center", ha="left", fontsize=8)
    ax.set_xlim(0, x_max * 1.14)
    fig.tight_layout()
    fig.savefig(output)
    plt.close(fig)


def save_metric_bars(metrics_df: pd.DataFrame) -> None:
    setup_plot_style()

    data = metrics_df.sort_values("test_r2", ascending=False)
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    bars = ax.bar(data["model"], data["test_r2"], color=["#4c78a8", "#59a14f", "#f28e2b"])
    ax.set_ylim(0, max(1.0, data["test_r2"].max() * 1.15))
    ax.set_ylabel("Test R²")
    ax.set_title("Model Comparison: Test R²")
    ax.grid(axis="y", alpha=0.25)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.015, f"{bar.get_height():.3f}", ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "10_model_test_r2_comparison.png")
    plt.close(fig)

    err = data.melt(id_vars="model", value_vars=["test_rmse", "test_mae"], var_name="metric", value_name="value")
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    width = 0.36
    models = data["model"].tolist()
    x = np.arange(len(models))
    rmse = data["test_rmse"].to_numpy()
    mae = data["test_mae"].to_numpy()
    ax.bar(x - width / 2, rmse, width, label="RMSE", color="#e15759")
    ax.bar(x + width / 2, mae, width, label="MAE", color="#76b7b2")
    ax.set_xticks(x)
    ax.set_xticklabels(models)
    ax.set_ylabel("Error")
    ax.set_title("Model Comparison: Test Errors")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False)
    for xi, v in zip(x - width / 2, rmse):
        ax.text(xi, v + 0.015, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    for xi, v in zip(x + width / 2, mae):
        ax.text(xi, v + 0.015, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "11_model_test_error_comparison.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    bars = ax.bar(data["model"], data["test_mape_percent"], color="#af7aa1")
    ax.set_ylabel("MAPE (%)")
    ax.set_title("Model Comparison: Test MAPE")
    ax.grid(axis="y", alpha=0.25)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, f"{bar.get_height():.2f}%", ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "11b_model_test_mape_comparison.png")
    plt.close(fig)


def save_cv_metric_bars(cv_df: pd.DataFrame) -> None:
    setup_plot_style()
    data = cv_df.sort_values("cv_r2", ascending=False)
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    bars = ax.bar(data["model"], data["cv_r2"], color=["#4c78a8", "#59a14f", "#f28e2b"])
    ax.set_ylim(0, max(1.0, data["cv_r2"].max() * 1.15))
    ax.set_ylabel("5-fold CV R²")
    ax.set_title("5-fold Cross-validation R²")
    ax.grid(axis="y", alpha=0.25)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.015, f"{bar.get_height():.3f}", ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "18_cv_r2_comparison.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    width = 0.36
    x = np.arange(len(data))
    ax.bar(x - width / 2, data["cv_rmse"], width, label="RMSE", color="#e15759")
    ax.bar(x + width / 2, data["cv_mae"], width, label="MAE", color="#76b7b2")
    ax.set_xticks(x)
    ax.set_xticklabels(data["model"])
    ax.set_ylabel("Cross-validation error")
    ax.set_title("5-fold Cross-validation Errors")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "19_cv_error_comparison.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    bars = ax.bar(data["model"], data["cv_mape_percent"], color="#af7aa1")
    ax.set_ylabel("5-fold CV MAPE (%)")
    ax.set_title("5-fold Cross-validation MAPE")
    ax.grid(axis="y", alpha=0.25)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, f"{bar.get_height():.2f}%", ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "20_cv_mape_comparison.png")
    plt.close(fig)


def save_mean_reflectance_curve(samples: pd.DataFrame, n_bootstrap: int = 2000) -> None:
    """Plot the Sentinel-2 mean reflectance spectrum with a bootstrap 95% CI."""
    setup_plot_style()
    reflectance = samples[BANDS].astype(float).replace([np.inf, -np.inf], np.nan)
    reflectance = reflectance.dropna(how="any").copy()
    if reflectance.empty:
        return

    arr = reflectance.to_numpy(dtype=float)
    n_samples = arr.shape[0]
    rng = np.random.default_rng(RANDOM_STATE)
    boot_means = np.empty((n_bootstrap, len(BANDS)), dtype=float)
    for i in range(n_bootstrap):
        idx = rng.integers(0, n_samples, size=n_samples)
        boot_means[i] = arr[idx].mean(axis=0)

    mean_ref = arr.mean(axis=0)
    std_ref = arr.std(axis=0, ddof=1)
    ci_low = np.percentile(boot_means, 2.5, axis=0)
    ci_high = np.percentile(boot_means, 97.5, axis=0)
    wavelengths = np.array([BAND_WAVELENGTHS_NM[b] for b in BANDS], dtype=float)
    x_pos = np.arange(len(BANDS), dtype=float)

    table = pd.DataFrame(
        {
            "band": BANDS,
            "wavelength_nm": wavelengths.astype(int),
            "mean_reflectance": mean_ref,
            "std_reflectance": std_ref,
            "ci95_low": ci_low,
            "ci95_high": ci_high,
            "n_samples": n_samples,
            "n_bootstrap": n_bootstrap,
        }
    )
    table.to_csv(OUT_DIR / "01b_mean_reflectance_curve.csv", index=False, encoding="utf-8-sig")

    fig, ax = plt.subplots(figsize=(9.5, 5.2))
    ax.fill_between(x_pos, ci_low, ci_high, color="#4c78a8", alpha=0.18, linewidth=0, label="95% bootstrap CI")
    ax.plot(x_pos, mean_ref, color="#1f5f99", lw=2.4, marker="o", ms=5.5, label="Mean reflectance")
    ax.scatter(x_pos, mean_ref, color="#1f5f99", s=28, zorder=3)

    for x, y, band in zip(x_pos, mean_ref, BANDS):
        ax.annotate(band, (x, y), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8)

    ax.set_title(f"Sentinel-2 Mean Reflectance Spectrum (n={n_samples})", pad=12)
    ax.set_xlabel("Sentinel-2 band / central wavelength (nm)")
    ax.set_ylabel("Remote sensing reflectance")
    ax.set_xticks(x_pos)
    ax.set_xticklabels([f"{band}\n{int(wl)}" for band, wl in zip(BANDS, wavelengths)])
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, loc="best")
    ax.margins(x=0.03)
    y_min = max(0.0, float(np.nanmin(ci_low)) * 0.88)
    y_max = float(np.nanmax(ci_high)) * 1.12
    if y_max > y_min:
        ax.set_ylim(y_min, y_max)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01b_mean_reflectance_curve_B1_B12.png")
    plt.close(fig)


def save_representative_sample_spectra(samples: pd.DataFrame) -> None:
    """Plot representative sample-level spectra in the style of multi-line spectral figures."""
    setup_plot_style()
    reflectance = samples[BANDS].astype(float).replace([np.inf, -np.inf], np.nan)
    valid = reflectance.notna().all(axis=1) & samples[TARGET_COL].notna()
    data = samples.loc[valid].copy().reset_index(drop=False).rename(columns={"index": "source_row"})
    if data.empty:
        return

    n_select = min(SPECTRAL_CURVE_SAMPLE_COUNT, len(data))
    sorted_pos = np.argsort(data[TARGET_COL].to_numpy(dtype=float))
    selected_pos = np.unique(np.round(np.linspace(0, len(sorted_pos) - 1, n_select)).astype(int))
    selected = data.iloc[sorted_pos[selected_pos]].copy().reset_index(drop=True)
    selected["sample_id"] = np.arange(1, len(selected) + 1)

    wavelengths = np.array([BAND_WAVELENGTHS_NM[b] for b in BANDS], dtype=float)
    x_pos = np.arange(len(BANDS), dtype=float)
    colors = plt.cm.tab20(np.linspace(0, 1, len(selected)))

    long_rows = []
    fig, ax = plt.subplots(figsize=(10.8, 6.2))
    for color, (_, row) in zip(colors, selected.iterrows()):
        y = row[BANDS].astype(float).to_numpy()
        sample_id = int(row["sample_id"])
        visual_band = np.maximum(np.abs(y) * SPECTRAL_CURVE_BAND_FRACTION, 0.0005)
        lower = np.clip(y - visual_band, 0, None)
        upper = y + visual_band
        ax.fill_between(x_pos, lower, upper, color=color, alpha=0.13, linewidth=0)
        ax.plot(x_pos, y, color=color, lw=1.6, alpha=0.92, label=str(sample_id))
        for band, wl, value in zip(BANDS, wavelengths, y):
            long_rows.append(
                {
                    "sample_id": sample_id,
                    "source_row": int(row["source_row"]),
                    "reference_cdom": float(row[TARGET_COL]),
                    "band": band,
                    "wavelength_nm": int(wl),
                    "reflectance": float(value),
                }
            )

    pd.DataFrame(long_rows).to_csv(OUT_DIR / "01c_representative_sample_spectra.csv", index=False, encoding="utf-8-sig")

    ax.set_title(f"Representative Sentinel-2 Reflectance Spectra (n={len(selected)})", pad=12)
    ax.set_xlabel("Sentinel-2 band / central wavelength (nm)", fontweight="bold")
    ax.set_ylabel("Remote sensing reflectance", fontweight="bold")
    ax.set_xticks(x_pos)
    ax.set_xticklabels([f"{band}\n{int(wl)}" for band, wl in zip(BANDS, wavelengths)])
    ax.grid(alpha=0.18)
    ax.legend(title="Sample_id", frameon=True, fontsize=8, title_fontsize=9, loc="upper right", ncol=1)
    ax.margins(x=0.03)
    y_max = float(np.nanmax(selected[BANDS].to_numpy(dtype=float))) * 1.16
    if y_max > 0:
        ax.set_ylim(0, y_max)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01c_representative_sample_spectra_B1_B12.png")
    plt.close(fig)


def extract_bands_from_feature_names(feature_names: Iterable[str]) -> List[str]:
    selected: List[str] = []
    for feature in feature_names:
        text = str(feature)
        for band in sorted(BANDS, key=len, reverse=True):
            if re.search(rf"(?<![A-Za-z0-9]){re.escape(band)}(?![A-Za-z0-9])", text):
                if band not in selected:
                    selected.append(band)
    return selected


def select_key_spectral_bands(top_pearson: pd.DataFrame, top_spearman: pd.DataFrame, final_features: Sequence[str]) -> Tuple[List[str], pd.DataFrame]:
    pearson_features = top_pearson.head(SPECTRAL_TOP_CORR_COUNT)["feature"].astype(str).tolist()
    spearman_features = top_spearman.head(SPECTRAL_TOP_CORR_COUNT)["feature"].astype(str).tolist()
    model_bands = extract_bands_from_feature_names(final_features)
    pearson_bands = extract_bands_from_feature_names(pearson_features)
    spearman_bands = extract_bands_from_feature_names(spearman_features)

    selected = []
    for band in SPECTRAL_FORCE_KEEP_BANDS + pearson_bands + spearman_bands + model_bands + SPECTRAL_CONTEXT_BANDS:
        if band in BANDS and band not in selected and band not in SPECTRAL_HIDE_BANDS:
            selected.append(band)

    selected = [band for band in BANDS if band in selected]
    source_rows = []
    for band in BANDS:
        source_rows.append(
            {
                "band": band,
                "wavelength_nm": BAND_WAVELENGTHS_NM[band],
                "used_in_key_spectral_plot": band in selected,
                "forced_core_band": band in SPECTRAL_FORCE_KEEP_BANDS,
                "from_top10_pearson": band in pearson_bands,
                "from_top10_spearman": band in spearman_bands,
                "from_final_model_features": band in model_bands,
                "context_band": band in SPECTRAL_CONTEXT_BANDS,
                "hidden_reason": "atmospheric_or_low_explanatory_priority" if band in SPECTRAL_HIDE_BANDS else "",
            }
        )
    selection_df = pd.DataFrame(source_rows)
    selection_df.to_csv(OUT_DIR / "01d_key_spectral_band_selection.csv", index=False, encoding="utf-8-sig")
    return selected, selection_df


def save_key_band_representative_spectra(samples: pd.DataFrame, selected_bands: Sequence[str]) -> None:
    """Plot a cleaner representative spectra figure using correlation/model-selected key bands."""
    setup_plot_style()
    bands = [band for band in selected_bands if band in BANDS]
    if not bands:
        return

    reflectance = samples[bands].astype(float).replace([np.inf, -np.inf], np.nan)
    valid = reflectance.notna().all(axis=1) & samples[TARGET_COL].notna()
    data = samples.loc[valid].copy().reset_index(drop=False).rename(columns={"index": "source_row"})
    if data.empty:
        return

    n_select = min(SPECTRAL_CURVE_SAMPLE_COUNT, len(data))
    sorted_pos = np.argsort(data[TARGET_COL].to_numpy(dtype=float))
    selected_pos = np.unique(np.round(np.linspace(0, len(sorted_pos) - 1, n_select)).astype(int))
    selected = data.iloc[sorted_pos[selected_pos]].copy().reset_index(drop=True)
    selected["sample_id"] = np.arange(1, len(selected) + 1)

    wavelengths = np.array([BAND_WAVELENGTHS_NM[b] for b in bands], dtype=float)
    x_pos = np.arange(len(bands), dtype=float)
    colors = plt.cm.tab20(np.linspace(0, 1, len(selected)))

    long_rows = []
    fig, ax = plt.subplots(figsize=(9.8, 5.9))
    for color, (_, row) in zip(colors, selected.iterrows()):
        y = row[bands].astype(float).to_numpy()
        sample_id = int(row["sample_id"])
        visual_band = np.maximum(np.abs(y) * SPECTRAL_CURVE_BAND_FRACTION, 0.0005)
        lower = np.clip(y - visual_band, 0, None)
        upper = y + visual_band
        ax.fill_between(x_pos, lower, upper, color=color, alpha=0.11, linewidth=0)
        ax.plot(x_pos, y, color=color, lw=1.7, alpha=0.94, label=str(sample_id))
        for band, wl, value in zip(bands, wavelengths, y):
            long_rows.append(
                {
                    "sample_id": sample_id,
                    "source_row": int(row["source_row"]),
                    "reference_cdom": float(row[TARGET_COL]),
                    "band": band,
                    "wavelength_nm": int(wl),
                    "reflectance": float(value),
                }
            )

    pd.DataFrame(long_rows).to_csv(OUT_DIR / "01d_key_band_representative_sample_spectra.csv", index=False, encoding="utf-8-sig")

    ax.set_title(f"Representative Spectra of Key Sentinel-2 Bands (n={len(selected)})", pad=12)
    ax.set_xlabel("Selected Sentinel-2 band / central wavelength (nm)", fontweight="bold")
    ax.set_ylabel("Remote sensing reflectance", fontweight="bold")
    ax.set_xticks(x_pos)
    ax.set_xticklabels([f"{band}\n{int(wl)}" for band, wl in zip(bands, wavelengths)])
    ax.grid(alpha=0.18)
    ax.legend(title="Sample_id", frameon=True, fontsize=8, title_fontsize=9, loc="upper right")
    ax.margins(x=0.04)
    y_max = float(np.nanmax(selected[bands].to_numpy(dtype=float))) * 1.15
    if y_max > 0:
        ax.set_ylim(0, y_max)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01d_key_band_representative_sample_spectra.png")
    plt.close(fig)


# =========================
# Data loading and feature generation
# =========================
def legacy_centroid(geo_str: str) -> Tuple[float, float]:
    """Reproduce the centroid method used by the earlier pearson.py workflow."""
    try:
        geo = json.loads(geo_str)
        coords = geo["coordinates"][0]
        lons = [p[0] for p in coords]
        lats = [p[1] for p in coords]
        return sum(lons) / len(lons), sum(lats) / len(lats)
    except Exception:
        return np.nan, np.nan


def read_or_create_clean_csv() -> pd.DataFrame:
    if CLEAN_CSV.exists():
        return pd.read_csv(CLEAN_CSV, low_memory=False)
    df = pd.read_csv(RAW_CSV, low_memory=False)
    df[TARGET_COL] = pd.to_numeric(df[TARGET_COL], errors="coerce")
    df = df.dropna(subset=[TARGET_COL]).copy()
    df = df[df[TARGET_COL] > 0].copy()
    df.to_csv(BASE_DIR / "CDOM_cleaned.csv", index=False, encoding="utf-8-sig")
    return df


def load_samples() -> Tuple[pd.DataFrame, float | None]:
    df = read_or_create_clean_csv()
    centroids = df[GEO_COL].apply(legacy_centroid)
    df["LON"] = [c[0] for c in centroids]
    df["LAT"] = [c[1] for c in centroids]
    df = df.dropna(subset=["LON", "LAT", TARGET_COL]).copy()

    with rasterio.open(TIF_PATH) as src:
        samples = np.array(list(src.sample(list(zip(df["LON"], df["LAT"])))), dtype=float)
        names = [d if d else ALL_BANDS[i] for i, d in enumerate(src.descriptions)]

    for i, name in enumerate(names):
        df[name] = samples[:, i]

    for band in BANDS:
        df[band] = df[band] / 10000.0

    before = len(df)
    df = df[df["SCL"] == 6].copy()
    mean = df[TARGET_COL].mean()
    std = df[TARGET_COL].std()
    df = df[(df[TARGET_COL] >= mean - 3 * std) & (df[TARGET_COL] <= mean + 3 * std)].copy()

    threshold = None
    if USE_OPTICAL_STRATUM:
        df["stratifier_B11_B3"] = df["B11"] / (df["B3"] + EPS)
        threshold = float(df["stratifier_B11_B3"].quantile(STRATIFIER_QUANTILE))
        df = df[df["stratifier_B11_B3"] <= threshold].copy()

    df = df.reset_index(drop=True)
    df.to_csv(OUT_DIR / "01_clean_stratified_samples.csv", index=False, encoding="utf-8-sig")
    return df, threshold


def add_feature(features: Dict[str, np.ndarray], name: str, values: np.ndarray) -> None:
    if name in features:
        return
    values = np.asarray(values, dtype=float)
    if np.isfinite(values).sum() < 10:
        return
    if np.nanstd(values) == 0:
        return
    features[name] = values


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    band = {b: df[b].to_numpy(dtype=float) for b in BANDS}
    features: Dict[str, np.ndarray] = {}

    for b in BANDS:
        x = band[b]
        add_feature(features, b, x)
        add_feature(features, f"log_{b}", np.log(x + EPS))
        add_feature(features, f"sqrt_{b}", np.sqrt(np.clip(x, 0, None)))
        add_feature(features, f"inv_{b}", 1.0 / (x + EPS))

    # Common water, vegetation, turbidity, and red-edge indices used as named candidates.
    # These are added explicitly so the candidate set maps cleanly to remote-sensing literature.
    add_feature(features, "NDWI_B3_B8", (band["B3"] - band["B8"]) / (band["B3"] + band["B8"] + EPS))
    add_feature(features, "MNDWI_B3_B11", (band["B3"] - band["B11"]) / (band["B3"] + band["B11"] + EPS))
    add_feature(features, "NDVI_B8_B4", (band["B8"] - band["B4"]) / (band["B8"] + band["B4"] + EPS))
    add_feature(features, "NDCI_B5_B4", (band["B5"] - band["B4"]) / (band["B5"] + band["B4"] + EPS))
    add_feature(features, "NDTI_B4_B3", (band["B4"] - band["B3"]) / (band["B4"] + band["B3"] + EPS))
    add_feature(features, "FAI_S2", band["B8"] - (band["B4"] + (band["B11"] - band["B4"]) * ((842 - 665) / (1610 - 665))))
    add_feature(features, "RECI_B8A_B5", band["B8A"] / (band["B5"] + EPS) - 1.0)
    add_feature(features, "RedEdgeRatio_B5_B4", band["B5"] / (band["B4"] + EPS))
    add_feature(features, "RedEdgeRatio_B6_B5", band["B6"] / (band["B5"] + EPS))
    add_feature(features, "RedEdgeRatio_B7_B5", band["B7"] / (band["B5"] + EPS))
    add_feature(features, "RedEdgeSlope_B5_B4", (band["B5"] - band["B4"]) / (705 - 665))
    add_feature(features, "RedEdgeSlope_B6_B5", (band["B6"] - band["B5"]) / (740 - 705))

    for b1, b2 in permutations(BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        ratio = (x1 + EPS) / (x2 + EPS)
        add_feature(features, f"{b1}/{b2}", ratio)
        add_feature(features, f"log({b1}/{b2})", np.log(ratio))
        for p in [0.5, 1.5, 2.0, 3.0]:
            add_feature(features, f"({b1}/{b2})^{p}", np.power(np.clip(ratio, 0, None), p))
        add_feature(features, f"({b1}-{b2})/{b2}", (x1 - x2) / (x2 + EPS))

    for b1, b2 in combinations(BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        add_feature(features, f"NDI_{b1}_{b2}", (x1 - x2) / (x1 + x2 + EPS))
        add_feature(features, f"Diff_{b1}_{b2}", x1 - x2)
        add_feature(features, f"Sum_{b1}_{b2}", x1 + x2)
        add_feature(features, f"Product_{b1}_{b2}", x1 * x2)
        for k in [0.25, 0.5, 0.75, 1.25, 1.5, 2.0, 3.0]:
            add_feature(features, f"{b1}-{k}*{b2}", x1 - k * x2)
            add_feature(features, f"{k}*{b1}-{b2}", k * x1 - x2)

    for b1, b2, b3 in permutations(BANDS, 3):
        x1 = band[b1]
        x2 = band[b2]
        x3 = band[b3]
        add_feature(features, f"({b1}-{b2})/{b3}", (x1 - x2) / (x3 + EPS))
        add_feature(features, f"{b1}/({b2}+{b3})", x1 / (x2 + x3 + EPS))
        add_feature(features, f"({b1}+{b2})/{b3}", (x1 + x2) / (x3 + EPS))
        add_feature(features, f"log(({b1}+{b2})/{b3})", np.log((x1 + x2 + EPS) / (x3 + EPS)))
        add_feature(features, f"TriNDI_{b1}_{b2}_{b3}", (x1 - x2) / (x1 + x2 - 2 * x3 + EPS))
        add_feature(features, f"3B_{b1}_{b2}_{b3}", (1.0 / (x1 + EPS) - 1.0 / (x2 + EPS)) * x3)

    out = pd.DataFrame(features).replace([np.inf, -np.inf], np.nan)
    out = out.loc[:, out.notna().sum(axis=0) >= int(0.95 * len(out))]
    out = out.fillna(out.median(numeric_only=True))
    return out


def feature_category(name: str) -> str:
    if name in BANDS or name.startswith(("log_B", "sqrt_B", "inv_B")):
        return "raw_band_or_transform"
    if name.startswith(("NDWI", "MNDWI", "NDVI", "NDCI", "NDTI", "FAI")):
        return "water_index"
    if name.startswith(("RECI", "RedEdge")):
        return "red_edge_index"
    if "/" in name and "+" not in name and "-" not in name:
        return "band_ratio"
    if name.startswith(("NDI_", "Diff_", "Sum_", "Product_")):
        return "two_band_index"
    if any(prefix in name for prefix in ["TriNDI", "3B_", "+", "/("]):
        return "multi_band_index"
    return "engineered_index"


# =========================
# Pearson / VIF / ReliefF
# =========================
def safe_corr(x: np.ndarray, y: np.ndarray, method: str) -> Tuple[float, float, int]:
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < 10 or np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
        return np.nan, np.nan, n
    if method == "pearson":
        r, p = stats.pearsonr(x[mask], y[mask])
    else:
        r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), n


def correlation_table(features: pd.DataFrame, y: np.ndarray) -> pd.DataFrame:
    rows = []
    for feature in features.columns:
        x = features[feature].to_numpy(dtype=float)
        pr, pp, n = safe_corr(x, y, "pearson")
        sr, sp, _ = safe_corr(x, y, "spearman")
        rows.append(
            {
                "feature": feature,
                "pearson_r": pr,
                "pearson_abs": abs(pr) if np.isfinite(pr) else np.nan,
                "pearson_p": pp,
                "spearman_r": sr,
                "spearman_abs": abs(sr) if np.isfinite(sr) else np.nan,
                "spearman_p": sp,
                "n": n,
            }
        )
    out = pd.DataFrame(rows).sort_values(["pearson_abs", "spearman_abs"], ascending=False)
    out.to_csv(OUT_DIR / "02_all_feature_pearson_spearman.csv", index=False, encoding="utf-8-sig")
    return out


def canonical_feature_key(name: str) -> str:
    m = re.fullmatch(r"\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, b, c = m.groups()
        return f"({'+'.join(sorted([a, b]))})/{c}"
    m = re.fullmatch(r"log\(\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)/(B\d+A?|B\d+)\)", name)
    if m:
        a, b, c = m.groups()
        return f"log(({'+'.join(sorted([a, b]))})/{c})"
    m = re.fullmatch(r"(B\d+A?|B\d+)/\((B\d+A?|B\d+)\+(B\d+A?|B\d+)\)", name)
    if m:
        a, b, c = m.groups()
        return f"{a}/({'+'.join(sorted([b, c]))})"
    m = re.fullmatch(r"\((B\d+A?|B\d+)-(B\d+A?|B\d+)\)/(B\d+A?|B\d+)", name)
    if m:
        a, b, c = m.groups()
        return f"absdiff({ '-'.join(sorted([a, b]))})/{c}"
    return name


def preselect_unique_features(corr_df: pd.DataFrame, n: int = PEARSON_PRESELECT_N) -> List[str]:
    ranked = corr_df.copy()
    ranked["pearson_rank"] = ranked["pearson_abs"].rank(method="min", ascending=False)
    ranked["spearman_rank"] = ranked["spearman_abs"].rank(method="min", ascending=False)
    ranked["combined_rank"] = ranked[["pearson_rank", "spearman_rank"]].mean(axis=1)
    selected: List[str] = []
    seen = set()
    for feature in ranked.sort_values("combined_rank")["feature"]:
        key = canonical_feature_key(str(feature))
        if key in seen:
            continue
        selected.append(str(feature))
        seen.add(key)
        if len(selected) == n:
            break
    return selected


def top_unique_correlations(corr_df: pd.DataFrame, metric_col: str, n: int) -> pd.DataFrame:
    rows = []
    seen = set()
    for _, row in corr_df.sort_values(metric_col, ascending=False).iterrows():
        key = canonical_feature_key(str(row["feature"]))
        if key in seen:
            continue
        rows.append(row)
        seen.add(key)
        if len(rows) == n:
            break
    return pd.DataFrame(rows)


def calculate_vif(X: pd.DataFrame, features: Sequence[str]) -> pd.DataFrame:
    rows = []
    for feature in features:
        others = [f for f in features if f != feature]
        if not others:
            rows.append({"feature": feature, "vif": 1.0, "r2_explained_by_others": 0.0})
            continue
        r2 = LinearRegression().fit(X[others], X[feature]).score(X[others], X[feature])
        vif = np.inf if r2 >= 0.999999999 else 1.0 / (1.0 - r2)
        rows.append({"feature": feature, "vif": float(vif), "r2_explained_by_others": float(r2)})
    return pd.DataFrame(rows).sort_values("vif", ascending=False)


def vif_filter(X: pd.DataFrame, candidates: List[str]) -> Tuple[List[str], pd.DataFrame, pd.DataFrame]:
    before = calculate_vif(X, candidates)
    before.to_csv(OUT_DIR / "03_vif_before_filter.csv", index=False, encoding="utf-8-sig")

    features = candidates.copy()
    steps = []
    while len(features) > MIN_FEATURES_AFTER_VIF:
        vif_df = calculate_vif(X, features)
        max_vif = float(vif_df.iloc[0]["vif"])
        if max_vif <= VIF_THRESHOLD:
            break
        drop_feature = str(vif_df.iloc[0]["feature"])
        steps.append({"dropped_feature": drop_feature, "vif": max_vif, "remaining_before_drop": len(features)})
        features.remove(drop_feature)

    after = calculate_vif(X, features)
    after.to_csv(OUT_DIR / "04_vif_after_filter.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(steps).to_csv(OUT_DIR / "05_vif_filter_steps.csv", index=False, encoding="utf-8-sig")
    return features, before, after


def regression_relieff_scores(X: pd.DataFrame, y: np.ndarray, n_neighbors: int = RELIEFF_NEIGHBORS) -> pd.DataFrame:
    """A compact RReliefF-style ranking for continuous targets.

    Features score high when nearby samples with different target values also differ in that feature.
    This is a feature-ranking heuristic, not a statistical test.
    """
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)
    y_scaled = MinMaxScaler().fit_transform(y.reshape(-1, 1)).ravel()
    k = min(n_neighbors + 1, len(X_scaled))
    nn = NearestNeighbors(n_neighbors=k, metric="euclidean")
    nn.fit(X_scaled)
    distances, indices = nn.kneighbors(X_scaled)

    scores = np.zeros(X_scaled.shape[1], dtype=float)
    denom = 0.0
    for i in range(X_scaled.shape[0]):
        neigh = indices[i, 1:]
        target_diff = np.abs(y_scaled[i] - y_scaled[neigh])
        feature_diff = np.abs(X_scaled[i] - X_scaled[neigh])
        scores += (feature_diff * target_diff[:, None]).sum(axis=0)
        denom += target_diff.sum()
    if denom > 0:
        scores /= denom
    out = pd.DataFrame({"feature": X.columns, "relieff_score": scores})
    out.sort_values("relieff_score", ascending=False, inplace=True)
    out.to_csv(OUT_DIR / "06_relieff_feature_ranking.csv", index=False, encoding="utf-8-sig")
    return out


# =========================
# Modeling and SHAP
# =========================
def regression_metrics(y_true: np.ndarray, pred: np.ndarray) -> Dict[str, float]:
    pr, pp, _ = safe_corr(np.asarray(pred), np.asarray(y_true), "pearson")
    mape = np.mean(np.abs((np.asarray(y_true) - np.asarray(pred)) / np.asarray(y_true))) * 100.0
    return {
        "r2": float(r2_score(y_true, pred)),
        "rmse": float(math.sqrt(mean_squared_error(y_true, pred))),
        "mae": float(mean_absolute_error(y_true, pred)),
        "mape_percent": float(mape),
        "pearson_r": float(pr),
        "pearson_p": float(pp),
    }


def tune_and_fit_models(X_train: pd.DataFrame, y_train: np.ndarray):
    cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    models = {
        "RF": (
            RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True),
            {
                "n_estimators": [300, 500],
                "max_depth": [3, 5, 8],
                "min_samples_leaf": [1, 2, 3],
                "min_samples_split": [2, 4],
                "max_features": [0.8, 1.0],
            },
        ),
        "SVR": (
            Pipeline([("scaler", StandardScaler()), ("svr", SVR(kernel="rbf"))]),
            {
                "svr__C": [1, 10, 50, 100],
                "svr__epsilon": [0.05, 0.1, 0.2],
                "svr__gamma": ["scale", 0.1, 0.5, 1.0],
            },
        ),
        "XGBoost": (
            XGBRegressor(
                objective="reg:squarederror",
                random_state=RANDOM_STATE,
                n_jobs=-1,
                tree_method="hist",
            ),
            {
                "n_estimators": [100, 250, 400],
                "max_depth": [2, 3],
                "learning_rate": [0.03, 0.05, 0.08],
                "subsample": [0.8, 1.0],
                "colsample_bytree": [0.8, 1.0],
                "reg_lambda": [1.0, 5.0],
            },
        ),
    }

    fitted = {}
    tuning_rows = []
    for name, (estimator, grid) in models.items():
        search = GridSearchCV(
            estimator,
            grid,
            scoring="neg_root_mean_squared_error",
            cv=cv,
            n_jobs=-1,
            refit=True,
        )
        search.fit(X_train, y_train)
        fitted[name] = search.best_estimator_
        tuning_rows.append(
            {
                "model": name,
                "best_cv_rmse": float(-search.best_score_),
                "best_params": json.dumps(search.best_params_, ensure_ascii=False),
            }
        )
        joblib.dump(search.best_estimator_, MODEL_DIR / f"{name}_model.joblib")

    pd.DataFrame(tuning_rows).to_csv(OUT_DIR / "08_model_tuning_summary.csv", index=False, encoding="utf-8-sig")
    return fitted


def evaluate_models(models: Dict[str, object], X_train: pd.DataFrame, X_test: pd.DataFrame, y_train: np.ndarray, y_test: np.ndarray) -> Tuple[pd.DataFrame, Dict[str, pd.DataFrame]]:
    rows = []
    pred_tables: Dict[str, pd.DataFrame] = {}
    for name, model in models.items():
        train_pred = model.predict(X_train)
        test_pred = model.predict(X_test)
        train_m = regression_metrics(y_train, train_pred)
        test_m = regression_metrics(y_test, test_pred)
        row = {"model": name}
        row.update({f"train_{k}": v for k, v in train_m.items()})
        row.update({f"test_{k}": v for k, v in test_m.items()})
        if name == "RF":
            row["oob_score"] = float(getattr(model, "oob_score_", np.nan))
        rows.append(row)
        pred = pd.DataFrame({"obs": y_test, "pred": test_pred, "residual": y_test - test_pred})
        pred.to_csv(OUT_DIR / f"09_{name}_test_predictions.csv", index=False, encoding="utf-8-sig")
        pred_tables[name] = pred

    metrics_df = pd.DataFrame(rows).sort_values("test_r2", ascending=False)
    metrics_df.to_csv(OUT_DIR / "10_model_metrics.csv", index=False, encoding="utf-8-sig")
    return metrics_df, pred_tables


def cross_validate_models(models: Dict[str, object], X: pd.DataFrame, y: np.ndarray) -> pd.DataFrame:
    """Five-fold CV on the final selected feature set using each tuned estimator.

    Feature screening is completed before this step; holdout test metrics remain the
    primary no-leakage estimate because screening used only the 70% training split.
    """
    cv = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    rows = []
    pred_table = pd.DataFrame({"obs": y})
    for model_name, model in models.items():
        fold_pred = np.full(len(y), np.nan, dtype=float)
        fold_rows = []
        for fold, (train_idx, test_idx) in enumerate(cv.split(X), start=1):
            estimator = clone(model)
            estimator.fit(X.iloc[train_idx], y[train_idx])
            pred = estimator.predict(X.iloc[test_idx])
            fold_pred[test_idx] = pred
            m = regression_metrics(y[test_idx], pred)
            fold_rows.append({"model": model_name, "fold": fold, "n_test": len(test_idx), **m})
        fold_df = pd.DataFrame(fold_rows)
        fold_df.to_csv(OUT_DIR / f"13_{model_name}_5fold_cv_fold_metrics.csv", index=False, encoding="utf-8-sig")
        overall = regression_metrics(y, fold_pred)
        rows.append({"model": model_name, **{f"cv_{k}": v for k, v in overall.items()}})
        pred_table[f"{model_name}_cv_pred"] = fold_pred
        pred_table[f"{model_name}_cv_residual"] = y - fold_pred
    pred_table.to_csv(OUT_DIR / "13_5fold_cv_predictions.csv", index=False, encoding="utf-8-sig")
    cv_df = pd.DataFrame(rows).sort_values("cv_r2", ascending=False)
    cv_df.to_csv(OUT_DIR / "13_5fold_cv_overall_metrics.csv", index=False, encoding="utf-8-sig")
    return cv_df


def plot_prediction_grid(pred_tables: Dict[str, pd.DataFrame], metrics_df: pd.DataFrame) -> None:
    setup_plot_style()
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), sharex=False, sharey=False)
    metric_lookup = metrics_df.set_index("model").to_dict(orient="index")
    for ax, (name, pred) in zip(axes, pred_tables.items()):
        ax.scatter(pred["obs"], pred["pred"], s=36, alpha=0.82, color="#4c78a8", edgecolor="white", linewidth=0.4)
        low = float(min(pred["obs"].min(), pred["pred"].min()))
        high = float(max(pred["obs"].max(), pred["pred"].max()))
        pad = (high - low) * 0.06
        ax.plot([low - pad, high + pad], [low - pad, high + pad], "--", color="#d62728", lw=1.6)
        m = metric_lookup[name]
        ax.set_title(f"{name}: R²={m['test_r2']:.3f}, RMSE={m['test_rmse']:.3f}")
        ax.set_xlabel("Reference CDOM product")
        ax.set_ylabel("Predicted CDOM")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "12_model_prediction_scatter_grid.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    for ax, (name, pred) in zip(axes, pred_tables.items()):
        ax.scatter(pred["pred"], pred["residual"], s=36, alpha=0.82, color="#f28e2b", edgecolor="white", linewidth=0.4)
        ax.axhline(0, color="#333333", linestyle="--", lw=1.2)
        ax.set_title(f"{name} Residuals")
        ax.set_xlabel("Predicted CDOM")
        ax.set_ylabel("Residual")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "13_model_residual_grid.png")
    plt.close(fig)


def shap_for_best_tree_model(models: Dict[str, object], metrics_df: pd.DataFrame, X_train: pd.DataFrame, X_test: pd.DataFrame) -> None:
    tree_order = [m for m in metrics_df["model"].tolist() if m in {"XGBoost", "RF"}]
    if not tree_order:
        return
    best_name = tree_order[0]
    model = models[best_name]

    explainer = shap.Explainer(model, X_train)
    shap_values = explainer(X_test)

    mean_abs = np.abs(shap_values.values).mean(axis=0)
    shap_df = pd.DataFrame({"feature": X_test.columns, "mean_abs_shap": mean_abs}).sort_values("mean_abs_shap", ascending=False)
    shap_df.to_csv(OUT_DIR / f"11_{best_name}_shap_importance.csv", index=False, encoding="utf-8-sig")

    setup_plot_style()
    fig, ax = plt.subplots(figsize=(8, 5))
    data = shap_df.iloc[::-1]
    ax.barh(data["feature"], data["mean_abs_shap"], color="#9467bd")
    ax.set_title(f"SHAP Mean Absolute Impact ({best_name})")
    ax.set_xlabel("Mean |SHAP value|")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "14_shap_mean_abs_bar.png")
    plt.close(fig)

    plt.figure(figsize=(8.5, 5.5))
    shap.plots.beeswarm(shap_values, max_display=min(10, X_test.shape[1]), show=False)
    plt.title(f"SHAP Beeswarm ({best_name})", pad=10)
    plt.tight_layout()
    plt.savefig(FIG_DIR / "15_shap_beeswarm.png", dpi=220, bbox_inches="tight")
    plt.close()

    top_feature = shap_df.iloc[0]["feature"]
    plt.figure(figsize=(7, 5))
    shap.plots.scatter(shap_values[:, top_feature], color=shap_values, show=False)
    plt.title(f"SHAP Dependence: {top_feature}", pad=10)
    plt.tight_layout()
    plt.savefig(FIG_DIR / "16_shap_dependence_top_feature.png", dpi=220, bbox_inches="tight")
    plt.close()


def main() -> None:
    setup_plot_style()

    samples, stratum_threshold = load_samples()
    features = build_features(samples)
    y = samples[TARGET_COL].to_numpy(dtype=float)
    save_mean_reflectance_curve(samples)
    save_representative_sample_spectra(samples)
    feature_catalog = pd.DataFrame(
        {
            "feature": features.columns,
            "category": [feature_category(c) for c in features.columns],
        }
    )
    feature_catalog.to_csv(OUT_DIR / "01_candidate_feature_catalog.csv", index=False, encoding="utf-8-sig")

    # Basic target distribution
    fig, ax = plt.subplots(figsize=(6.8, 4.5))
    ax.hist(y, bins=18, color="#4c78a8", edgecolor="white", alpha=0.9)
    ax.set_title("Reference CDOM Distribution")
    ax.set_xlabel("Reference CDOM product")
    ax.set_ylabel("Sample count")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01_target_distribution.png")
    plt.close(fig)

    corr_df = correlation_table(features, y)
    top_pearson = top_unique_correlations(corr_df, "pearson_abs", 20)
    top_spearman = top_unique_correlations(corr_df, "spearman_abs", 20)
    top_pearson.to_csv(OUT_DIR / "02_top20_pearson.csv", index=False, encoding="utf-8-sig")
    top_spearman.to_csv(OUT_DIR / "03_top20_spearman.csv", index=False, encoding="utf-8-sig")

    save_barh(top_pearson, "feature", "pearson_abs", "Top 20 Pearson Correlated Indices", "|Pearson r|", FIG_DIR / "02_top20_pearson_bar.png", "pearson_r")
    save_barh(top_spearman, "feature", "spearman_abs", "Top 20 Spearman Correlated Indices", "|Spearman rho|", FIG_DIR / "03_top20_spearman_bar.png", "spearman_r")

    best_feature = str(top_pearson.iloc[0]["feature"])
    x_best = features[best_feature].to_numpy(dtype=float)
    pr, pp, _ = safe_corr(x_best, y, "pearson")
    sr, sp, _ = safe_corr(x_best, y, "spearman")
    fig, ax = plt.subplots(figsize=(6.8, 5.2))
    ax.scatter(x_best, y, s=34, alpha=0.82, color="#4c78a8", edgecolor="white", linewidth=0.4)
    coef = np.polyfit(x_best, y, 1)
    xx = np.linspace(np.nanmin(x_best), np.nanmax(x_best), 100)
    ax.plot(xx, coef[0] * xx + coef[1], color="#d62728", lw=2.0)
    ax.set_title(f"Best Pearson Index: r={pr:.3f}, rho={sr:.3f}")
    ax.set_xlabel(best_feature)
    ax.set_ylabel("Reference CDOM product")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "04_best_pearson_index_scatter.png")
    plt.close(fig)

    # Train/test split first. Feature selection below uses training data only.
    train_idx, test_idx = train_test_split(np.arange(len(y)), test_size=TEST_SIZE, random_state=RANDOM_STATE)
    X_train_all = features.iloc[train_idx].reset_index(drop=True)
    X_test_all = features.iloc[test_idx].reset_index(drop=True)
    y_train = y[train_idx]
    y_test = y[test_idx]

    train_corr = correlation_table(X_train_all, y_train)
    candidates = preselect_unique_features(train_corr, PEARSON_PRESELECT_N)
    pd.DataFrame({"feature": candidates}).to_csv(OUT_DIR / "04_train_pearson_preselected_features.csv", index=False, encoding="utf-8-sig")

    vif_features, vif_before, vif_after = vif_filter(X_train_all, candidates)
    save_barh(vif_before.head(20), "feature", "vif", "VIF Before Filtering (Top 20)", "VIF", FIG_DIR / "05_vif_before_filter.png")
    save_barh(vif_after, "feature", "vif", f"VIF After Filtering (threshold={VIF_THRESHOLD:g})", "VIF", FIG_DIR / "06_vif_after_filter.png")

    corr_matrix = X_train_all[vif_features].corr()
    corr_matrix.to_csv(OUT_DIR / "07_vif_filtered_feature_correlation_matrix.csv", encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(corr_matrix, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(vif_features)))
    ax.set_yticks(range(len(vif_features)))
    ax.set_xticklabels(vif_features, rotation=45, ha="right")
    ax.set_yticklabels(vif_features)
    ax.set_title("Correlation Matrix After VIF Filtering")
    cbar = fig.colorbar(im, ax=ax, shrink=0.82)
    cbar.set_label("Pearson correlation")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "07_vif_filtered_correlation_heatmap.png")
    plt.close(fig)

    relief = regression_relieff_scores(X_train_all[vif_features], y_train, RELIEFF_NEIGHBORS)
    save_barh(relief, "feature", "relieff_score", "ReliefF-style Feature Ranking", "ReliefF score", FIG_DIR / "08_relieff_feature_ranking.png", top_n=min(15, len(relief)))

    final_features = relief.head(min(FINAL_FEATURE_COUNT, len(relief)))["feature"].tolist()
    pd.DataFrame({"feature": final_features}).to_csv(OUT_DIR / "07_final_model_features.csv", index=False, encoding="utf-8-sig")
    key_spectral_bands, _ = select_key_spectral_bands(top_pearson, top_spearman, final_features)
    save_key_band_representative_spectra(samples, key_spectral_bands)
    selected_dataset = pd.concat(
        [
            samples[["LON", "LAT", TARGET_COL] + (["stratifier_B11_B3"] if "stratifier_B11_B3" in samples.columns else [])],
            features[final_features],
        ],
        axis=1,
    )
    selected_dataset.to_csv(OUT_DIR / "08_final_feature_dataset.csv", index=False, encoding="utf-8-sig")

    X_train = X_train_all[final_features]
    X_test = X_test_all[final_features]
    models = tune_and_fit_models(X_train, y_train)
    metrics_df, pred_tables = evaluate_models(models, X_train, X_test, y_train, y_test)
    cv_df = cross_validate_models(models, pd.concat([X_train, X_test], axis=0).reset_index(drop=True), np.concatenate([y_train, y_test]))
    save_metric_bars(metrics_df)
    save_cv_metric_bars(cv_df)
    plot_prediction_grid(pred_tables, metrics_df)
    shap_for_best_tree_model(models, metrics_df, X_train, X_test)

    # Permutation importance for the best model, useful as model-agnostic comparison to SHAP.
    best_model_name = str(metrics_df.iloc[0]["model"])
    best_model = models[best_model_name]
    perm = permutation_importance(best_model, X_test, y_test, n_repeats=50, random_state=RANDOM_STATE, scoring="r2", n_jobs=-1)
    perm_df = pd.DataFrame(
        {
            "feature": final_features,
            "importance_mean": perm.importances_mean,
            "importance_std": perm.importances_std,
        }
    ).sort_values("importance_mean", ascending=False)
    perm_df.to_csv(OUT_DIR / f"12_{best_model_name}_permutation_importance.csv", index=False, encoding="utf-8-sig")
    save_barh(perm_df, "feature", "importance_mean", f"Permutation Importance ({best_model_name})", "Mean decrease in R²", FIG_DIR / "17_permutation_importance.png")

    summary = {
        "data_note": "Target is a public reference CDOM remote-sensing product extracted as mean, not in-situ field measurement.",
        "use_optical_stratum": USE_OPTICAL_STRATUM,
        "stratifier": STRATIFIER_NAME if USE_OPTICAL_STRATUM else None,
        "stratifier_quantile": STRATIFIER_QUANTILE if USE_OPTICAL_STRATUM else None,
        "stratifier_threshold": stratum_threshold,
        "n_samples": int(len(samples)),
        "n_generated_features": int(features.shape[1]),
        "pearson_preselect_n": PEARSON_PRESELECT_N,
        "vif_threshold": VIF_THRESHOLD,
        "vif_features": vif_features,
        "final_features_after_relieff": final_features,
        "key_spectral_bands_for_main_figure": key_spectral_bands,
        "model_metrics": metrics_df.to_dict(orient="records"),
        "cross_validation_metrics": cv_df.to_dict(orient="records"),
    }
    with open(OUT_DIR / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("Complete ML pipeline finished.")
    print(f"Samples: {len(samples)}")
    print(f"Generated features: {features.shape[1]}")
    if stratum_threshold is not None:
        print(f"Optical stratum: B11/B3 <= {stratum_threshold:.6f}")
    print("\nFinal features:")
    print(pd.Series(final_features).to_string(index=False))
    print("\nModel metrics:")
    print(metrics_df[["model", "test_r2", "test_rmse", "test_mae", "test_mape_percent", "train_r2", "train_rmse", "train_mae"]].to_string(index=False))
    print("\n5-fold CV metrics:")
    print(cv_df[["model", "cv_r2", "cv_rmse", "cv_mae", "cv_mape_percent"]].to_string(index=False))
    print(f"\nOutputs saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
