// Chagan Lake Jun-Sep seasonal Landsat composites for historical CDOM mapping.
// Copy this script into https://code.earthengine.google.com/ and run it.
//
// Why Landsat instead of Sentinel-2?
// Sentinel-2 starts in 2015. A 1986-2026 time series must use Landsat for the
// historical years. This script exports harmonized Landsat Collection 2 Level-2
// surface reflectance bands for local Python CDOM modelling.
//
// Date note:
// Today is 2026-05-16. The 2026 Jun-Sep season is not complete yet, so the
// default export list stops at 2021. Add 2026 only after 2026-09-30.

var roi = ee.Geometry.Rectangle([123.98, 45.13, 124.47, 45.46], null, false);

var EXPORT_YEARS = [1986, 1991, 1996, 2001, 2006, 2011, 2016, 2021];
// After 2026-09-30, you may use:
// var EXPORT_YEARS = [1986, 1991, 1996, 2001, 2006, 2011, 2016, 2021, 2026];

var EXPORT_FOLDER = "ChaganLake_CDOM_GEE_Exports";
var EXPORT_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2", "MNDWI", "NDVI"];

Map.centerObject(roi, 11);
Map.addLayer(roi, {color: "red"}, "Chagan Lake ROI");

function maskLandsatC2L2(image) {
  var qa = image.select("QA_PIXEL");
  var clearMask = qa.bitwiseAnd(1 << 0).eq(0)   // fill
    .and(qa.bitwiseAnd(1 << 1).eq(0))           // dilated cloud
    .and(qa.bitwiseAnd(1 << 2).eq(0))           // cirrus
    .and(qa.bitwiseAnd(1 << 3).eq(0))           // cloud
    .and(qa.bitwiseAnd(1 << 4).eq(0))           // cloud shadow
    .and(qa.bitwiseAnd(1 << 5).eq(0));          // snow
  var saturationMask = image.select("QA_RADSAT").eq(0);
  return image.updateMask(clearMask).updateMask(saturationMask);
}

function addWaterMaskAndIndices(image) {
  var mndwi = image.normalizedDifference(["Green", "SWIR1"]).rename("MNDWI");
  var ndvi = image.normalizedDifference(["NIR", "Red"]).rename("NDVI");
  var positive = image.select(["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .reduce(ee.Reducer.min()).gt(0);
  var validRange = image.select(["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .reduce(ee.Reducer.max()).lt(1);
  var waterMask = mndwi.gt(0).and(ndvi.lt(0.35)).and(positive).and(validRange);
  return image.addBands([mndwi, ndvi]).updateMask(waterMask).clip(roi);
}

function prepL57(image) {
  image = maskLandsatC2L2(image);
  var optical = image
    .select(["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"],
            ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .multiply(0.0000275)
    .add(-0.2);
  return addWaterMaskAndIndices(optical)
    .copyProperties(image, image.propertyNames());
}

function prepL89(image) {
  image = maskLandsatC2L2(image);

  // Landsat 8/9 aerosol QA: bits 6-7 are aerosol level. Exclude high aerosol.
  var aerosol = image.select("SR_QA_AEROSOL");
  var aerosolLevel = aerosol.rightShift(6).bitwiseAnd(3);
  image = image.updateMask(aerosolLevel.lte(2));

  var optical = image
    .select(["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"],
            ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .multiply(0.0000275)
    .add(-0.2);
  return addWaterMaskAndIndices(optical)
    .copyProperties(image, image.propertyNames());
}

function collectionForYear(year) {
  var start = ee.Date.fromYMD(year, 6, 1);
  var end = ee.Date.fromYMD(year, 10, 1);
  var col = ee.ImageCollection([]);

  if (year <= 2011) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LT05/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL57)
    );
  }

  if (year >= 1999 && year <= 2021) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LE07/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL57)
    );
  }

  if (year >= 2013) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL89)
    );
  }

  if (year >= 2022) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LC09/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL89)
    );
  }

  return col;
}

function compositeForYear(year) {
  var col = collectionForYear(year);
  print("Year " + year + " valid image count", col.size());
  return col
    .median()
    .select(EXPORT_BANDS)
    .clip(roi)
    .set({
      "year": year,
      "season": "June-September",
      "preprocessing": "Landsat C2 L2 SR, QA cloud/shadow/snow/saturation mask, high aerosol mask for L8/L9, water mask, seasonal median"
    });
}

EXPORT_YEARS.forEach(function(year) {
  var image = compositeForYear(year);
  var vis = {bands: ["SWIR1", "NIR", "Red"], min: 0, max: 0.35};
  Map.addLayer(image, vis, "Composite " + year, false);

  Export.image.toDrive({
    image: image.toFloat(),
    description: "ChaganLake_harmonized_SR_" + year + "_JunSep",
    folder: EXPORT_FOLDER,
    fileNamePrefix: "ChaganLake_harmonized_SR_" + year + "_JunSep",
    region: roi,
    scale: 30,
    crs: "EPSG:4326",
    maxPixels: 1e13
  });
});
