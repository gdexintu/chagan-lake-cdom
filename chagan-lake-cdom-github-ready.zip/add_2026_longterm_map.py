from __future__ import annotations

import math
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio


BASE_DIR = Path(__file__).resolve().parent
INPUT_TIF = BASE_DIR / "gee_exports" / "ChaganLake_harmonized_SR_2026_to_20260516.tif"
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "cross_sensor_longterm"
FIG_DIR = OUT_DIR / "figures"
RASTER_DIR = OUT_DIR / "rasters"
TABLE_DIR = OUT_DIR / "tables"
MODEL_PATH = OUT_DIR / "models" / "ExtraTrees_cross_sensor_model.joblib"
SAMPLES_PATH = BASE_DIR / "outputs" / "cdom_2020" / "complete_ml_pipeline" / "01_clean_stratified_samples.csv"
STATS_PATH = TABLE_DIR / "11_longterm_cdom_raster_stats.csv"

COMMON_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"]
EPS = 1e-6


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 260
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 12
    plt.rcParams["axes.labelsize"] = 10
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 9


def read_common_bands(path: Path):
    with rasterio.open(path) as src:
        names = [desc or "" for desc in src.descriptions]
        if all(b in names for b in COMMON_BANDS):
            arrays = {b: src.read(names.index(b) + 1).astype("float32") for b in COMMON_BANDS}
        else:
            arrays = {b: src.read(i + 1).astype("float32") for i, b in enumerate(COMMON_BANDS)}
        profile = src.profile.copy()
    return arrays, profile


def build_selected_feature_frame(arrays: dict[str, np.ndarray], valid: np.ndarray) -> pd.DataFrame:
    blue = arrays["Blue"][valid].astype(float)
    green = arrays["Green"][valid].astype(float)
    red = arrays["Red"][valid].astype(float)
    nir = arrays["NIR"][valid].astype(float)
    swir1 = arrays["SWIR1"][valid].astype(float)
    swir2 = arrays["SWIR2"][valid].astype(float)

    frame = pd.DataFrame(
        {
            "(Blue/NIR)^1.5": np.power(np.clip((blue + EPS) / (nir + EPS), 0, None), 1.5),
            "NIR/(Red+SWIR2)": nir / (red + swir2 + EPS),
            "NDI_Red_NIR": (red - nir) / (red + nir + EPS),
            "Blue/(NIR+Red)": blue / (nir + red + EPS),
            "log((SWIR1+Blue)/NIR)": np.log((swir1 + blue + EPS) / (nir + EPS)),
            "Blue/(NIR+Green)": blue / (nir + green + EPS),
        }
    )
    return frame


def predict_2026() -> pd.DataFrame:
    model = joblib.load(MODEL_PATH)
    arrays, profile = read_common_bands(INPUT_TIF)
    stack = np.stack([arrays[b] for b in COMMON_BANDS])
    valid = np.isfinite(stack).all(axis=0)
    valid &= (stack > 0).all(axis=0)
    valid &= (stack < 1).all(axis=0)

    pred = np.full(valid.shape, np.nan, dtype="float32")
    if int(valid.sum()) > 0:
        features = build_selected_feature_frame(arrays, valid)
        samples = pd.read_csv(SAMPLES_PATH)
        y_clip = (float(samples["mean"].quantile(0.005)), float(samples["mean"].quantile(0.995)))
        values = model.predict(features)
        pred[valid] = np.clip(values, y_clip[0], y_clip[1]).astype("float32")

    out_path = RASTER_DIR / "ChaganLake_CDOM_ExtraTrees_2026_to_20260516.tif"
    profile.update(count=1, dtype="float32", nodata=np.nan, compress="deflate")
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(pred, 1)
        dst.update_tags(year="2026", period="to_20260516", source_file=INPUT_TIF.name, model="ExtraTrees")

    finite = pred[np.isfinite(pred)]
    row = {
        "year": 2026,
        "source_file": INPUT_TIF.name,
        "output_file": out_path.name,
        "model": "ExtraTrees",
        "valid_pixels": int(len(finite)),
        "mean_cdom": float(np.nanmean(finite)) if len(finite) else np.nan,
        "median_cdom": float(np.nanmedian(finite)) if len(finite) else np.nan,
        "std_cdom": float(np.nanstd(finite)) if len(finite) else np.nan,
        "min_cdom": float(np.nanmin(finite)) if len(finite) else np.nan,
        "max_cdom": float(np.nanmax(finite)) if len(finite) else np.nan,
    }

    stats = pd.read_csv(STATS_PATH)
    stats = stats[stats["year"] != 2026]
    stats = pd.concat([stats, pd.DataFrame([row])], ignore_index=True).sort_values("year")
    stats.to_csv(STATS_PATH, index=False, encoding="utf-8-sig")
    return stats


def draw_longterm_figures(stats: pd.DataFrame) -> None:
    setup_plot_style()
    rasters = []
    for _, row in stats.sort_values("year").iterrows():
        path = RASTER_DIR / row["output_file"]
        with rasterio.open(path) as src:
            arr = src.read(1).astype(float)
            bounds = src.bounds
        rasters.append((int(row["year"]), arr, bounds))

    finite = np.concatenate([arr[np.isfinite(arr)] for _, arr, _ in rasters if np.isfinite(arr).any()])
    vmin = float(np.nanpercentile(finite, 2))
    vmax = float(np.nanpercentile(finite, 98))

    fig, axes = plt.subplots(3, 3, figsize=(11.2, 9.3), constrained_layout=True)
    axes = axes.ravel()
    letters = "abcdefghi"
    im = None
    for i, (year, arr, bounds) in enumerate(rasters):
        ax = axes[i]
        im = ax.imshow(
            arr,
            cmap="YlOrBr",
            vmin=vmin,
            vmax=vmax,
            extent=[bounds.left, bounds.right, bounds.bottom, bounds.top],
            origin="upper",
        )
        suffix = "*" if year == 2026 else ""
        ax.set_title(f"({letters[i]}) {year}{suffix}", loc="left")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)

    cbar = fig.colorbar(im, ax=axes, shrink=0.82, location="bottom", pad=0.045)
    cbar.set_label("Predicted CDOM")
    fig.savefig(FIG_DIR / "04_longterm_cdom_spatial_panel_with_2026.png")
    plt.close(fig)

    data = stats.sort_values("year")
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    hist = data[data["year"] < 2026]
    current = data[data["year"] == 2026]
    ax.plot(hist["year"], hist["mean_cdom"], marker="o", lw=2.3, color="#a6611a", label="Jun-Sep mean")
    ax.fill_between(
        hist["year"].to_numpy(dtype=float),
        (hist["mean_cdom"] - hist["std_cdom"]).to_numpy(dtype=float),
        (hist["mean_cdom"] + hist["std_cdom"]).to_numpy(dtype=float),
        color="#dfc27d",
        alpha=0.28,
        linewidth=0,
        label="Mean ± SD",
    )
    if not current.empty:
        ax.scatter(
            current["year"],
            current["mean_cdom"],
            marker="s",
            s=62,
            facecolor="#d73027",
            edgecolor="white",
            linewidth=0.8,
            label="2026 partial-year",
            zorder=4,
        )
        ax.plot(
            [hist["year"].iloc[-1], current["year"].iloc[0]],
            [hist["mean_cdom"].iloc[-1], current["mean_cdom"].iloc[0]],
            ls="--",
            lw=1.4,
            color="#d73027",
            alpha=0.7,
        )
    ax.set_xlabel("Year")
    ax.set_ylabel("Predicted CDOM")
    ax.set_title("Chagan Lake CDOM Change from 1986 to 2026")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, ncol=3, loc="best")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "05_longterm_cdom_time_series_with_2026.png")
    plt.close(fig)


def main() -> None:
    stats = predict_2026()
    draw_longterm_figures(stats)
    print(stats.tail(3).to_string(index=False))


if __name__ == "__main__":
    main()
