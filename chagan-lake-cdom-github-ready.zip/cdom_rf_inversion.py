from __future__ import annotations

import json
import math
from itertools import combinations, permutations
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window
from scipy.stats import pearsonr, spearmanr
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import mutual_info_regression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold, KFold, RandomizedSearchCV, train_test_split


BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "CDOM_Extracted_2020.csv"
TIF_PATH = BASE_DIR / "S2_2020_AllBands_Median.tif"
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020"

TARGET_COL = "mean"
GEO_COL = ".geo"
RANDOM_STATE = 42
EPS = 1e-6
BLOCK_SIZE = 512
TARGET_SOURCE = "Public remote-sensing CDOM product mean extracted from the source dataset; not field measurements."
TARGET_LABEL = "Reference CDOM product"

REFLECTANCE_BANDS = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
EXPECTED_BANDS = REFLECTANCE_BANDS + [
    "AOT",
    "WVP",
    "SCL",
    "TCI_R",
    "TCI_G",
    "TCI_B",
    "MSK_CLDPRB",
    "MSK_SNWPRB",
    "QA10",
    "QA20",
    "QA60",
    "MSK_CLASSI_OPAQUE",
    "MSK_CLASSI_CIRRUS",
    "MSK_CLASSI_SNOW_ICE",
]


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 180
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False


def add_report(report: List[dict], step: str, before: int, after: int, note: str = "") -> None:
    report.append({"step": step, "removed": int(before - after), "remaining": int(after), "note": note})


def polygon_centroid(ring: Sequence[Sequence[float]]) -> Tuple[float, float]:
    if not ring:
        return (np.nan, np.nan)

    pts = [(float(p[0]), float(p[1])) for p in ring if len(p) >= 2]
    if len(pts) == 1:
        return pts[0]
    if len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    if len(pts) < 3:
        xs, ys = zip(*pts)
        return (float(np.mean(xs)), float(np.mean(ys)))

    area2 = 0.0
    cx = 0.0
    cy = 0.0
    closed = pts + [pts[0]]
    for (x0, y0), (x1, y1) in zip(closed[:-1], closed[1:]):
        cross = x0 * y1 - x1 * y0
        area2 += cross
        cx += (x0 + x1) * cross
        cy += (y0 + y1) * cross

    if abs(area2) < 1e-15:
        xs, ys = zip(*pts)
        return (float(np.mean(xs)), float(np.mean(ys)))
    return (cx / (3.0 * area2), cy / (3.0 * area2))


def iter_polygon_rings(geo: dict) -> Iterable[Sequence[Sequence[float]]]:
    gtype = geo.get("type")
    if gtype == "Polygon":
        if geo.get("coordinates"):
            yield geo["coordinates"][0]
    elif gtype == "MultiPolygon":
        for poly in geo.get("coordinates", []):
            if poly:
                yield poly[0]
    elif gtype == "GeometryCollection":
        for geom in geo.get("geometries", []):
            yield from iter_polygon_rings(geom)


def centroid_from_geojson(geo_str: str) -> Tuple[float, float]:
    try:
        geo = json.loads(geo_str)
    except Exception:
        return (np.nan, np.nan)

    rings = list(iter_polygon_rings(geo))
    if rings:
        centroids = []
        weights = []
        for ring in rings:
            c = polygon_centroid(ring)
            pts = [(float(p[0]), float(p[1])) for p in ring if len(p) >= 2]
            if len(pts) > 1 and pts[0] == pts[-1]:
                pts = pts[:-1]
            area = 0.0
            if len(pts) >= 3:
                closed = pts + [pts[0]]
                for (x0, y0), (x1, y1) in zip(closed[:-1], closed[1:]):
                    area += x0 * y1 - x1 * y0
                area = abs(area) / 2.0
            centroids.append(c)
            weights.append(area if area > 0 else 1.0)
        if centroids:
            xs = np.array([c[0] for c in centroids], dtype=float)
            ys = np.array([c[1] for c in centroids], dtype=float)
            ws = np.array(weights, dtype=float)
            return (float(np.average(xs, weights=ws)), float(np.average(ys, weights=ws)))

    if geo.get("type") == "Point":
        coords = geo.get("coordinates", [])
        if len(coords) >= 2:
            return (float(coords[0]), float(coords[1]))

    if geo.get("type") == "GeometryCollection":
        for geom in geo.get("geometries", []):
            if geom.get("type") == "Point":
                coords = geom.get("coordinates", [])
                if len(coords) >= 2:
                    return (float(coords[0]), float(coords[1]))

    return (np.nan, np.nan)


def get_band_names(src: rasterio.io.DatasetReader) -> List[str]:
    names = [name if name else EXPECTED_BANDS[i] if i < len(EXPECTED_BANDS) else f"band_{i+1}" for i, name in enumerate(src.descriptions)]
    return list(names)


def sample_raster_at_points(df: pd.DataFrame, report: List[dict]) -> Tuple[pd.DataFrame, Dict[str, float], Dict[str, int]]:
    with rasterio.open(TIF_PATH) as src:
        band_names = get_band_names(src)
        band_indexes = {name: idx + 1 for idx, name in enumerate(band_names)}
        missing = [b for b in REFLECTANCE_BANDS if b not in band_indexes]
        if missing:
            raise ValueError(f"Raster is missing required bands: {missing}")

        before = len(df)
        bounds = src.bounds
        inside = (
            df["lon"].between(bounds.left, bounds.right)
            & df["lat"].between(bounds.bottom, bounds.top)
            & np.isfinite(df["lon"])
            & np.isfinite(df["lat"])
        )
        df = df.loc[inside].copy()
        add_report(report, "drop points outside raster bounds", before, len(df), f"raster CRS={src.crs}")

        coords = list(zip(df["lon"], df["lat"]))
        samples = np.array(list(src.sample(coords)), dtype=float)

    for i, name in enumerate(band_names):
        df[name] = samples[:, i]

    scale_factors: Dict[str, float] = {}
    for band in REFLECTANCE_BANDS:
        vals = pd.to_numeric(df[band], errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
        q99 = float(vals.abs().quantile(0.99)) if len(vals) else np.nan
        scale = 10000.0 if np.isfinite(q99) and q99 > 2.0 else 1.0
        scale_factors[band] = scale
        df[band] = df[band].astype(float) / scale

    before = len(df)
    finite_mask = np.ones(len(df), dtype=bool)
    for band in REFLECTANCE_BANDS:
        finite_mask &= np.isfinite(df[band].to_numpy(dtype=float))
        finite_mask &= df[band].between(0.0, 1.2).to_numpy()
    df = df.loc[finite_mask].copy()
    add_report(report, "drop invalid reflectance samples", before, len(df), "kept 0 <= scaled reflectance <= 1.2")

    if "SCL" in df.columns:
        before = len(df)
        water = np.rint(df["SCL"].astype(float)).astype(int) == 6
        water_count = int(water.sum())
        if water_count >= 30:
            df = df.loc[water].copy()
            add_report(report, "keep SCL water samples", before, len(df), "SCL rounded to 6")
        else:
            add_report(report, "SCL water filter skipped", before, before, f"only {water_count} water samples")

    return df, scale_factors, band_indexes


def load_and_clean_samples() -> Tuple[pd.DataFrame, Dict[str, float], Dict[str, int], pd.DataFrame]:
    report: List[dict] = []
    df = pd.read_csv(CSV_PATH, low_memory=False)
    original_count = len(df)
    add_report(report, "read raw CSV", original_count, original_count, str(CSV_PATH))

    if TARGET_COL not in df.columns:
        raise KeyError(f"CSV does not contain target column '{TARGET_COL}'")
    if GEO_COL not in df.columns:
        raise KeyError(f"CSV does not contain geometry column '{GEO_COL}'")

    df["cdom"] = pd.to_numeric(df[TARGET_COL], errors="coerce")

    before = len(df)
    df = df.loc[df["cdom"].notna()].copy()
    add_report(report, "drop missing CDOM", before, len(df), "target column: mean; reference product, not in-situ")

    before = len(df)
    df = df.loc[df["cdom"] > 0].copy()
    add_report(report, "drop non-positive CDOM", before, len(df), "CDOM/absorption values should be positive")

    centroids = df[GEO_COL].apply(centroid_from_geojson)
    df["lon"] = [c[0] for c in centroids]
    df["lat"] = [c[1] for c in centroids]
    before = len(df)
    df = df.loc[np.isfinite(df["lon"]) & np.isfinite(df["lat"])].copy()
    add_report(report, "drop invalid geometries", before, len(df), "centroid parsed from .geo")

    q1 = df["cdom"].quantile(0.25)
    q3 = df["cdom"].quantile(0.75)
    iqr = q3 - q1
    low = q1 - 3.0 * iqr
    high = q3 + 3.0 * iqr
    before = len(df)
    df = df.loc[df["cdom"].between(low, high)].copy()
    add_report(report, "drop extreme CDOM outliers", before, len(df), f"3*IQR range [{low:.4f}, {high:.4f}]")

    df, scale_factors, band_indexes = sample_raster_at_points(df, report)

    before = len(df)
    df = df.drop_duplicates(subset=["lon", "lat", "cdom"]).copy()
    add_report(report, "drop exact duplicate samples", before, len(df), "same lon, lat, cdom")

    report_df = pd.DataFrame(report)
    return df.reset_index(drop=True), scale_factors, band_indexes, report_df


def feature_formula(name: str) -> str:
    if name in REFLECTANCE_BANDS:
        return name
    parts = name.split("_")
    if name.startswith("RATIO_") and len(parts) == 3:
        return f"{parts[1]} / {parts[2]}"
    if name.startswith("LOGRATIO_") and len(parts) == 3:
        return f"log({parts[1]} / {parts[2]})"
    if name.startswith("NDI_") and len(parts) == 3:
        return f"({parts[1]} - {parts[2]}) / ({parts[1]} + {parts[2]})"
    if name.startswith("DIFF_") and len(parts) == 3:
        return f"{parts[1]} - {parts[2]}"
    return name


def build_feature_frame(df: pd.DataFrame) -> pd.DataFrame:
    out: Dict[str, np.ndarray] = {}
    band_arrays = {band: df[band].to_numpy(dtype=float) for band in REFLECTANCE_BANDS}

    for band, arr in band_arrays.items():
        out[band] = arr

    for b1, b2 in permutations(REFLECTANCE_BANDS, 2):
        out[f"RATIO_{b1}_{b2}"] = (band_arrays[b1] + EPS) / (band_arrays[b2] + EPS)
        out[f"LOGRATIO_{b1}_{b2}"] = np.log((band_arrays[b1] + EPS) / (band_arrays[b2] + EPS))

    for b1, b2 in combinations(REFLECTANCE_BANDS, 2):
        out[f"NDI_{b1}_{b2}"] = (band_arrays[b1] - band_arrays[b2]) / (band_arrays[b1] + band_arrays[b2] + EPS)
        out[f"DIFF_{b1}_{b2}"] = band_arrays[b1] - band_arrays[b2]

    features = pd.DataFrame(out)
    features.replace([np.inf, -np.inf], np.nan, inplace=True)
    return features


def safe_pearson(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3 or np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
        return (np.nan, np.nan)
    r, p = pearsonr(x[mask], y[mask])
    return (float(r), float(p))


def safe_spearman(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3 or np.nanstd(x[mask]) == 0 or np.nanstd(y[mask]) == 0:
        return (np.nan, np.nan)
    r, p = spearmanr(x[mask], y[mask])
    return (float(r), float(p))


def correlation_tables(features: pd.DataFrame, y: pd.Series) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    y_arr = y.to_numpy(dtype=float)
    for col in features.columns:
        x = features[col].to_numpy(dtype=float)
        pr, pp = safe_pearson(x, y_arr)
        sr, sp = safe_spearman(x, y_arr)
        rows.append(
            {
                "feature": col,
                "formula": feature_formula(col),
                "pearson_r": pr,
                "pearson_p": pp,
                "spearman_r": sr,
                "spearman_p": sp,
                "abs_pearson": abs(pr) if np.isfinite(pr) else np.nan,
                "abs_spearman": abs(sr) if np.isfinite(sr) else np.nan,
            }
        )

    corr = pd.DataFrame(rows).sort_values("abs_pearson", ascending=False)

    clean = features.replace([np.inf, -np.inf], np.nan).dropna(axis=0)
    y_aligned = y.loc[clean.index]
    mi = mutual_info_regression(clean, y_aligned, random_state=RANDOM_STATE)
    mi_df = pd.DataFrame({"feature": clean.columns, "mutual_info": mi})
    corr = corr.merge(mi_df, on="feature", how="left")
    corr.sort_values(["abs_pearson", "mutual_info"], ascending=False, inplace=True)

    raw_corr = corr[corr["feature"].isin(REFLECTANCE_BANDS)].copy()
    raw_corr.sort_values("abs_pearson", ascending=False, inplace=True)
    return corr, raw_corr


def choose_features(corr: pd.DataFrame) -> List[str]:
    pearson_top = corr.head(20)["feature"].tolist()
    spearman_top = corr.sort_values("abs_spearman", ascending=False).head(10)["feature"].tolist()
    mi_top = corr.sort_values("mutual_info", ascending=False).head(10)["feature"].tolist()
    raw_top = corr[corr["feature"].isin(REFLECTANCE_BANDS)].head(6)["feature"].tolist()

    selected: List[str] = []
    for name in raw_top + pearson_top + spearman_top + mi_top:
        if name not in selected:
            selected.append(name)
    return selected[:30]


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    r, p = safe_pearson(np.asarray(y_pred), np.asarray(y_true))
    return {"r2": float(r2), "rmse": float(rmse), "mae": float(mae), "pearson_r": float(r), "pearson_p": float(p)}


def spatial_groups(df: pd.DataFrame, bins: int = 5) -> pd.Series:
    lon_bins = pd.qcut(df["lon"], q=min(bins, df["lon"].nunique()), labels=False, duplicates="drop")
    lat_bins = pd.qcut(df["lat"], q=min(bins, df["lat"].nunique()), labels=False, duplicates="drop")
    groups = lon_bins.astype(str) + "_" + lat_bins.astype(str)
    return groups


def cross_val_predictions(model: RandomForestRegressor, X: pd.DataFrame, y: pd.Series, splitter, groups=None) -> Tuple[pd.DataFrame, Dict[str, float]]:
    pred = pd.Series(index=y.index, dtype=float)
    fold_rows = []
    split_iter = splitter.split(X, y, groups) if groups is not None else splitter.split(X, y)
    for fold, (train_idx, test_idx) in enumerate(split_iter, start=1):
        fold_model = clone(model)
        fold_model.fit(X.iloc[train_idx], y.iloc[train_idx])
        yhat = fold_model.predict(X.iloc[test_idx])
        pred.iloc[test_idx] = yhat
        metrics = regression_metrics(y.iloc[test_idx].to_numpy(), yhat)
        metrics["fold"] = fold
        metrics["n_test"] = int(len(test_idx))
        fold_rows.append(metrics)
    overall = regression_metrics(y.to_numpy(), pred.to_numpy())
    return pd.DataFrame(fold_rows), overall


def train_random_forest(features: pd.DataFrame, y: pd.Series, selected_features: List[str], sample_df: pd.DataFrame):
    X = features[selected_features].copy()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=RANDOM_STATE)

    base = RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True)
    param_dist = {
        "n_estimators": [300, 500, 800],
        "max_depth": [None, 6, 10, 16, 24],
        "min_samples_leaf": [1, 2, 4, 8],
        "min_samples_split": [2, 5, 10],
        "max_features": ["sqrt", 0.5, 0.8, 1.0],
    }
    cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    search = RandomizedSearchCV(
        base,
        param_distributions=param_dist,
        n_iter=35,
        scoring="neg_root_mean_squared_error",
        cv=cv,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbose=0,
    )
    search.fit(X_train, y_train)
    model: RandomForestRegressor = search.best_estimator_

    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)
    metrics = {
        "best_params": search.best_params_,
        "best_cv_rmse": float(-search.best_score_),
        "train": regression_metrics(y_train.to_numpy(), train_pred),
        "test": regression_metrics(y_test.to_numpy(), test_pred),
        "oob_score": float(getattr(model, "oob_score_", np.nan)),
        "n_samples": int(len(y)),
        "n_features": int(len(selected_features)),
    }

    final_model = clone(model)
    final_model.fit(X, y)

    random_cv_rows, random_cv_overall = cross_val_predictions(final_model, X, y, KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE))
    metrics["random_5fold"] = random_cv_overall

    groups = spatial_groups(sample_df.loc[X.index])
    n_groups = groups.nunique()
    if n_groups >= 5:
        spatial_rows, spatial_overall = cross_val_predictions(final_model, X, y, GroupKFold(n_splits=5), groups=groups)
        metrics["spatial_group_5fold"] = spatial_overall
    else:
        spatial_rows = pd.DataFrame()
        metrics["spatial_group_5fold"] = {"note": f"skipped, only {n_groups} groups"}

    pred_df = pd.DataFrame(
        {
            "obs": y_test,
            "pred": test_pred,
            "residual": y_test - test_pred,
            "lon": sample_df.loc[y_test.index, "lon"],
            "lat": sample_df.loc[y_test.index, "lat"],
        }
    )

    importance = pd.DataFrame(
        {
            "feature": selected_features,
            "formula": [feature_formula(f) for f in selected_features],
            "importance": final_model.feature_importances_,
        }
    ).sort_values("importance", ascending=False)

    return final_model, metrics, pred_df, importance, random_cv_rows, spatial_rows


def compute_feature_array(name: str, arrays: Dict[str, np.ndarray]) -> np.ndarray:
    if name in REFLECTANCE_BANDS:
        return arrays[name]
    parts = name.split("_")
    if name.startswith("RATIO_") and len(parts) == 3:
        return (arrays[parts[1]] + EPS) / (arrays[parts[2]] + EPS)
    if name.startswith("LOGRATIO_") and len(parts) == 3:
        return np.log((arrays[parts[1]] + EPS) / (arrays[parts[2]] + EPS))
    if name.startswith("NDI_") and len(parts) == 3:
        return (arrays[parts[1]] - arrays[parts[2]]) / (arrays[parts[1]] + arrays[parts[2]] + EPS)
    if name.startswith("DIFF_") and len(parts) == 3:
        return arrays[parts[1]] - arrays[parts[2]]
    raise ValueError(f"Unknown feature expression: {name}")


def bands_needed(features: Sequence[str]) -> List[str]:
    needed: List[str] = []
    for feature in features:
        if feature in REFLECTANCE_BANDS and feature not in needed:
            needed.append(feature)
        for token in feature.split("_"):
            if token in REFLECTANCE_BANDS and token not in needed:
                needed.append(token)
    return needed


def predict_raster(model: RandomForestRegressor, selected_features: List[str], scale_factors: Dict[str, float]) -> Path:
    output_path = OUT_DIR / "ChaganLake_CDOM_RF_2020.tif"
    needed = bands_needed(selected_features)
    nodata = -9999.0

    with rasterio.open(TIF_PATH) as src:
        names = get_band_names(src)
        band_indexes = {name: idx + 1 for idx, name in enumerate(names)}
        profile = src.profile.copy()
        profile.update(
            count=1,
            dtype="float32",
            nodata=nodata,
            compress="deflate",
            predictor=2,
            tiled=True,
            blockxsize=256,
            blockysize=256,
        )

        with rasterio.open(output_path, "w", **profile) as dst:
            for row in range(0, src.height, BLOCK_SIZE):
                height = min(BLOCK_SIZE, src.height - row)
                for col in range(0, src.width, BLOCK_SIZE):
                    width = min(BLOCK_SIZE, src.width - col)
                    window = Window(col, row, width, height)
                    arrays = {}
                    valid = np.ones((height, width), dtype=bool)

                    for band in needed:
                        arr = src.read(band_indexes[band], window=window, out_dtype="float32")
                        arr = arr / float(scale_factors.get(band, 1.0))
                        arrays[band] = arr
                        valid &= np.isfinite(arr) & (arr >= 0.0) & (arr <= 1.2)

                    if "SCL" in band_indexes:
                        scl = src.read(band_indexes["SCL"], window=window, out_dtype="float32")
                        valid &= np.rint(scl).astype(np.int16) == 6

                    feature_stack = []
                    for feature in selected_features:
                        vals = compute_feature_array(feature, arrays).astype("float32")
                        feature_stack.append(vals)
                        valid &= np.isfinite(vals)

                    block_pred = np.full((height, width), nodata, dtype="float32")
                    if valid.any():
                        X_block = np.stack(feature_stack, axis=-1)
                        X_valid = pd.DataFrame(X_block[valid], columns=selected_features)
                        block_pred[valid] = model.predict(X_valid).astype("float32")
                    dst.write(block_pred, 1, window=window)

    return output_path


def save_plots(
    raw_df: pd.DataFrame,
    cleaned_df: pd.DataFrame,
    corr: pd.DataFrame,
    raw_corr: pd.DataFrame,
    pred_df: pd.DataFrame,
    importance: pd.DataFrame,
    map_path: Path,
) -> None:
    setup_plot_style()
    plot_dir = OUT_DIR / "figures"
    plot_dir.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    raw_vals = pd.to_numeric(raw_df[TARGET_COL], errors="coerce")
    ax[0].hist(raw_vals.dropna(), bins=30, color="#5975a4", edgecolor="white")
    ax[0].set_title("Raw reference CDOM distribution")
    ax[0].set_xlabel("CDOM")
    ax[0].set_ylabel("Count")
    ax[1].hist(cleaned_df["cdom"], bins=30, color="#5f9e6e", edgecolor="white")
    ax[1].set_title("Cleaned reference CDOM distribution")
    ax[1].set_xlabel("CDOM")
    fig.tight_layout()
    fig.savefig(plot_dir / "01_cdom_distribution.png")
    plt.close(fig)

    top_raw = raw_corr.head(12).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(top_raw["feature"], top_raw["pearson_r"], color=np.where(top_raw["pearson_r"] >= 0, "#4c78a8", "#e45756"))
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title("Pearson correlation: raw Sentinel-2 bands vs CDOM")
    ax.set_xlabel("Pearson r")
    fig.tight_layout()
    fig.savefig(plot_dir / "02_raw_band_correlations.png")
    plt.close(fig)

    top = corr.head(15).iloc[::-1]
    labels = top["formula"].to_list()
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.barh(labels, top["pearson_r"], color=np.where(top["pearson_r"] >= 0, "#4c78a8", "#e45756"))
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title("Top spectral indices by Pearson correlation")
    ax.set_xlabel("Pearson r")
    fig.tight_layout()
    fig.savefig(plot_dir / "03_top_index_correlations.png")
    plt.close(fig)

    best_feature = corr.iloc[0]["feature"]
    best_formula = corr.iloc[0]["formula"]
    features_for_plot = build_feature_frame(cleaned_df)
    x = features_for_plot[best_feature]
    y = cleaned_df["cdom"]
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(x, y, s=20, alpha=0.65, color="#4c78a8", edgecolor="white", linewidth=0.3)
    if x.nunique() > 1:
        coeff = np.polyfit(x, y, 1)
        xx = np.linspace(x.min(), x.max(), 100)
        ax.plot(xx, coeff[0] * xx + coeff[1], color="#e45756", linewidth=2)
    ax.set_xlabel(best_formula)
    ax.set_ylabel(TARGET_LABEL)
    ax.set_title(f"Best index vs reference CDOM (r={corr.iloc[0]['pearson_r']:.3f})")
    fig.tight_layout()
    fig.savefig(plot_dir / "04_best_index_scatter.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 5.5))
    ax.scatter(pred_df["obs"], pred_df["pred"], s=24, alpha=0.7, color="#4c78a8", edgecolor="white", linewidth=0.3)
    low = min(pred_df["obs"].min(), pred_df["pred"].min())
    high = max(pred_df["obs"].max(), pred_df["pred"].max())
    ax.plot([low, high], [low, high], color="#e45756", linestyle="--", linewidth=1.5)
    ax.set_xlabel(TARGET_LABEL)
    ax.set_ylabel("Predicted CDOM")
    ax.set_title("RF validation against reference product")
    fig.tight_layout()
    fig.savefig(plot_dir / "05_rf_observed_vs_predicted.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    imp = importance.head(15).iloc[::-1]
    ax.barh(imp["formula"], imp["importance"], color="#59a14f")
    ax.set_xlabel("RF impurity importance")
    ax.set_title("Random forest feature importance")
    fig.tight_layout()
    fig.savefig(plot_dir / "06_rf_feature_importance.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(pred_df["pred"], pred_df["residual"], s=24, alpha=0.7, color="#f28e2b", edgecolor="white", linewidth=0.3)
    ax.axhline(0, color="black", linestyle="--", linewidth=1)
    ax.set_xlabel("Predicted CDOM")
    ax.set_ylabel("Residual")
    ax.set_title("Holdout residuals")
    fig.tight_layout()
    fig.savefig(plot_dir / "07_rf_residuals.png")
    plt.close(fig)

    with rasterio.open(map_path) as src:
        max_size = 1200
        scale = max(1, int(math.ceil(max(src.width, src.height) / max_size)))
        arr = src.read(1, out_shape=(1, src.height // scale, src.width // scale), masked=True)
        bounds = src.bounds
    data = np.ma.masked_where(arr == src.nodata if hasattr(src, "nodata") else False, arr)
    finite = data.compressed()
    vmin, vmax = (float(np.nanpercentile(finite, 2)), float(np.nanpercentile(finite, 98))) if finite.size else (0.0, 1.0)
    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(data, extent=[bounds.left, bounds.right, bounds.bottom, bounds.top], origin="upper", cmap="viridis", vmin=vmin, vmax=vmax)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("RF fitted CDOM from Sentinel-2, 2020")
    fig.colorbar(im, ax=ax, label="CDOM")
    fig.tight_layout()
    fig.savefig(plot_dir / "08_cdom_map_preview.png")
    plt.close(fig)


def write_summary(metrics: dict, corr: pd.DataFrame, raw_corr: pd.DataFrame, selected_features: List[str], scale_factors: Dict[str, float]) -> None:
    summary = {
        "input_csv": str(CSV_PATH),
        "input_raster": str(TIF_PATH),
        "target_source": TARGET_SOURCE,
        "scale_factors": scale_factors,
        "top_raw_bands_by_abs_pearson": raw_corr.head(10).to_dict(orient="records"),
        "top_spectral_indices_by_abs_pearson": corr.head(15).to_dict(orient="records"),
        "selected_rf_features": [{"feature": f, "formula": feature_formula(f)} for f in selected_features],
        "rf_metrics": metrics,
    }
    with open(OUT_DIR / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    raw_df = pd.read_csv(CSV_PATH, low_memory=False)
    samples, scale_factors, band_indexes, cleaning_report = load_and_clean_samples()
    cleaning_report.to_csv(OUT_DIR / "cleaning_report.csv", index=False, encoding="utf-8-sig")
    samples.to_csv(OUT_DIR / "cdom_cleaned_sampled_points.csv", index=False, encoding="utf-8-sig")

    features = build_feature_frame(samples)
    valid_rows = features.notna().all(axis=1)
    samples = samples.loc[valid_rows].reset_index(drop=True)
    features = features.loc[valid_rows].reset_index(drop=True)
    y = samples["cdom"].reset_index(drop=True)

    corr, raw_corr = correlation_tables(features, y)
    corr.to_csv(OUT_DIR / "spectral_feature_correlations.csv", index=False, encoding="utf-8-sig")
    raw_corr.to_csv(OUT_DIR / "raw_band_correlations.csv", index=False, encoding="utf-8-sig")

    selected_features = choose_features(corr)
    selected_df = pd.DataFrame({"feature": selected_features, "formula": [feature_formula(f) for f in selected_features]})
    selected_df.to_csv(OUT_DIR / "rf_selected_features.csv", index=False, encoding="utf-8-sig")

    model, metrics, pred_df, importance, random_cv_rows, spatial_rows = train_random_forest(features, y, selected_features, samples)
    pred_df.to_csv(OUT_DIR / "rf_holdout_predictions.csv", index=False, encoding="utf-8-sig")
    importance.to_csv(OUT_DIR / "rf_feature_importance.csv", index=False, encoding="utf-8-sig")
    random_cv_rows.to_csv(OUT_DIR / "rf_random_5fold_metrics.csv", index=False, encoding="utf-8-sig")
    if not spatial_rows.empty:
        spatial_rows.to_csv(OUT_DIR / "rf_spatial_group_5fold_metrics.csv", index=False, encoding="utf-8-sig")
    joblib.dump(model, OUT_DIR / "rf_cdom_model.joblib")

    map_path = predict_raster(model, selected_features, scale_factors)
    save_plots(raw_df, samples, corr, raw_corr, pred_df, importance, map_path)
    write_summary(metrics, corr, raw_corr, selected_features, scale_factors)

    print("Done.")
    print(f"Clean samples: {len(samples)}")
    print(f"Output directory: {OUT_DIR}")
    print("Top raw bands:")
    print(raw_corr.head(8)[["feature", "pearson_r", "spearman_r", "mutual_info"]].to_string(index=False))
    print("Top spectral indices:")
    print(corr.head(8)[["feature", "formula", "pearson_r", "spearman_r", "mutual_info"]].to_string(index=False))
    print("RF metrics:")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
