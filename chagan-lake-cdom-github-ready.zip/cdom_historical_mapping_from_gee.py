from __future__ import annotations

import json
import math
import re
from itertools import combinations, permutations
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from scipy import stats
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, KFold, train_test_split


BASE_DIR = Path(__file__).resolve().parent
PIPELINE_DIR = BASE_DIR / "outputs" / "cdom_2020" / "complete_ml_pipeline"
INPUT_DIR = BASE_DIR / "gee_exports"
OUT_DIR = BASE_DIR / "outputs" / "cdom_2020" / "historical_cdom"
FIG_DIR = OUT_DIR / "figures"
RASTER_DIR = OUT_DIR / "rasters"
MODEL_DIR = OUT_DIR / "models"
TABLE_DIR = OUT_DIR / "tables"

for path in [FIG_DIR, RASTER_DIR, MODEL_DIR, TABLE_DIR, INPUT_DIR]:
    path.mkdir(parents=True, exist_ok=True)

TARGET_COL = "mean"
RANDOM_STATE = 42
TEST_SIZE = 0.30
EPS = 1e-6
VIF_THRESHOLD = 30.0
PRESELECT_N = 30
MIN_FEATURES_AFTER_VIF = 6

COMMON_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"]
S2_TO_COMMON = {
    "Blue": "B2",
    "Green": "B3",
    "Red": "B4",
    "NIR": "B8",
    "SWIR1": "B11",
    "SWIR2": "B12",
}


def setup_plot_style() -> None:
    plt.rcParams["figure.dpi"] = 140
    plt.rcParams["savefig.dpi"] = 240
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.titlesize"] = 13
    plt.rcParams["axes.labelsize"] = 11
    plt.rcParams["xtick.labelsize"] = 9
    plt.rcParams["ytick.labelsize"] = 9


def add_feature(features: Dict[str, np.ndarray], name: str, values: np.ndarray) -> None:
    if name in features:
        return
    values = np.asarray(values, dtype=float)
    finite = np.isfinite(values)
    if finite.sum() < 10:
        return
    if np.nanstd(values[finite]) == 0:
        return
    features[name] = values


def build_common_features(df: pd.DataFrame) -> pd.DataFrame:
    band = {b: df[b].to_numpy(dtype=float) for b in COMMON_BANDS}
    features: Dict[str, np.ndarray] = {}

    for b in COMMON_BANDS:
        x = band[b]
        add_feature(features, b, x)
        add_feature(features, f"log_{b}", np.log(x + EPS))
        add_feature(features, f"sqrt_{b}", np.sqrt(np.clip(x, 0, None)))

    add_feature(features, "NDWI_Green_NIR", (band["Green"] - band["NIR"]) / (band["Green"] + band["NIR"] + EPS))
    add_feature(features, "MNDWI_Green_SWIR1", (band["Green"] - band["SWIR1"]) / (band["Green"] + band["SWIR1"] + EPS))
    add_feature(features, "NDVI_NIR_Red", (band["NIR"] - band["Red"]) / (band["NIR"] + band["Red"] + EPS))
    add_feature(features, "NDTI_Red_Green", (band["Red"] - band["Green"]) / (band["Red"] + band["Green"] + EPS))
    add_feature(features, "Blue_Green_Ratio", band["Blue"] / (band["Green"] + EPS))
    add_feature(features, "Blue_Red_Ratio", band["Blue"] / (band["Red"] + EPS))
    add_feature(features, "Green_Red_Ratio", band["Green"] / (band["Red"] + EPS))
    add_feature(features, "(Blue+Green)/Red", (band["Blue"] + band["Green"]) / (band["Red"] + EPS))
    add_feature(features, "(Blue+Green)/SWIR1", (band["Blue"] + band["Green"]) / (band["SWIR1"] + EPS))
    add_feature(features, "(Green-Red)/Blue", (band["Green"] - band["Red"]) / (band["Blue"] + EPS))

    for b1, b2 in permutations(COMMON_BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        ratio = (x1 + EPS) / (x2 + EPS)
        add_feature(features, f"{b1}/{b2}", ratio)
        add_feature(features, f"log({b1}/{b2})", np.log(ratio))
        add_feature(features, f"({b1}-{b2})/{b2}", (x1 - x2) / (x2 + EPS))

    for b1, b2 in combinations(COMMON_BANDS, 2):
        x1 = band[b1]
        x2 = band[b2]
        add_feature(features, f"NDI_{b1}_{b2}", (x1 - x2) / (x1 + x2 + EPS))
        add_feature(features, f"Diff_{b1}_{b2}", x1 - x2)
        add_feature(features, f"Sum_{b1}_{b2}", x1 + x2)

    out = pd.DataFrame(features).replace([np.inf, -np.inf], np.nan)
    out = out.loc[:, out.notna().sum(axis=0) >= int(0.95 * len(out))]
    out = out.fillna(out.median(numeric_only=True))
    return out


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 5 or np.nanstd(x[mask]) == 0:
        return 0.0
    return float(stats.pearsonr(x[mask], y[mask]).statistic)


def calculate_vif(X: pd.DataFrame, features: Sequence[str]) -> pd.DataFrame:
    rows = []
    for feature in features:
        others = [f for f in features if f != feature]
        if not others:
            rows.append({"feature": feature, "vif": 1.0})
            continue
        model = LinearRegression()
        model.fit(X[others], X[feature])
        r2 = model.score(X[others], X[feature])
        vif = math.inf if r2 >= 0.999999 else 1.0 / max(1.0 - r2, EPS)
        rows.append({"feature": feature, "vif": float(vif)})
    return pd.DataFrame(rows).sort_values("vif", ascending=False)


def vif_filter(X: pd.DataFrame, candidates: List[str]) -> Tuple[List[str], pd.DataFrame, pd.DataFrame]:
    current = list(candidates)
    before = calculate_vif(X, current)
    while len(current) > MIN_FEATURES_AFTER_VIF:
        vif = calculate_vif(X, current)
        max_vif = float(vif.iloc[0]["vif"])
        if max_vif <= VIF_THRESHOLD:
            break
        current.remove(str(vif.iloc[0]["feature"]))
    after = calculate_vif(X, current)
    return current, before, after


def load_training_samples() -> Tuple[pd.DataFrame, np.ndarray]:
    sample_path = PIPELINE_DIR / "01_clean_stratified_samples.csv"
    if not sample_path.exists():
        raise FileNotFoundError(
            "Missing cleaned samples. Run cdom_complete_ml_pipeline.py first so the same SCL=6 and optical-stratum samples are used."
        )
    samples = pd.read_csv(sample_path)
    common = pd.DataFrame({name: samples[s2_band].astype(float) for name, s2_band in S2_TO_COMMON.items()})
    valid = common.notna().all(axis=1) & samples[TARGET_COL].notna()
    common = common.loc[valid].reset_index(drop=True)
    y = samples.loc[valid, TARGET_COL].to_numpy(dtype=float)
    return common, y


def train_common_band_model() -> Tuple[RandomForestRegressor, List[str], Dict[str, float], Tuple[float, float]]:
    common, y = load_training_samples()
    features = build_common_features(common)

    corr_rows = []
    for col in features.columns:
        r = safe_corr(features[col].to_numpy(dtype=float), y)
        corr_rows.append({"feature": col, "pearson_r": r, "pearson_abs": abs(r)})
    corr_df = pd.DataFrame(corr_rows).sort_values("pearson_abs", ascending=False)
    corr_df.to_csv(TABLE_DIR / "01_common_band_feature_pearson.csv", index=False, encoding="utf-8-sig")

    candidates = corr_df.head(PRESELECT_N)["feature"].tolist()
    selected, vif_before, vif_after = vif_filter(features, candidates)
    vif_before.to_csv(TABLE_DIR / "02_common_band_vif_before.csv", index=False, encoding="utf-8-sig")
    vif_after.to_csv(TABLE_DIR / "03_common_band_vif_after.csv", index=False, encoding="utf-8-sig")

    X = features[selected]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE)
    model = RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, bootstrap=True, oob_score=True)
    grid = {
        "n_estimators": [500, 900],
        "max_depth": [4, 6, None],
        "min_samples_leaf": [2, 3, 5],
        "max_features": ["sqrt", 0.7],
    }
    cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    search = GridSearchCV(model, grid, cv=cv, scoring="r2", n_jobs=-1, refit=True)
    search.fit(X_train, y_train)

    best = search.best_estimator_
    pred_train = best.predict(X_train)
    pred_test = best.predict(X_test)
    metrics = {
        "train_r2": float(r2_score(y_train, pred_train)),
        "train_rmse": float(np.sqrt(mean_squared_error(y_train, pred_train))),
        "train_mae": float(mean_absolute_error(y_train, pred_train)),
        "test_r2": float(r2_score(y_test, pred_test)),
        "test_rmse": float(np.sqrt(mean_squared_error(y_test, pred_test))),
        "test_mae": float(mean_absolute_error(y_test, pred_test)),
        "oob_r2": float(getattr(best, "oob_score_", np.nan)),
        "n_samples": int(len(y)),
        "n_features": int(len(selected)),
    }

    final_model = clone(best)
    final_model.fit(X, y)
    joblib.dump(final_model, MODEL_DIR / "common_band_rf_model.joblib")
    pd.DataFrame({"feature": selected}).to_csv(TABLE_DIR / "04_common_band_final_features.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([metrics]).to_csv(TABLE_DIR / "05_common_band_model_metrics.csv", index=False, encoding="utf-8-sig")
    with open(OUT_DIR / "common_band_model_summary.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "note": "This model uses only Landsat/Sentinel common bands for historical mapping. It is not the original Sentinel-2 red-edge model.",
                "selected_features": selected,
                "best_params": search.best_params_,
                "metrics": metrics,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    y_clip = (float(np.nanpercentile(y, 0.5)), float(np.nanpercentile(y, 99.5)))
    return final_model, selected, metrics, y_clip


def year_from_path(path: Path) -> int | None:
    match = re.search(r"(19|20)\d{2}", path.name)
    return int(match.group(0)) if match else None


def build_feature_frame_from_raster(band_values: Dict[str, np.ndarray]) -> pd.DataFrame:
    return build_common_features(pd.DataFrame(band_values))


def predict_one_raster(path: Path, model: RandomForestRegressor, selected_features: Sequence[str], y_clip: Tuple[float, float]) -> Dict[str, float]:
    year = year_from_path(path)
    if year is None:
        raise ValueError(f"Could not parse year from {path.name}")

    with rasterio.open(path) as src:
        arr = src.read(list(range(1, 7))).astype("float32")
        profile = src.profile.copy()
        transform = src.transform
        crs = src.crs
        height, width = src.height, src.width

    valid = np.isfinite(arr).all(axis=0)
    valid &= np.nanmin(arr, axis=0) > 0
    valid &= np.nanmax(arr, axis=0) < 1

    pred = np.full((height, width), np.nan, dtype="float32")
    if valid.sum() > 0:
        flat = {band: arr[i][valid].astype(float) for i, band in enumerate(COMMON_BANDS)}
        feature_frame = build_feature_frame_from_raster(flat)
        missing = [f for f in selected_features if f not in feature_frame.columns]
        if missing:
            raise ValueError(f"Raster features missing for {path.name}: {missing}")
        values = model.predict(feature_frame[list(selected_features)])
        values = np.clip(values, y_clip[0], y_clip[1])
        pred[valid] = values.astype("float32")

    out_path = RASTER_DIR / f"ChaganLake_CDOM_RF_{year}_JunSep.tif"
    profile.update(count=1, dtype="float32", nodata=np.nan, compress="deflate")
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(pred, 1)
        dst.update_tags(year=str(year), source=str(path.name), model="common_band_rf")

    stats_row = {
        "year": year,
        "source_file": path.name,
        "output_file": out_path.name,
        "valid_pixels": int(np.isfinite(pred).sum()),
        "mean_cdom": float(np.nanmean(pred)),
        "median_cdom": float(np.nanmedian(pred)),
        "std_cdom": float(np.nanstd(pred)),
        "min_cdom": float(np.nanmin(pred)),
        "max_cdom": float(np.nanmax(pred)),
        "crs": str(crs),
        "transform": str(transform),
    }
    return stats_row


def make_panel_and_time_series(stats_df: pd.DataFrame) -> None:
    setup_plot_style()
    rasters = []
    for _, row in stats_df.sort_values("year").iterrows():
        path = RASTER_DIR / row["output_file"]
        with rasterio.open(path) as src:
            arr = src.read(1).astype(float)
            bounds = src.bounds
        rasters.append((int(row["year"]), arr, bounds))

    finite_values = np.concatenate([arr[np.isfinite(arr)] for _, arr, _ in rasters if np.isfinite(arr).any()])
    vmin = float(np.nanpercentile(finite_values, 2))
    vmax = float(np.nanpercentile(finite_values, 98))

    n = len(rasters)
    ncols = 3
    nrows = math.ceil(n / ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(11.0, 3.6 * nrows), constrained_layout=True)
    axes = np.atleast_1d(axes).ravel()
    letters = "abcdefghijklmnopqrstuvwxyz"
    im = None
    for i, (year, arr, bounds) in enumerate(rasters):
        ax = axes[i]
        extent = [bounds.left, bounds.right, bounds.bottom, bounds.top]
        im = ax.imshow(arr, cmap="YlOrBr", vmin=vmin, vmax=vmax, extent=extent, origin="upper")
        ax.set_title(f"({letters[i]}) {year}", loc="left", fontsize=12)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)
    for ax in axes[n:]:
        ax.axis("off")
    if im is not None:
        cbar = fig.colorbar(im, ax=axes[:n], shrink=0.82, location="bottom", pad=0.04)
        cbar.set_label("Predicted CDOM")
    fig.savefig(FIG_DIR / "01_historical_cdom_spatial_panel.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    data = stats_df.sort_values("year")
    ax.plot(data["year"], data["mean_cdom"], marker="o", lw=2.2, color="#a6611a", label="Mean")
    ax.fill_between(
        data["year"].to_numpy(dtype=float),
        (data["mean_cdom"] - data["std_cdom"]).to_numpy(dtype=float),
        (data["mean_cdom"] + data["std_cdom"]).to_numpy(dtype=float),
        color="#dfc27d",
        alpha=0.28,
        linewidth=0,
        label="Mean ± SD",
    )
    ax.set_xlabel("Year")
    ax.set_ylabel("Predicted CDOM")
    ax.set_title("Chagan Lake Jun-Sep CDOM Time Series")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "02_historical_cdom_time_series.png")
    plt.close(fig)


def main() -> None:
    model, selected_features, metrics, y_clip = train_common_band_model()
    print("Common-band historical model trained.")
    print(pd.Series(metrics).to_string())
    print("\nSelected common-band features:")
    print(pd.Series(selected_features).to_string(index=False))

    tif_files = sorted(INPUT_DIR.glob("*.tif")) + sorted(INPUT_DIR.glob("*.tiff"))
    if not tif_files:
        print(f"\nNo GEE GeoTIFF files found in {INPUT_DIR}.")
        print("Run gee_scripts/gee_chaganlake_historical_landsat_exports.js in GEE, download the exported files, and place them in this folder.")
        return

    rows = []
    for path in tif_files:
        rows.append(predict_one_raster(path, model, selected_features, y_clip))
        print(f"Mapped CDOM for {path.name}")

    stats_df = pd.DataFrame(rows).sort_values("year")
    stats_df.to_csv(TABLE_DIR / "06_historical_cdom_stats.csv", index=False, encoding="utf-8-sig")
    make_panel_and_time_series(stats_df)
    print(f"\nHistorical CDOM outputs saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
