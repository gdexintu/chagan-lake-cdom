// Cross-sensor Chagan Lake Jun-Sep composites for long-term CDOM mapping.
// Copy into Google Earth Engine Code Editor and run:
// https://code.earthengine.google.com/
//
// The export bands match cdom_cross_sensor_longterm_pipeline.py:
// Blue, Green, Red, NIR, SWIR1, SWIR2.
//
// Scientific note:
// - 1986-2014 can only use Landsat.
// - 2015+ can optionally merge Sentinel-2 with Landsat using common bands.
// - For the strictest long-term trend comparability, set USE_SENTINEL2_AFTER_2015 = false.
// - For denser recent-year spatial coverage, keep it true.

var roi = ee.Geometry.Rectangle([123.98, 45.13, 124.47, 45.46], null, false);

var EXPORT_YEARS = [1986, 1991, 1996, 2001, 2006, 2011, 2016, 2021];
// Today is 2026-05-16, so the 2026 Jun-Sep season is not complete.
// After 2026-09-30, you may add 2026 to EXPORT_YEARS.

var EXPORT_FOLDER = "ChaganLake_CDOM_CrossSensor_Exports";
var EXPORT_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2", "MNDWI", "NDVI", "valid_count"];
var USE_SENTINEL2_AFTER_2015 = true;

Map.centerObject(roi, 11);
Map.addLayer(roi, {color: "red"}, "Chagan Lake ROI");

function maskLandsatC2L2(image) {
  var qa = image.select("QA_PIXEL");
  var clearMask = qa.bitwiseAnd(1 << 0).eq(0)   // fill
    .and(qa.bitwiseAnd(1 << 1).eq(0))           // dilated cloud
    .and(qa.bitwiseAnd(1 << 2).eq(0))           // cirrus
    .and(qa.bitwiseAnd(1 << 3).eq(0))           // cloud
    .and(qa.bitwiseAnd(1 << 4).eq(0))           // cloud shadow
    .and(qa.bitwiseAnd(1 << 5).eq(0));          // snow
  var saturationMask = image.select("QA_RADSAT").eq(0);
  return image.updateMask(clearMask).updateMask(saturationMask);
}

function addWaterMaskAndIndices(image) {
  var mndwi = image.normalizedDifference(["Green", "SWIR1"]).rename("MNDWI");
  var ndvi = image.normalizedDifference(["NIR", "Red"]).rename("NDVI");
  var positive = image.select(["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .reduce(ee.Reducer.min()).gt(0);
  var validRange = image.select(["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .reduce(ee.Reducer.max()).lt(1);
  var waterMask = mndwi.gt(0).and(ndvi.lt(0.35)).and(positive).and(validRange);
  return image.addBands([mndwi, ndvi]).updateMask(waterMask).clip(roi);
}

function prepL57(image) {
  image = maskLandsatC2L2(image);
  var optical = image
    .select(["SR_B1", "SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B7"],
            ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .multiply(0.0000275)
    .add(-0.2);
  return addWaterMaskAndIndices(optical)
    .copyProperties(image, image.propertyNames())
    .set("sensor_group", "Landsat");
}

function prepL89(image) {
  image = maskLandsatC2L2(image);

  // Landsat 8/9 SR_QA_AEROSOL bits 6-7 represent aerosol level.
  // Exclude high-aerosol observations to reduce atmospheric residuals.
  var aerosol = image.select("SR_QA_AEROSOL");
  var aerosolLevel = aerosol.rightShift(6).bitwiseAnd(3);
  image = image.updateMask(aerosolLevel.lte(2));

  var optical = image
    .select(["SR_B2", "SR_B3", "SR_B4", "SR_B5", "SR_B6", "SR_B7"],
            ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .multiply(0.0000275)
    .add(-0.2);
  return addWaterMaskAndIndices(optical)
    .copyProperties(image, image.propertyNames())
    .set("sensor_group", "Landsat");
}

function prepS2(image) {
  var scl = image.select("SCL");
  var clearMask = scl.neq(0)   // no data
    .and(scl.neq(1))           // saturated / defective
    .and(scl.neq(3))           // cloud shadow
    .and(scl.neq(8))           // medium probability cloud
    .and(scl.neq(9))           // high probability cloud
    .and(scl.neq(10))          // cirrus
    .and(scl.neq(11));         // snow / ice

  var optical = image
    .updateMask(clearMask)
    .select(["B2", "B3", "B4", "B8", "B11", "B12"],
            ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"])
    .divide(10000)
    .resample("bilinear");

  return addWaterMaskAndIndices(optical)
    .copyProperties(image, image.propertyNames())
    .set("sensor_group", "Sentinel-2");
}

function landsatCollection(year) {
  var start = ee.Date.fromYMD(year, 6, 1);
  var end = ee.Date.fromYMD(year, 10, 1);
  var col = ee.ImageCollection([]);

  if (year <= 2011) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LT05/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL57)
    );
  }

  if (year >= 1999 && year <= 2021) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LE07/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL57)
    );
  }

  if (year >= 2013) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL89)
    );
  }

  if (year >= 2022) {
    col = col.merge(
      ee.ImageCollection("LANDSAT/LC09/C02/T1_L2")
        .filterBounds(roi)
        .filterDate(start, end)
        .map(prepL89)
    );
  }

  return col;
}

function sentinel2Collection(year) {
  if (year < 2016 || !USE_SENTINEL2_AFTER_2015) {
    return ee.ImageCollection([]);
  }
  var start = ee.Date.fromYMD(year, 6, 1);
  var end = ee.Date.fromYMD(year, 10, 1);
  return ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
    .filterBounds(roi)
    .filterDate(start, end)
    .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 60))
    .map(prepS2);
}

function collectionForYear(year) {
  return landsatCollection(year).merge(sentinel2Collection(year));
}

function compositeForYear(year) {
  var col = collectionForYear(year);
  var validCount = col.select("Blue").count().rename("valid_count");
  print("Year " + year + " valid image count", col.size());
  print("Year " + year + " sensor groups", col.aggregate_histogram("sensor_group"));
  return col
    .median()
    .addBands(validCount)
    .select(EXPORT_BANDS)
    .clip(roi)
    .set({
      "year": year,
      "season": "June-September",
      "use_sentinel2_after_2015": USE_SENTINEL2_AFTER_2015,
      "preprocessing": "Landsat C2 L2 SR + Sentinel-2 SR Harmonized common bands; QA cloud/shadow/snow/saturation mask; high aerosol mask for L8/L9; S2 SCL mask; water mask; seasonal median"
    });
}

EXPORT_YEARS.forEach(function(year) {
  var image = compositeForYear(year);
  Map.addLayer(image, {bands: ["SWIR1", "NIR", "Red"], min: 0, max: 0.35}, "Common SR " + year, false);

  Export.image.toDrive({
    image: image.toFloat(),
    description: "ChaganLake_cross_sensor_SR_" + year + "_JunSep",
    folder: EXPORT_FOLDER,
    fileNamePrefix: "ChaganLake_cross_sensor_SR_" + year + "_JunSep",
    region: roi,
    scale: 30,
    crs: "EPSG:4326",
    maxPixels: 1e13
  });
});
