# Reproducibility Workflow

The project is organized as a script-based workflow. Run the steps below after placing the required local datasets described in `DATA.md`.

## 1. Sentinel-2 Model Development

```bash
python cdom_complete_ml_pipeline.py
```

Main outputs:

- cleaned optically stratified sample table
- Pearson/Spearman feature screening results
- VIF filtering tables
- ReliefF ranking
- RF/SVR/XGBoost model metrics
- SHAP interpretation figures

## 2. Stratified RF Mapping

```bash
python cdom_stratified_rf.py
```

Main outputs:

- 2020 Random Forest fitted CDOM raster
- holdout validation figure
- feature importance figure

## 3. Cross-Sensor Long-Term Modeling

First export the required Landsat/Sentinel composites from Google Earth Engine using:

```text
gee_scripts/gee_chaganlake_historical_landsat_exports.js
gee_scripts/gee_chaganlake_cross_sensor_integrated_exports.js
gee_scripts/gee_chaganlake_2026_cdom_mean_cross_sensor_consistent.js
```

Then run:

```bash
python cdom_cross_sensor_longterm_pipeline.py
```

Main outputs:

- common-band feature matrix
- cross-sensor model comparison
- long-term predicted CDOM rasters
- long-term spatial panel
- long-term temporal statistics

## 4. Figure Updates

Integrated study-area map:

```bash
python make_integrated_study_area_cdom_map.py
```

Lake-only long-term panel:

```bash
python make_longterm_cdom_lake_only_figure.py
```

Add 2026 partial-year map:

```bash
python add_2026_longterm_map.py
```

## Validation Metrics

The workflow reports:

- R²
- RMSE
- MAE
- MAPE
- five-fold cross-validation metrics
- out-of-bag score where supported

For manuscript writing, emphasize test-set and cross-validation metrics rather than training-set R².

