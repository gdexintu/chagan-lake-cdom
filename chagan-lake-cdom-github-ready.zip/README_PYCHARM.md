# 查干湖 CDOM Sentinel-2 拟合项目

## 项目说明

本项目以公开 CDOM 遥感产品提取值作为参考标签，不是现场实测 CDOM 数据。
流程用于分析 Sentinel-2 光谱特征与参考 CDOM 产品之间的关系，并进行机器学习拟合。

## 主要数据

- `CDOM_Extracted_2020.csv`：从公开 CDOM 产品提取的样本均值，目标列为 `mean`
- `S2_2020_AllBands_Median.tif`：Sentinel-2 2020 年多波段中值影像

## 推荐在 PyCharm 中打开

1. 打开 PyCharm
2. 选择 `File -> Open`
3. 选择项目目录：`D:\codex`
4. 设置 Python Interpreter：
   - 当前已创建并验证的项目虚拟环境为：`D:\codex\pytorch\Scripts\python.exe`
   - 该环境使用 `--system-site-packages` 创建，会复用当前本机已安装的科学计算库
5. 运行配置：
   - 主流程：`cdom_complete_ml_pipeline.py`
   - SHAP 连续图：`cdom_shap_continuous_plots.py`

## 运行命令

```powershell
D:\codex\pytorch\Scripts\python.exe D:\codex\cdom_complete_ml_pipeline.py
D:\codex\pytorch\Scripts\python.exe D:\codex\cdom_shap_continuous_plots.py
```

## 主流程

`cdom_complete_ml_pipeline.py` 包含：

1. 读取公开 CDOM 产品提取样本
2. 匹配 Sentinel-2 多光谱影像
3. SCL=6 水体筛选
4. B11/B3 光学分层
5. 构建候选特征：原始波段、波段比值、水体指数、红边指数、多波段指数
6. Pearson / Spearman 相关性分析
7. VIF 共线性筛选
8. ReliefF 特征排序
9. RF / SVR / XGBoost 建模
10. 70%/30% 训练测试评价
11. 5 折交叉验证评价
12. SHAP 与 permutation importance 模型解释

## 主要输出

所有结果保存在：

`D:\codex\outputs\cdom_2020\complete_ml_pipeline`

重要结果：

- `10_model_metrics.csv`：测试集 R²、RMSE、MAE、MAPE
- `13_5fold_cv_overall_metrics.csv`：5 折交叉验证结果
- `01b_mean_reflectance_curve.csv`：B1-B12 平均反射率与 bootstrap 95% 置信区间
- `01c_representative_sample_spectra.csv`：代表性样本的 B1-B12 光谱曲线数据
- `01d_key_spectral_band_selection.csv`：论文主图保留/隐藏波段依据
- `01d_key_band_representative_sample_spectra.csv`：关键波段代表性样本光谱曲线数据
- `02_all_feature_pearson_spearman.csv`：所有候选指数相关性
- `04_vif_after_filter.csv`：VIF 筛选后特征
- `06_relieff_feature_ranking.csv`：ReliefF 排序
- `11_RF_shap_importance.csv`：SHAP 重要性

重要图件：

- `figures/02_top20_pearson_bar.png`
- `figures/01b_mean_reflectance_curve_B1_B12.png`
- `figures/01c_representative_sample_spectra_B1_B12.png`
- `figures/01d_key_band_representative_sample_spectra.png`
- `figures/06_vif_after_filter.png`
- `figures/08_relieff_feature_ranking.png`
- `figures/12_model_prediction_scatter_grid.png`
- `figures/16b_shap_smooth_effect_curves.png`

## 论文写作注意

本项目目标变量来源于公开 CDOM 遥感产品，不是现场采样实测值。
论文中建议使用“参考 CDOM 产品拟合”“公开 CDOM 产品重建”“Sentinel-2 对 CDOM 产品的代理建模”等表述。
不要写成“基于现场实测 CDOM 的真实反演精度”。
